(function(root){'use strict';
// Code-native pictograms; no Chinese text or external icon/font dependency.
const defs={
 infantry:{label:'ทหารราบ',paths:['M9 8V5a3 3 0 0 1 6 0v3M8 8h8M12 9v8M12 12l-5 3M12 17l-4 6M12 17l4 6M20 2v21M18 5l2-4 2 4','M3 12h6v6l-3 3-3-3z']},
 cavalry:{label:'ทหารม้า',paths:['M3 13Q7 10 13 13L16 7l4-2 3 5-4 2-1 6H6L3 13zM6 18l-2 5M9 18l2 5M16 18l-1 5M19 16l3 6M3 13l-2-2','M10 6a2 2 0 1 0 0-4 2 2 0 0 0 0 4M10 7l-1 5 4 2M10 8l6 1M14 2l6 14']},
 archers:{label:'พลธนู',paths:['M7 2Q23 12 7 23L12 12 7 2M2 12h20M18 8l5 4-5 4']},
 scout:{label:'ลาดตระเวน',paths:['M7 7a3 3 0 1 0 0-6 3 3 0 0 0 0 6M7 8v8M7 11l-5 3M7 16l-4 7M7 16l5 6M16 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8M19 10l4 5']},
 engineer:{label:'ช่างค่าย',paths:['M3 3l5-2 4 6-4 3-5-7zM9 9l12 14M21 2l-5 3-1 5L3 22M19 1l4 4-3 4-5 1']},
 support:{label:'เสบียง/สนับสนุน',paths:['M3 5h16v13H3zM3 9h16M10 5v13M1 18h21l2-9M6 21a2 2 0 1 0 0 .01M18 21a2 2 0 1 0 0 .01']},
 guard:{label:'องครักษ์',paths:['M12 1l9 4v8c0 5-9 10-9 10S3 18 3 13V5l9-4zM12 6v10M7 11h10']},
 naval:{label:'กองเรือ',paths:['M2 16h21l-5 7H7l-5-7zM12 1v16M11 3L3 13h8M14 4l7 9h-7']},
 fire:{label:'เรือเพลิง',paths:['M2 17h21l-5 6H7l-5-6zM11 1c0 6-5 7-5 11a6 6 0 0 0 12 0c0-3-3-5-3-8 0 4-3 5-4-3z']}
};
function type(u){return defs[u?.type]?u.type:'infantry';}
function svg(key,cls='unit-symbol'){const d=defs[key]||defs.infantry;return '<svg class="'+cls+'" viewBox="0 0 26 26" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">'+d.paths.map(p=>'<path d="'+p+'"/>').join('')+'</svg>';}
function paint(g,key,color='#f5e6bf',size=24){const d=defs[key]||defs.infantry;g.save();g.translate(-size/2,-size/2);g.scale(size/26,size/26);g.strokeStyle=color;g.lineWidth=1.85;g.lineCap='round';g.lineJoin='round';g.shadowBlur=0;for(const p of d.paths)g.stroke(new Path2D(p));g.restore();}
const api={defs,type,svg,paint};root.BattleSymbols=api;if(typeof module==='object')module.exports=api;
})(typeof globalThis!=='undefined'?globalThis:this);
