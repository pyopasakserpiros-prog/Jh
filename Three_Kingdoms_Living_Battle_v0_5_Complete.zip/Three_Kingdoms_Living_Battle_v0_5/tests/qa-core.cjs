'use strict';
const assert=require('node:assert/strict'),C=require('../src/battle-core'),D=C.D,E=C.E;
let checks=0;function test(name,fn){fn();checks++;console.log('PASS '+name);}
const sumTroops=(sim,side)=>sim.units.filter(u=>u.side===side).reduce((s,u)=>s+u.troops,0);
const totalRations=sim=>sim.units.reduce((s,u)=>s+u.rations,0)+sim.nodes.reduce((s,n)=>s+n.stock,0)+sim.camps.reduce((s,c)=>s+c.stock,0)+sim.convoys.reduce((s,c)=>s+c.cargo,0);
function invariant(sim){
 for(const side of [sim.side,sim.opponent])assert.equal(sumTroops(sim,side)+sim.metrics.losses[side],sim.initialTotals[side],'manpower conservation '+side);
 const commanders=sim.units.filter(u=>u.troops>0&&u.status!=='merged').map(u=>u.commanderId);assert.equal(new Set(commanders).size,commanders.length,'one active unit per commander');
 for(const u of sim.units){for(const k of ['x','y','troops','rations','fatigue','morale'])assert.ok(Number.isFinite(u[k]),u.id+'.'+k+' must be finite');assert.ok(u.troops>=0&&u.rations>=-1e-7);assert.ok(sim.npcs[u.commanderId]);if(u.parentId)assert.ok(sim.units.some(p=>p.id===u.parentId));}
 for(const c of sim.camps)assert.ok(c.progress>=0&&c.progress<=100&&c.stock>=-1e-7);
}
test('111 sourced cards have unique IDs and stable complete 68-axis identities',()=>{
 assert.equal(D.CARDS.filter(c=>c.draftable!==false).length,111);assert.equal(new Set(D.CARDS.filter(c=>c.draftable!==false).map(c=>c.id)).size,111);assert.equal(E.axisCount,68);
 for(const c of D.CARDS){const n=E.createNpc({id:c.id,seed:1});E.applyPreset(n,c.preset);const id=E.getIdentity(n);let count=0;for(const [group,defs]of Object.entries(E.axisDefinitions))for(const def of defs){assert.ok(Number.isFinite(id[group][def.id])&&id[group][def.id]>=0&&id[group][def.id]<=100,c.id+' '+def.id);count++;}assert.equal(count,68);assert.ok(D.SOURCES.some(s=>s.id===c.sourceId));assert.ok(c.bio.length>10&&c.evidence.length>20);assert.ok(['สูง','กลาง','ต่ำ'].includes(c.confidence));}
});
test('all four scenario/side combinations deploy valid distinct rosters',()=>{
 for(const scenario of ['chibi','boma'])for(const side of D.SCENARIOS[scenario].sides){const sim=C.createSimulation({scenario,side:side.id,mode:'era'});assert.equal(sim.units.length,D.SCENARIOS[scenario].roles.length*2);invariant(sim);assert.equal(new Set(Object.keys(sim.npcs)).size,Object.keys(sim.npcs).length);for(const id of Object.values(sim.assignments[side.id]))assert.ok(D.eligible(C.card(id),scenario,side.id,'era'));}
});
test('duplicate or missing assignments are rejected; anachronistic selection is explicit',()=>{
 const a=C.autoRoster('chibi','allied');const bad={...a.assign,field:a.assign.supreme};assert.throws(()=>C.createSimulation({assign:bad,reserves:[]}),/หนึ่งคน/);assert.throws(()=>C.validateRoster('chibi','allied',{},[]),/ยังไม่ได้เลือก/);
 assert.equal(D.eligible(C.card('dian_wei'),'chibi','allied','era'),false);assert.equal(D.eligible(C.card('dian_wei'),'chibi','allied','free'),true);
 const swapped={...a.assign,supreme:'cao_cao'};assert.throws(()=>C.createSimulation({assign:swapped,reserves:a.reserves}),/ฝ่ายตรงข้าม/);
});
test('rerouting a moving army retains its current position and current edge',()=>{
 const sim=C.createSimulation(),u=sim.units.find(u=>u.side===sim.side&&u.role==='field');assert.ok(C.orderMove(sim,u,'east_landing','test'));
 C.step(sim,10);const p={x:u.x,y:u.y},edge=u.route.slice(0,2),progress=u.edgeProgress;assert.ok(progress>0);assert.ok(C.orderMove(sim,u,'chibi','return test'));assert.deepEqual({x:u.x,y:u.y},p);assert.deepEqual(u.route.slice(0,2),edge);assert.equal(u.edgeProgress,progress);
 C.step(sim,1);assert.ok(C.dist(p,u)<3,'one minute cannot teleport across map');
});
test('naval formations use water routes and cannot sail over land to inland headquarters',()=>{
 const sim=C.createSimulation(),u=sim.units.find(u=>u.side===sim.side&&u.role==='naval');
 assert.ok(C.orderMove(sim,u,'north_port','naval movement'));
 for(let i=0;i<u.route.length-1;i++){const a=u.route[i],b=u.route[i+1];assert.ok(sim.edges.some(e=>e.terrain==='water'&&((e.from===a&&e.to===b)||(e.from===b&&e.to===a))));}
 assert.equal(C.orderMove(sim,u,'wulin','invalid inland sailing'),false);
});
test('split and merge preserve troops and rations and require a distinct reserve commander',()=>{
 const sim=C.createSimulation(),p=sim.units.find(u=>u.side===sim.side&&u.role==='field'),before=p.troops,rations=p.rations,id=C.freeOfficers(sim,sim.side)[0];assert.equal(C.splitUnit(sim,p,NaN,id),null);assert.equal(C.splitUnit(sim,p,-1,id),null);assert.equal(C.splitUnit(sim,p,1000,p.commanderId),null);
 const d=C.splitUnit(sim,p,1000,id);assert.ok(d);assert.equal(p.troops+d.troops,before);assert.ok(Math.abs(p.rations+d.rations-rations)<1e-7);assert.notEqual(d.commanderId,p.commanderId);assert.equal(C.splitUnit(sim,p,500,id),null);invariant(sim);assert.ok(C.mergeUnit(sim,d));assert.equal(p.troops,before);assert.ok(Math.abs(p.rations-rations)<1e-7);assert.equal(d.troops,0);assert.equal(C.mergeUnit(sim,d),false);invariant(sim);
});
test('new camps cost local rations, require construction time and finish with real defenses',()=>{
 const sim=C.createSimulation(),u=sim.units.find(u=>u.side===sim.side&&u.role==='engineer'),before=totalRations(sim),n=sim.nodes.find(n=>n.id===u.nodeId);const c=C.constructCamp(sim,u);assert.ok(c);assert.equal(c.progress,0);assert.ok(Math.abs(totalRations(sim)-before)<1e-7);assert.equal(C.constructCamp(sim,u),false);C.step(sim,120);assert.equal(c.progress,100);const boosted=C.defenseAt(sim,n,u.side);sim.camps=sim.camps.filter(x=>x!==c);assert.ok(C.defenseAt(sim,n,u.side)<boosted,'completed camp adds real defensive power');sim.camps.push(c);assert.ok(sim.events.some(e=>e.type==='camp'));invariant(sim);
});
test('real-time operations produce movement, supply, camps, detachments, and bounded resource use',()=>{
 const sim=C.createSimulation({seed:208}),rations=totalRations(sim);for(let i=0;i<12;i++){C.step(sim,120);invariant(sim);}assert.ok(sim.metrics.campBuilt>0);assert.ok(sim.metrics.detached>0);assert.ok(sim.convoys.length>0);assert.ok(sim.events.some(e=>e.type==='movement'));assert.ok(totalRations(sim)+sim.metrics.rationsConsumed<=rations+.01,'no new rations appear');assert.ok(sim.units.some(u=>u.decision?.contributions.personality!==0));
});
test('seeded multi-hour runs are reproducible',()=>{
 const a=C.createSimulation({seed:42}),b=C.createSimulation({seed:42});for(let i=0;i<8;i++){C.step(a,120);C.step(b,120);}const snapshot=s=>JSON.stringify({units:s.units,camps:s.camps,events:s.events,weather:s.weather,metrics:s.metrics});assert.equal(snapshot(a),snapshot(b));invariant(a);invariant(b);
});
test('all 4 playable sides finish finite campaigns across 3 seeds',()=>{
 for(const scenario of ['chibi','boma'])for(const side of D.SCENARIOS[scenario].sides)for(const seed of [1,208,777]){const sim=C.createSimulation({scenario,side:side.id,seed,mode:'era'});let guard=0;while(sim.status!=='completed'&&guard++<60){C.step(sim,120);invariant(sim);}assert.equal(sim.status,'completed');assert.ok(sim.outcome);assert.ok(sim.time<=D.SCENARIOS[scenario].hours*60);console.log('  '+scenario+'/'+side.id+' seed '+seed+' -> '+sim.outcome.result+' at minute '+sim.time);}
});
console.log('\n'+checks+' acceptance groups passed.');
