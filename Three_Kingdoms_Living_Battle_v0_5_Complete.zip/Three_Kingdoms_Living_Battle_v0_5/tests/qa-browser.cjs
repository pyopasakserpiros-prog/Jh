'use strict';
// Requires Playwright in the test environment only. The distributed game has no dependencies.
// BROWSER_EXECUTABLE may point to a local Chromium when Playwright's own browser is unavailable.
const {chromium}=require('playwright'),assert=require('node:assert/strict'),path=require('node:path'),fs=require('node:fs');
(async()=>{
 const options={headless:true};if(process.env.BROWSER_EXECUTABLE){options.executablePath=process.env.BROWSER_EXECUTABLE;options.args=['--no-sandbox','--disable-dev-shm-usage','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader'];}
 const browser=await chromium.launch(options),results=[];
 const file='file://'+path.resolve(__dirname,'../Three_Kingdoms_Living_Battle_v0_5.html'),shots=process.env.QA_SHOTS;
 for(const size of[{width:1440,height:1000},{width:393,height:851},{width:360,height:800}].filter(s=>!process.env.QA_WIDTH||s.width===Number(process.env.QA_WIDTH))){
  console.log('Testing viewport '+size.width);const page=await browser.newPage({viewport:size,isMobile:size.width<600,hasTouch:size.width<600}),errors=[],remote=[];page.on('pageerror',e=>errors.push(e.message));page.on('request',r=>{if(/^https?:/.test(r.url()))remote.push(r.url());});await page.goto(file);await page.evaluate(()=>document.fonts.ready);
  assert.equal(await page.locator('.stage-card').count(),5);await page.click('[data-action="nextstep"]');await page.click('[data-action="nextstep"]');
  await page.fill('#cardSearch','โลซก');assert.equal(await page.locator('.officer-card').count(),1);await page.fill('#cardSearch','');
  await page.locator('[data-action="inspect"]').first().click();for(const tab of['personality','abilities','foundation','relations','decisions','history'])await page.click('[data-action="npctab"][data-value="'+tab+'"]');await page.keyboard.press('Escape');assert.equal(await page.locator('.modal').count(),0);
  await page.click('[data-action="nextstep"]');await page.click('[data-action="launch"]');await page.evaluate(()=>{BattleApp.pause();LivingBattle.step(BattleApp.state.sim,120);BattleApp.refresh();});
  assert.ok(await page.locator('#battleCanvas').count());assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false);const before=await page.evaluate(()=>BattleApp.state.sim.time);await page.click('[data-action="step30"]');assert.equal(await page.evaluate(()=>BattleApp.state.sim.time),before+30);
  await page.click('[data-action="layers"]');await page.uncheck('[data-layer="routes"]');assert.equal(await page.evaluate(()=>BattleApp.getMap().layers.routes),false);await page.click('[data-action="layers"]');
  const box=await page.locator('#battleCanvas').boundingBox(),px=box.x+box.width/2,py=box.y+box.height/2;const pan=await page.evaluate(()=>BattleApp.getMap().camera.panX);await page.mouse.move(px,py);await page.mouse.down();await page.mouse.move(px+40,py+20,{steps:4});await page.mouse.up();assert.ok(await page.evaluate(p=>BattleApp.getMap().camera.panX!==p,pan));
  if(shots){fs.mkdirSync(shots,{recursive:true});await page.screenshot({path:path.join(shots,'map-'+size.width+'.png'),fullPage:true});}
  for(const tab of ['overview','army','npcs','reports','sources','map']){const target=page.locator('[data-action="battletab"][data-value="'+tab+'"]').first();await target.scrollIntoViewIfNeeded();await target.click();assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false,'overflow '+tab+' width '+size.width);}
  await page.evaluate(()=>BattleApp.inspect('zhou_yu'));for(const tab of['overview','personality','abilities','foundation','relations','decisions','history'])await page.click('[data-action="npctab"][data-value="'+tab+'"]');assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false);
  assert.deepEqual(errors,[]);assert.deepEqual(remote,[],'offline HTML should never fetch remote dependencies');results.push({viewport:size,errors,remoteRequests:remote.length,result:'PASS'});
 }
 console.log(JSON.stringify(results,null,2));
 // Some externally supplied Chromium builds do not complete Browser.close on this host.
 if(process.env.QA_EXIT_AFTER_RESULT==='1')process.exit(0);await browser.close();
})().catch(e=>{console.error(e);process.exit(1)});
