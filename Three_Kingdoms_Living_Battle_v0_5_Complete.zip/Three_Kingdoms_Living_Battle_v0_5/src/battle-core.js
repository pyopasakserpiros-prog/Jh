(function(root){'use strict';
const E=root.NpcIdentityEngine||(typeof require==='function'?require('./npc-runtime'):null),D=root.BattleData||(typeof require==='function'?require('./data'):null),M=root.BattleMaps||(typeof require==='function'?require('./maps'):null);
const VERSION='0.5.0',clamp=(v,a=0,b=100)=>Math.max(a,Math.min(b,v)),round=v=>Math.round(v*100)/100,card=id=>D.CARDS.find(c=>c.id===id),dist=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y);
function operations(){return root.BattleOps||(typeof require==='function'?require('./operations'):null);}
function sideColor(sim,side){return operations().sideColor(sim,side);}
function defenseAt(sim,n,side){return operations().defenseAt(sim,n,side);}
const ACTIONS=[
 ['disperse','กระจายระยะกองเรือป้องกันไฟ','naval_warfare',{caution:.9,discipline:.6,creativity:.3},{sectDuty:.7}],
 ['formup','รวมแนวกองเรือประสานรบ','naval_warfare',{discipline:.8,courage:.4},{sectDuty:.7}],
 ['firefight','แบ่งกำลังดับไฟและช่วยเรือใกล้เคียง','siege_engineering',{empathy:.7,discipline:.9,caution:.7},{sectDuty:.8}],
 ['medical','พักลูกเรือและแยกผู้ป่วย','medicine_care',{empathy:.8,caution:.8,discipline:.6},{familyClan:.4}],
 ['attack','เข้าตีแนวหน้า','land_warfare',{aggression:.9,courage:.8,caution:-.7},{martialPeak:.5,honorLegacy:.4}],
 ['flank','โอบเข้าตีปีก','strategy_doctrine',{creativity:.8,rationality:.4,caution:.2},{knowledgeCraft:.5}],
 ['recon','ตรวจเส้นทางและข่าวข้าศึก','intelligence_deception',{caution:.8,curiosity:.9},{knowledgeCraft:.6}],
 ['camp','ตั้งค่ายพักและเสริมแนว','siege_engineering',{discipline:.9,caution:.8},{sectDuty:.7}],
 ['resupply','กลับเติมเสบียงและพักทหาร','logistics_sustainment',{discipline:.6,caution:.8,aggression:-.5},{sectDuty:.5}],
 ['hold','รักษาที่มั่นและรอจังหวะ','command_leadership',{discipline:.7,caution:.6,composure:.5,aggression:-.5},{sectDuty:.5}],
 ['retreat','ถอนกำลังรักษาทหาร','command_leadership',{caution:1,empathy:.6,pride:-.7},{familyClan:.3}],
 ['fireprepare','เตรียมเรือเพลิง','naval_warfare',{creativity:.8,discipline:.6,caution:.3},{knowledgeCraft:.6}],
 ['fireattack','ปล่อยกองเรือเพลิง','naval_warfare',{courage:.8,creativity:.8,caution:-.5},{honorLegacy:.7}]
];
for(const [id,label,domain,pw,vw]of ACTIONS){if(!E.activities['lb2_'+id])E.registerAction({id:'lb2_'+id,label,version:'1.0.0',category:domain,skillDomain:domain,capabilityDomain:domain,effort:35,risk:id==='fireattack'?65:35,timeCost:1,personalityWeights:pw,valueWeights:vw,effects:{['lb2_'+id]:true}});}
const roleName=id=>D.ROLES.find(r=>r.id===id)?.name||'หน่วยแยก';
function autoRoster(scenario,side,mode='era',existing={},reserveCount=4){
 const spec=D.SCENARIOS[scenario],used=new Set(),assign={};
 const hist=D.HISTORICAL[scenario][side];
 spec.roles.forEach((r,i)=>{
  const current=card(existing[r.id]);let pick=current&&D.eligible(current,scenario,side,mode)&&!used.has(current.id)?current:null;
  if(!pick){const h=card(hist[i]);if(h&&D.eligible(h,scenario,side,mode)&&!used.has(h.id))pick=h;}
  if(!pick)pick=D.CARDS.filter(c=>!used.has(c.id)&&D.eligible(c,scenario,side,mode)).sort((a,b)=>D.fit(b,r)-D.fit(a,r)||a.id.localeCompare(b.id))[0];
  if(pick){assign[r.id]=pick.id;used.add(pick.id);}
 });
 const reserves=D.CARDS.filter(c=>!used.has(c.id)&&D.eligible(c,scenario,side,mode)).sort((a,b)=>b.stats.command-a.stats.command||a.id.localeCompare(b.id)).slice(0,reserveCount).map(c=>c.id);
 return {assign,reserves};
}
function validateRoster(scenario,side,assign,reserves=[],mode='free'){
 const s=D.SCENARIOS[scenario];if(!s||!s.sides.some(x=>x.id===side))throw new Error('ด่านหรือฝ่ายไม่ถูกต้อง');
 const ids=[];for(const r of s.roles){const c=card(assign?.[r.id]);if(!c)throw new Error('ยังไม่ได้เลือก '+r.name);if(!D.eligible(c,scenario,side,mode))throw new Error(c.name+(D.enemyDeployed(scenario,side).includes(c.id)?' ประจำฝ่ายตรงข้าม เลือกไม่ได้':' ไม่อยู่ในเงื่อนไขตามยุค'));ids.push(c.id);}
 if(reserves.length>(D.SCENARIOS[scenario].reserveMax||(scenario==='chibi'?8:4)))throw new Error('จำนวนขุนพลสำรองเกินกำหนด');
 for(const id of reserves){const c=card(id);if(!c||!D.eligible(c,scenario,side,mode))throw new Error('ขุนพลสำรองไม่ถูกต้อง');ids.push(id);}
 if(new Set(ids).size!==ids.length)throw new Error('ขุนพลหนึ่งคนรับได้หนึ่งตำแหน่งหรือหนึ่งที่สำรอง');return true;
}
function event(sim,type,title,text,meta={}){
 const e={id:'e'+(++sim.eventSerial),time:sim.time,type,title,text,...meta};if(sim.campaign){sim.eventArchive=sim.eventArchive||[];sim.eventArchive.push(e);}sim.events.unshift(e);if(sim.events.length>600)sim.events.length=600;return e;
}
function supplyDays(u){return u.troops>0?u.rations/u.troops:0;}
function findRoute(sim,from,to,{avoidEnemy=false,side=null,landOnly=false,waterOnly=false,avoidKnownThreats=false}={}){
 if(from===to)return[from];const nodes=sim.nodes;const scores=new Map([[from,0]]),prev=new Map(),q=new Set(nodes.map(n=>n.id));
 while(q.size){let id=null,best=Infinity;for(const v of q){const s=scores.get(v)??Infinity;if(s<best){best=s;id=v;}}if(!id)break;q.delete(id);if(id===to)break;
  for(const e of sim.edges){if(e.from!==id&&e.to!==id)continue;if(landOnly&&e.terrain==='water'||waterOnly&&e.terrain!=='water')continue;const next=e.from===id?e.to:e.from;if(!q.has(next))continue;const n=nodes.find(n=>n.id===next);const penalty=avoidEnemy&&n.owner!==side&&n.owner!=='neutral'?2.4:1;const known=avoidKnownThreats&&side?Object.values(sim.knowledge[side]||{}).filter(k=>sim.time-k.time<120&&dist(k,n)<100).reduce((sum,k)=>sum+k.troops,0):0;const s=best+e.distance*penalty+known/10;if(s<(scores.get(next)??Infinity)){scores.set(next,s);prev.set(next,id);}}
 }
 if(!prev.has(to))return[];const result=[to];while(result[0]!==from){result.unshift(prev.get(result[0]));if(result.length>nodes.length)return[];}return result;
}
function orderMove(sim,u,target,reason='เคลื่อนทัพ',options={}){
 if(!u||u.troops<=0||['destroyed','merged','building'].includes(u.status))return false;
 if(!sim.nodes.some(n=>n.id===target))return false;
 if(u.route.length>1&&u.target===target)return true;
 const moving=u.route.length>1;
 const start=moving?u.route[1]:u.nodeId;
 const tail=findRoute(sim,start,target,{side:u.side,avoidEnemy:u.type==='convoy',avoidKnownThreats:options.avoidKnownThreats===true,waterOnly:['naval','fire'].includes(u.type)||u.riverOnly===true});
 if(!tail.length)return false;
 if(moving){u.route=[u.route[0],...tail];}else{u.route=tail;u.edgeProgress=0;}
 u.target=target;u.order=reason;u.status=u.route.length>1?'moving':'holding';
 if(u.route.length===1){u.route=[];u.target=null;}return true;
}
function nearestNode(sim,u,fn=()=>true){return sim.nodes.filter(n=>n.type!=='transit'&&fn(n)).sort((a,b)=>dist(a,u)-dist(b,u))[0];}
function spawnNpc(sim,id,side,role){const c=card(id),npc=E.createNpc({id,seed:sim.seed,name:c.name});E.applyPreset(npc,c.preset);npc.side=side;npc.role=role;sim.npcs[id]=npc;return npc;}
function createUnit(sim,id,side,role,commander,nodeId,troops,type){const n=sim.nodes.find(n=>n.id===nodeId);const u={id,side,role,commanderId:commander,name:roleName(role),type,troops,initialTroops:troops,nodeId,x:n.x,y:n.y,route:[],edgeProgress:0,target:null,status:'holding',order:'รอคำสั่งและจัดระเบียบ',morale:82,fatigue:7,cohesion:86,rations:troops*(role==='vanguard'?1.2:role==='logistics'?3:1.8),ammo:100,lastDecision:-1000,decision:null,parentId:null,isDetachment:false,firePreparation:0,fireCharges:0,burning:0,lastSeen:{},sick:type==='naval'&&side==='wei'?6:0,commandLocked:false,fleetSpacing:side==='wei'?20:60,spacingTarget:side==='wei'?20:60,firefightUntil:0,medicalUntil:0};sim.units.push(u);return u;}
function createSimulation({scenario='chibi',side='allied',assign=null,reserves=[],seed=208,mode='free',doctrine='balanced',pressure=.6}={}){
 if(!D.SCENARIOS[scenario])throw new Error('ด่านไม่ถูกต้อง');
 if(D.SCENARIOS[scenario]?.campaign){const K=root.LongCampaign||(typeof require==='function'?require('./long-campaign'):null);return K.createSimulation({scenario,side:side==='allied'?'shu':side,assign,reserves,seed,mode,doctrine,years:arguments[0]?.years||D.SCENARIOS[scenario].yearOptions[0]});}
 if(!assign){const a=autoRoster(scenario,side,mode==='free'?'era':mode);assign=a.assign;reserves=a.reserves;}
 validateRoster(scenario,side,assign,reserves,mode);
 const spec=D.SCENARIOS[scenario],opponent=spec.sides.find(s=>s.id!==side).id,map=M.getMap(scenario);
 const sim={version:VERSION,scenario,side,opponent,pressure:clamp(Number(pressure)||.6,.4,1.4),seed:Number.isFinite(Number(seed))?Number(seed):0,mode,rng:E.createRng(Number.isFinite(Number(seed))?Number(seed):0,'living-battle-v02'),time:0,status:'ready',outcome:null,nodes:map.nodes,edges:map.edges,npcs:{},units:[],camps:[],convoys:[],events:[],eventSerial:0,nextId:0,assignments:{[side]:{...assign}},reserves:{[side]:[...reserves]},doctrines:{[side]:doctrine,[opponent]:'balanced'},metrics:{losses:{[side]:0,[opponent]:0},campBuilt:0,detached:0,convoysDelivered:0,convoysLost:0,fireAttacks:0,fireSpread:0,firefightingMinutes:0,medicalCareMinutes:0,rationsConsumed:0},initialTotals:{},initialNavalTotals:{},initialSiegeThreat:0,knowledge:{[side]:{},[opponent]:{}},weather:{wind:'NW',strength:2,rain:false,temperature:14},hqControl:{},objectiveProgress:{},objectives:{},counterfactualNotes:[],serial:{},navalDoctrine:{[side]:'balanced',[opponent]:'balanced'}};
 const enemy=D.fixedRoster(scenario,opponent);
 sim.assignments[opponent]=enemy.assign;sim.reserves[opponent]=enemy.reserves;
 for(const s of[side,opponent]){
  const team=sim.assignments[s];for(const [role,id]of Object.entries(team))spawnNpc(sim,id,s,role);for(const id of sim.reserves[s])spawnNpc(sim,id,s,'reserve_officer');
  const ids=[...Object.values(team),...sim.reserves[s]];for(const a of ids)for(const b of ids)if(a!==b)E.setRelationship(sim.npcs[a],b,{trust:card(a).faction===card(b).faction?78:60,respect:70,loyalty:75,rivalry:0,role:b===team.supreme?'liege':'peer'});
  if(ids.includes('gan_ning')&&ids.includes('ling_tong')){E.setRelationship(sim.npcs.gan_ning,'ling_tong',{trust:25,rivalry:80,respect:60});E.setRelationship(sim.npcs.ling_tong,'gan_ning',{trust:15,rivalry:90,respect:52});}
  let starts,types,counts;
  if(scenario==='chibi'){
   const ally=s==='allied';starts=ally?['chibi','chibi','chibi','fankou','south_grain','hidden_cove','south_cliff','east_landing','south_reserve','west_landing','nanping','chaisang','chibi','east_landing','south_wood','xiakou']:['wulin','wulin','north_port','north_east','north_grain','north_port','west_watch','east_port','north_east','east_port','north_medical','east_depot','wulin','north_port','cavalry_ridge','jiangling'];
   types=['infantry','scout','naval','infantry','support',ally?'fire':'naval','archers','naval','infantry','scout','engineer','support','guard','naval','cavalry','infantry'];
   counts=[6500,1000,8000,6000,1500,2500,3000,3000,4000,900,900,1200,1500,3500,1800,2200].map(n=>ally?n:Math.round(n*2.1));
  }else{
   const cao=s==='cao';starts=cao?['staging','staging','wuyang','staging','boma','west_road','staging','guandu']:['yuan_hq','yuan_hq','siege_west','siege_east','yuan_reserve','north_ford','siege_west','yuan_grain'];
   types=['infantry','scout','cavalry','cavalry','infantry','scout','engineer','support'];counts=[2600,400,1600,1200,1600,350,500,650].map(n=>cao?n:Math.round(n*2.4));
  }
  spec.roles.forEach((r,i)=>createUnit(sim,s+'_'+r.id,s,r.id,team[r.id],starts[i],s===opponent?Math.round(counts[i]*sim.pressure):counts[i],types[i]));
  sim.initialTotals[s]=sim.units.filter(u=>u.side===s).reduce((sum,u)=>sum+u.troops,0);sim.initialNavalTotals[s]=sim.units.filter(u=>u.side===s&&['naval','fire'].includes(u.type)).reduce((sum,u)=>sum+u.troops,0);
 }
 for(const n of sim.nodes){n.stock=n.type==='depot'?60000:n.type==='hq'?30000:n.type==='port'?18000:0;n.control=0;n.originalOwner=n.owner;}
 for(const n of sim.nodes.filter(n=>['hq','depot'].includes(n.type))){sim.camps.push({id:'camp_'+n.id,nodeId:n.id,x:n.x+30,y:n.y+24,side:n.owner,name:'ค่าย'+n.name,progress:100,defense:n.defense,stock:0,initial:true,createdAt:0,commanderId:sim.assignments[n.owner]?.supreme,burning:0});}
 if(scenario==='boma'){const city=sim.nodes.find(n=>n.id==='boma');sim.initialSiegeThreat=sim.units.filter(u=>u.side==='yuan'&&dist(u,city)<300).reduce((sum,u)=>sum+u.troops,0);}
 sim.status='running';operations().init(sim);
 event(sim,'briefing','เปิดสมรภูมิ'+spec.name,'กำลังพลและระยะทางเป็นค่าจำลองเพื่อการเล่น ขุนพลตัดสินใจจากตัวตน ข่าวที่พบ เสบียง และความเสี่ยง ผู้เล่นเปลี่ยนเจตนารมณ์ได้ แต่การสั่งการระดับหน่วยเป็นอิสระ',{side});
 event(sim,'history','เริ่มนับเวลาเป็นนาที','หนึ่งวันมี 24 ชั่วโมง การเคลื่อนทัพและขบวนเสบียงคำนวณตำแหน่งทุกนาที',{side});
 updateSight(sim);checkOutcome(sim,0);return sim;
}
function logDecision(sim,u,scored){
 const chosen=scored[0];u.decision={time:sim.time,action:chosen.id.replace('lb2_',''),label:chosen.label||ACTIONS.find(a=>'lb2_'+a[0]===chosen.id)?.[1],score:chosen.score,contributions:chosen.decisionContributions,options:scored.slice(0,4).map(o=>({id:o.id,label:o.label,score:o.score,contributions:o.decisionContributions})),reason:chosen.reason};u.lastDecision=sim.time;
 const npc=sim.npcs[u.commanderId];if(u.lastAction!==chosen.id||sim.time-(u.lastReport||0)>180){
  event(sim,'decision',npc.name+' • '+u.decision.label,chosen.reason,{side:u.side,unitId:u.id,npcId:npc.id,nodeId:u.nodeId,decision:JSON.parse(JSON.stringify(u.decision))});u.lastReport=sim.time;
 }
 u.lastAction=chosen.id;return u.decision.action;
}
function chooseTarget(sim,u,flank=false){
 const enemies=Object.values(sim.knowledge[u.side]).filter(e=>e.troops>0&&sim.time-e.time<120);
 const naval=['naval','fire'].includes(u.type);
 const objectives=sim.nodes.filter(n=>n.type!=='transit'&&(n.owner!==u.side||n.type==='hq'&&enemies.some(e=>dist(e,n)<300))&&(naval?['port','hq','channel','shoal'].includes(n.type):n.type!=='channel'&&n.terrain!=='water'));
 const origin=u.route.length>1?u.route[1]:u.nodeId;
 let options=objectives.map(n=>{const path=findRoute(sim,origin,n.id,{waterOnly:naval});const distance=path.length?path.slice(1).reduce((d,id,i)=>d+dist(sim.nodes.find(n=>n.id===path[i]),sim.nodes.find(n=>n.id===id)),0):1e9;const hostile=enemies.filter(e=>dist(e,n)<90).reduce((s,e)=>s+e.troops,0);return{n,reachable:path.length>0,score:distance+hostile/22-(n.value||1)*30-(n.owner===u.side&&n.type==='hq'?450:0)+(flank&&n.type==='hq'?150:0)};});
 options=options.filter(o=>o.reachable);options.sort((a,b)=>a.score-b.score);return options[0]?.n;
}
function canBuild(sim,u){if(!u||u.troops<=0||sim.units.some(v=>v.side!==u.side&&v.troops>0&&dist(u,v)<100))return false;if(sim.campaign){const n=sim.nodes.find(n=>n.id===u.nodeId);return !!n&&n.owner===u.side&&n.campable&&!u.route.length&&u.materials>=80&&supplyDays(u)>12&&!sim.camps.some(c=>c.nodeId===n.id)&&u.troops>0&&!['engaged','destroyed','merged','building'].includes(u.status);}const n=sim.nodes.find(n=>n.id===u.nodeId);return !!n&&n.campable&&n.owner===u.side&&!u.route.length&&!sim.camps.some(c=>c.nodeId===n.id)&&u.troops>=400&&u.rations>=1000&&!['engaged','destroyed','merged','building'].includes(u.status);}
function constructCamp(sim,u){
 if(sim.campaign)return (root.LongCampaign||require('./long-campaign')).buildCamp(sim,u);
 if(!canBuild(sim,u))return false;const n=sim.nodes.find(n=>n.id===u.nodeId),c={id:'camp_new_'+(++sim.nextId),nodeId:n.id,x:n.x+30,y:n.y+25,side:u.side,name:'ค่าย'+n.name,progress:0,defense:8,stock:Math.min(1000,u.rations*.18),initial:false,createdAt:sim.time,commanderId:u.commanderId,burning:0};u.rations-=c.stock;operations().ensureCamp(c);sim.camps.push(c);u.order='สร้าง'+c.name;u.buildCamp=c.id;u.status='building';event(sim,'camp',sim.npcs[u.commanderId].name+' เริ่มตั้งค่ายที่'+n.name,'แบ่งงานขุดคู ปักรั้ว ตั้งหอสังเกต และเก็บเสบียง '+Math.round(c.stock).toLocaleString()+' หน่วยจากทัพ ค่ายต้องใช้เวลาก่อสร้าง',{side:u.side,unitId:u.id,nodeId:n.id,npcId:u.commanderId});return c;
}
function freeOfficers(sim,side){const assigned=new Set(sim.units.filter(u=>u.troops>0&&u.status!=='merged').map(u=>u.commanderId));return sim.reserves[side].filter(id=>!assigned.has(id));}
function splitUnit(sim,parent,count,officerId,target=null){
 count=Math.floor(Number(count));if(!Number.isFinite(count)||!parent||!sim.units.includes(parent)||parent.troops-count<400||count<250||parent.route.length||parent.retreating||['engaged','building','merged','destroyed','preparing'].includes(parent.status)||!freeOfficers(sim,parent.side).includes(officerId))return null;
 const ratio=count/parent.troops,rations=parent.rations*ratio,initial=parent.initialTroops*ratio,wounded=Number.isFinite(parent.wounded)?Math.min(count,Math.round(parent.wounded*ratio)):null,materials=Number.isFinite(parent.materials)?parent.materials*ratio:null;parent.troops-=count;parent.rations-=rations;parent.initialTroops-=initial;if(wounded!==null)parent.wounded-=wounded;if(materials!==null)parent.materials-=materials;
 const u={...JSON.parse(JSON.stringify(parent)),id:'det_'+(++sim.nextId),commanderId:officerId,name:'หน่วยแยก '+sim.npcs[officerId].name,role:'detachment',troops:count,initialTroops:initial,rations,route:[],target:null,parentId:parent.id,isDetachment:true,decision:null,lastAction:null,lastDecision:-1000,lastReport:0,fireCharges:0,firePreparation:0,commandLocked:false,buildCamp:null};if(sim.campaign){Object.assign(u,{wounded:wounded||0,materials:materials||0,duty:'infantry',task:null,taskUntil:sim.time,plan:null,planGoal:null});}sim.units.push(u);sim.npcs[officerId].role='detachment';sim.metrics.detached++;
 if(target)orderMove(sim,u,target,'ภารกิจหน่วยแยก');event(sim,'detachment',u.name+' รับกำลัง '+count.toLocaleString()+' นาย','แยกจาก'+parent.name+' ของ'+sim.npcs[parent.commanderId].name+' คงเหลือ '+parent.troops.toLocaleString()+' นาย กำลังและเสบียงถูกแบ่งจากทัพเดิมจริง',{side:u.side,unitId:u.id,npcId:officerId,nodeId:parent.nodeId});return u;
}
function mergeUnit(sim,u){const p=sim.units.find(p=>p.id===u.parentId);if(!p||p.troops<=0||u.troops<=0||u.route.length||p.route.length||dist(p,u)>60)return false;const total=p.troops+u.troops;for(const key of['morale','fatigue','cohesion','sick','training'])if(Number.isFinite(p[key])&&Number.isFinite(u[key]))p[key]=(p[key]*p.troops+u[key]*u.troops)/total;p.initialTroops+=u.initialTroops;for(const key of['wounded','materials'])if(Number.isFinite(u[key])){p[key]=(p[key]||0)+u[key];u[key]=0;}p.troops=total;p.rations+=u.rations;u.troops=0;u.rations=0;u.initialTroops=0;u.status='merged';sim.npcs[u.commanderId].role='reserve_officer';event(sim,'detachment','หน่วยแยกกลับเข้าทัพ',u.name+' รวมกลับกับ'+p.name,{side:u.side,unitId:p.id,npcId:u.commanderId,nodeId:p.nodeId});return true;}
function supplyBase(sim,u){const naval=['naval','fire'].includes(u.type),origin=u.route.length>1?u.route[1]:u.nodeId;return nearestNode(sim,u,n=>n.owner===u.side&&(n.stock>100||sim.camps.some(c=>c.side===u.side&&c.nodeId===n.id&&c.progress>=100&&c.stock>100))&&['depot','port','hq'].includes(n.type)&&findRoute(sim,origin,n.id,{waterOnly:naval}).length>0);}
function retreatBase(sim,u){const waterOnly=['naval','fire'].includes(u.type),origin=u.route.length>1?u.route[1]:u.nodeId,known=Object.values(sim.knowledge[u.side]||{}).filter(k=>sim.time-k.time<120);return nearestNode(sim,u,n=>n.owner===u.side&&['depot','hq','port'].includes(n.type)&&!known.some(k=>dist(k,n)<130)&&findRoute(sim,origin,n.id,{waterOnly}).length>0);}
function think(sim,u){
 if(u.troops<=0||['merged','building','routed'].includes(u.status)||u.retreating||u.recoverUntil>sim.time)return;
 if(u.route.length>1&&supplyDays(u)>.15&&u.morale>28)return;if(u.firefightUntil>sim.time)return;
 const npc=sim.npcs[u.commanderId],days=supplyDays(u),visible=Object.values(sim.knowledge[u.side]).filter(k=>sim.time-k.time<80&&dist(k,u)<250),support=sim.units.filter(a=>a.side===u.side&&a.id!==u.id&&a.troops>0&&dist(a,u)<230).reduce((sum,a)=>sum+a.troops*.6,0),site=sim.nodes.find(n=>n.id===u.nodeId),fort=(site?.owner===u.side&&!u.route.length?1+site.defense/65:1),pressure=visible.reduce((sum,e)=>sum+e.troops,0)/Math.max(1,u.troops+support)/fort,doctrine=sim.doctrines[u.side],offensive=doctrine==='aggressive'?15:doctrine==='cautious'?-13:0;
 const target=chooseTarget(sim,u),isRear=(['strategist','logistics','guard','rear'].includes(u.role)||u.role==='supreme'&&!(sim.scenario==='boma'&&u.side==='cao'))||(sim.scenario==='boma'&&u.side==='cao'&&u.role==='reserve'),isScout=['scout'].includes(u.type),isEngineer=u.type==='engineer';
 const opts=[];const add=(id,base,reason,risk=35)=>{const a=ACTIONS.find(a=>a[0]===id);opts.push({id:'lb2_'+id,label:a[1],baseScore:base,situationalBias:0,riskLevel:risk,reason});};
 const fortified=sim.nodes.find(n=>n.id===u.nodeId)?.type==='hq'&&!u.route.length&&isRear;
 add('hold',(isRear?60:16)+(fortified?45:0),'ประเมินกำลังที่เห็น '+Math.round(pressure*100)+'% ของหน่วยตน รักษาขวัญ '+Math.round(u.morale)+' และการประสานกำลัง');
 if(target&&!isRear){add('attack',39+offensive+(sim.time>180?10:0)-Math.max(0,pressure-1)*18,'เป้าหมาย '+target.name+' ข้อมูลข้าศึกในระยะ '+visible.length+' กอง เสบียง '+days.toFixed(1)+' วัน');add('flank',31+offensive-(pressure>2?10:0),'ค้นช่องโหว่รอบ '+target.name+' เพื่อลดการปะทะซึ่งหน้า',25);}
 if(days<1.25||u.fatigue>55)add('resupply',days<.35?160:days<.8?100:30+u.fatigue*.45,'เสบียงเหลือ '+days.toFixed(2)+' วัน ความล้า '+Math.round(u.fatigue)+' จึงชั่งน้ำหนักการรักษากำลัง',8);
 if(u.morale<33||pressure>2.6||days<.12)add('retreat',u.morale<25||days<.12?180:60+(pressure-2)*25,'กำลังข้าศึกที่พบสูงกว่า หรือขวัญและเสบียงต่ำ ต้องลดความเสี่ยงเสียทั้งหน่วย',10);
 if(isScout)add('recon',58,'ใช้หน่วยเบาเปิดข้อมูลที่มั่นและเส้นทางก่อนให้ทัพหลักเคลื่อน',18);
 if(canBuild(sim,u))add('camp',(isEngineer?108:sim.time>90?38:12)+operations().campNeed(sim,u)+(u.fatigue>25?20:0),'พื้นที่ '+sim.nodes.find(n=>n.id===u.nodeId).name+' ตั้งค่ายได้ ใช้เสบียงจากทัพและแรงงานจริง',10);
 if(sim.scenario==='chibi'){
  const naval=['naval','fire'].includes(u.type),policy=sim.navalDoctrine[u.side],nearFire=sim.units.some(v=>v.side===u.side&&v.troops>0&&v.burning>10&&dist(u,v)<130)||sim.camps.some(c=>c.side===u.side&&c.burning>10&&dist(u,c)<130);
  if(!u.route.length&&(u.burning>5||nearFire)&&days>.2)add('firefight',u.burning>20?210:132,'มีไฟในระยะจริง แบ่งกำลังดับไฟ 45 นาที ลดกำลังรบระหว่างช่วยเหลือ',15);
  if(naval&&u.type!=='fire'&&u.fleetSpacing<80&&(policy==='dispersed'||sim.weather.wind==='SE'&&visible.length||nearFire))add('disperse',policy==='dispersed'?110:nearFire?160:92,'รักษาช่องว่างระหว่างเรือ ลดไฟลาม แต่กำลังประสานและความเร็วลดลง',12);
  if(naval&&u.type!=='fire'&&u.fleetSpacing>35&&policy==='compact'&&!nearFire)add('formup',90,'เน้นกำลังประสานรบ เรือใกล้กันมากขึ้นจึงเสี่ยงไฟลาม',30);
  if(u.sick>8||u.medicalUntil>sim.time)add('medical',u.sick>18?145:88,'ลูกเรือป่วย '+Math.round(u.sick)+'% ต้องพักและดูแลในฐานฝ่ายตน',8);
 }
 if(sim.scenario==='chibi'&&u.type==='fire'){
  if(u.firePreparation<100)add('fireprepare',110,'จัดเชื้อเพลิงและฝึกเรือเข้าจู่โจม รอให้พร้อมก่อนเสี่ยงส่งกำลัง',15);
  if(u.firePreparation>=100&&u.fireCharges>0&&sim.weather.wind==='SE'&&!sim.weather.rain)add('fireattack',165,'ลมอาคเนย์พัดหนุน เรือพร้อม '+u.fireCharges+' ชุด โอกาสเข้าถึงกองเรือฝั่งเหนือเพิ่มขึ้น',65);
 }
 const mobilisation=operations().context(sim,u);if(mobilisation.dispatch)opts.push({id:'op_dispatch',label:'ส่งทัพย่อยจากฐานระดมพล',baseScore:145,riskLevel:25,reason:'ใช้'+mobilisation.base.name+' เป็นฐาน แบ่งกำลังจริงให้ขุนพลรอง'});else if(mobilisation.rally&&mobilisation.target)opts.push({id:'op_rally',label:'รวมกำลังที่ฐานระดมพล',baseScore:85,riskLevel:20,reason:'เตรียมคนและเสบียงที่'+mobilisation.target.name+' ก่อนส่งทัพย่อย'});
 const scored=E.scoreDecisionOptions(npc,opts,{time:sim.time/60,includeMemory:true,memoryScale:.35});const action=logDecision(sim,u,scored);
 if(action==='op_dispatch'){operations().dispatch(sim,u);return;}if(action==='op_rally'){if(mobilisation.target)orderMove(sim,u,mobilisation.target.id,'รวมกำลังที่'+mobilisation.target.name);return;}
 if(action==='firefight'){u.firefightUntil=sim.time+45;u.route=[];u.target=null;u.status='firefighting';u.order='แบ่งกำลังดับไฟและช่วยหน่วยใกล้เคียง';return;}
 if(action==='disperse'||action==='formup'){u.spacingTarget=action==='disperse'?90:20;u.status='holding';u.order=action==='disperse'?'กระจายกองเรือและจัดแนวกันไฟ':'รวมแนวกองเรือประสานรบ';return;}
 if(action==='medical'){u.medicalUntil=sim.time+90;const b=supplyBase(sim,u);if(b&&b.id!==u.nodeId)orderMove(sim,u,b.id,'กลับค่ายพักลูกเรือและแยกผู้ป่วย');else{u.status='recovering';u.order='พักรักษาและแยกผู้ป่วย';}return;}
 if(action==='camp'){constructCamp(sim,u);return;}
 if(action==='fireprepare'){u.status='preparing';u.order='เตรียมเรือเพลิงและรอทิศลม';return;}
 if(action==='hold'){u.status='holding';u.order='รักษา'+(sim.nodes.find(n=>n.id===u.nodeId)?.name||'แนวรบ');return;}
 if(action==='fireattack'){u.fireMission=true;orderMove(sim,u,'north_port','นำเรือเพลิงเข้าตีกองเรือเหนือ');event(sim,'fire','กองเรือเพลิงออกจากที่ตั้ง',npc.name+' สั่งออกเรือตามลมอาคเนย์ ต้องผ่านร่องน้ำจริงและอาจถูกสกัดก่อนถึงเป้าหมาย',{side:u.side,unitId:u.id,npcId:npc.id,nodeId:u.nodeId});return;}
 if(action==='resupply'||action==='retreat'){
  const base=action==='retreat'?retreatBase(sim,u):supplyBase(sim,u);if(base){orderMove(sim,u,base.id,action==='retreat'?'ถอนทัพกลับฐาน':'กลับเติมเสบียง');u.retreating=action==='retreat';}return;
 }
 if(action==='recon'){
  const choices=sim.nodes.filter(n=>n.id!==u.nodeId&&n.type!=='hq'&&n.type!=='transit'&&n.owner!==otherSide(sim,u.side)&&!visible.some(k=>dist(k,n)<100&&k.troops>u.troops*1.5)).sort((a,b)=>((sim.serial['seen_'+u.side+'_'+a.id]||-1000)+dist(a,u)*.6)-((sim.serial['seen_'+u.side+'_'+b.id]||-1000)+dist(b,u)*.6));const t=choices[0];if(t)orderMove(sim,u,t.id,'ลาดตระเวน '+t.name);return;
 }
 if(target)orderMove(sim,u,target.id,action==='flank'?'เข้าตีโอบปีก '+target.name:'เข้าตี '+target.name,{avoidKnownThreats:action==='flank'});
}
function move(sim,u,dt=1){
 if(u.troops<=0||u.status==='destroyed'||u.status==='merged'||u.status==='engaged'||u.route.length<2)return;
 let remaining=dt;
 for(let guard=0;guard<8&&remaining>0&&u.route.length>1;guard++){
 const a=sim.nodes.find(n=>n.id===u.route[0]),b=sim.nodes.find(n=>n.id===u.route[1]),edge=sim.edges.find(e=>(e.from===a.id&&e.to===b.id)||(e.to===a.id&&e.from===b.id));if(!edge){u.route=[];u.status='holding';break;}
 const c=card(u.commanderId),water=edge.terrain==='water';if(u.type==='convoy')u.waterborne=water;const speed=(u.type==='convoy'?(water?1.05:.65):water?1.05+(c?.stats.naval||50)*.007:u.type==='cavalry'?1.7:u.type==='scout'?1.55:.95)*(1-u.fatigue*.004)*(water&&sim.weather.rain?.8:1)*(u.retreating?1.12:1)*(water&&u.fleetSpacing>70?.88:1);
 const available=edge.distance*(1-u.edgeProgress),travel=speed*remaining;
 if(travel>=available){remaining-=available/speed;u.x=b.x;u.y=b.y;u.nodeId=b.id;u.route.shift();u.edgeProgress=0;sim.serial['seen_'+u.side+'_'+b.id]=sim.time;
  if(u.route.length<2){u.route=[];u.target=null;if(u.retreating)u.recoverUntil=sim.time+90;u.status=u.retreating?'recovering':'holding';u.retreating=false;
   if(u.type!=='convoy')event(sim,'movement',sim.npcs[u.commanderId].name+' ถึง'+b.name,u.name+' เคลื่อนกำลัง '+u.troops.toLocaleString()+' นายเข้าพื้นที่ ขวัญ '+Math.round(u.morale)+' เสบียง '+supplyDays(u).toFixed(1)+' วัน',{side:u.side,unitId:u.id,npcId:u.commanderId,nodeId:b.id});
  }
 }else{u.edgeProgress+=travel/edge.distance;u.x=a.x+(b.x-a.x)*u.edgeProgress;u.y=a.y+(b.y-a.y)*u.edgeProgress;remaining=0;}
 }
}
function updateSight(sim){
 for(const side of[sim.side,sim.opponent]){const scouts=sim.units.filter(u=>u.side===side&&u.troops>0);for(const e of sim.units.filter(u=>u.side!==side&&u.troops>0)){
  const seeing=scouts.find(s=>dist(s,e)<(s.type==='scout'?320:230));if(seeing){const first=!sim.knowledge[side][e.id];sim.knowledge[side][e.id]={id:e.id,x:e.x,y:e.y,time:sim.time,troops:e.troops,nodeId:e.nodeId,commanderId:e.commanderId};
   if(first)event(sim,'recon','พบ'+e.name,sim.npcs[seeing.commanderId].name+' รายงานทัพ '+sim.npcs[e.commanderId].name+' ประเมิน '+e.troops.toLocaleString()+' นาย ข้อมูลจะล้าสมัยเมื่อข้าศึกพ้นสายตา',{side,unitId:seeing.id,nodeId:seeing.nodeId});
  }
 }}
}
function launchConvoy(sim,side,target){
 if(sim.convoys.some(c=>c.side===side&&c.targetUnit===target.id&&!['delivered','lost'].includes(c.status)))return false;
 const river=['naval','fire'].includes(target.type),sources=sim.nodes.filter(n=>n.owner===side&&n.stock>500&&(river?['port','hq'].includes(n.type):n.type==='depot')).map(n=>({n,path:findRoute(sim,n.id,target.nodeId,{side,avoidEnemy:true,waterOnly:river})})).filter(x=>x.path.length&&(!river||sim.edges.some(e=>e.terrain==='water'&&(e.from===x.n.id||e.to===x.n.id)))).sort((a,b)=>dist(a.n,target)-dist(b.n,target));
 const source=sources[0];if(!source)return false;const depot=source.n,amount=Math.min(depot.stock,target.troops*2,25000);if(amount<250)return false;
 depot.stock-=amount;const c={id:'supply_'+(++sim.nextId),side,type:'convoy',commanderId:sim.assignments[side].transport,role:'convoy',troops:1,nodeId:depot.id,x:depot.x,y:depot.y,route:[],edgeProgress:0,target:null,targetUnit:target.id,cargo:amount,fatigue:0,status:'moving',order:'ลำเลียงให้'+target.name,waterborne:river,riverOnly:river};sim.convoys.push(c);orderMove(sim,c,target.nodeId,c.order);
 event(sim,'supply',(river?'เรือเสบียง':'ขบวนเสบียง')+' ออกจาก'+depot.name,'ขน '+Math.round(amount).toLocaleString()+' หน่วยให้'+target.name+' หักจากคลังจริง '+(river?'ใช้เส้นทางน้ำ':'ใช้เส้นทางที่เชื่อมถึงกัน'),{side,unitId:target.id,nodeId:depot.id});return c;
}

function updateLogistics(sim){
 for(const u of sim.units){if(u.troops<=0||u.status==='merged')continue;const consumption=u.troops/1440*(u.route.length?1.18:1);const actual=Math.min(u.rations,consumption);u.rations-=actual;sim.metrics.rationsConsumed+=actual;
  if(u.rations<=0){u.morale=clamp(u.morale-.028);u.cohesion=clamp(u.cohesion-.012);}
  if(u.route.length){u.fatigue=clamp(u.fatigue+.022);}else if(u.status!=='engaged'){u.fatigue=clamp(u.fatigue-.075);u.morale=clamp(u.morale+(u.recoverUntil>sim.time?.09:.012));}
  const n=sim.nodes.find(n=>n.id===u.nodeId);if(!u.route.length&&n.owner===u.side&&n.stock>0&&dist(n,u)<40){const amount=Math.min(n.stock,Math.max(0,u.troops*3-u.rations),u.troops*.012);u.rations+=amount;n.stock-=amount;}
  const camp=sim.camps.find(c=>c.nodeId===u.nodeId&&c.side===u.side&&c.progress>=100);if(camp&&!u.route.length){const amount=Math.min(camp.stock,Math.max(0,u.troops*2-u.rations),u.troops*.007);u.rations+=amount;camp.stock-=amount;u.fatigue=clamp(u.fatigue-.05);}
 }
 if(sim.time%60===1){for(const side of[sim.side,sim.opponent]){
  for(const u of sim.units.filter(u=>u.side===side&&u.troops>0&&supplyDays(u)<1.5).sort((a,b)=>supplyDays(a)-supplyDays(b)).slice(0,3))launchConvoy(sim,side,u);
 }}
 for(const c of sim.convoys){if(['delivered','lost'].includes(c.status))continue;move(sim,c);const target=sim.units.find(u=>u.id===c.targetUnit&&u.troops>0);const escort=sim.units.filter(u=>u.side===c.side&&u.troops>0&&dist(u,c)<90).reduce((sum,u)=>sum+u.troops,0),interceptor=sim.units.find(u=>u.side!==c.side&&u.troops>100&&u.troops>escort*.6&&dist(u,c)<28);
  if(interceptor){c.status='lost';sim.metrics.convoysLost++;const loot=Math.min(c.cargo,Math.max(0,interceptor.troops*4-interceptor.rations));interceptor.rations+=loot;sim.metrics.rationsLost+=c.cargo-loot;event(sim,'supply','ขบวนเสบียงถูกตัด',sim.npcs[interceptor.commanderId].name+' ยึดเสบียง '+Math.round(loot).toLocaleString()+' หน่วย เสบียงที่เหลือสูญหาย',{side:c.side,nodeId:c.nodeId});c.cargo=0;continue;}
  if(!target){sim.nodes.find(n=>n.id===c.nodeId).stock+=c.cargo;c.cargo=0;c.status='delivered';continue;}
  if(dist(c,target)<38){const amount=Math.min(c.cargo,Math.max(0,target.troops*4-target.rations));target.rations+=amount;c.cargo-=amount;if(c.cargo>0)sim.nodes.find(n=>n.id===c.nodeId).stock+=c.cargo;c.cargo=0;c.status='delivered';sim.metrics.convoysDelivered++;event(sim,'supply','ส่งเสบียงถึง'+target.name,'รับเสบียง '+Math.round(amount).toLocaleString()+' หน่วย เหลือใช้งาน '+supplyDays(target).toFixed(1)+' วัน',{side:c.side,unitId:target.id,nodeId:target.nodeId});}
  else if(!c.route.length)orderMove(sim,c,target.nodeId,'ติดตามกองทัพเพื่อส่งเสบียง');
 }
 if(sim.convoys.length>120)sim.convoys=sim.convoys.filter(c=>!['delivered','lost'].includes(c.status)).concat(sim.convoys.filter(c=>['delivered','lost'].includes(c.status)).slice(-30));
}
function lose(sim,u,n){n=Math.min(u.troops,Math.max(0,Math.round(n)));u.troops-=n;sim.metrics.losses[u.side]+=n;if(u.troops===0){u.status='destroyed';u.route=[];u.target=null;event(sim,'battle',u.name+' สูญเสียความสามารถรบ','กองทัพของ'+sim.npcs[u.commanderId].name+' ไม่เหลือกำลังที่จัดเป็นหน่วยรบได้',{side:u.side,unitId:u.id,npcId:u.commanderId,nodeId:u.nodeId});}return n;}
function power(sim,u){const c=card(u.commanderId),n=nearestNode(sim,u),near=dist(n,u)<65,water=u.route.length?sim.edges.find(e=>(e.from===u.route[0]&&e.to===u.route[1])||(e.to===u.route[0]&&e.from===u.route[1]))?.terrain==='water':n.terrain==='water'||n.terrain==='bank';return u.troops*(.45+c.stats.command/180+(water?Math.pow(c.stats.naval/100,2)*1.25:c.stats.martial/250))*(u.morale/100)*(.55+u.cohesion/220)*(1-u.fatigue/220)*(supplyDays(u)>.2?1:.58)*(1-u.sick/150)*(near&&n.owner===u.side?1+defenseAt(sim,n,u.side)/250:1)*(u.firefightUntil>sim.time?.65:1)*(water?1-(u.fleetSpacing||0)*.0012:1);}
function resolveCombat(sim){
 const active=sim.units.filter(u=>u.troops>0&&u.status!=='merged');const damage=new Map(),engaged=new Set();
 for(let i=0;i<active.length;i++)for(let j=i+1;j<active.length;j++){const a=active[i],b=active[j];if(a.side===b.side||dist(a,b)>48)continue;if(!a.retreating)engaged.add(a.id);if(!b.retreating)engaged.add(b.id);const pa=power(sim,a),pb=power(sim,b),shareA=active.filter(x=>x.side!==a.side&&dist(x,a)<48).length,shareB=active.filter(x=>x.side!==b.side&&dist(x,b)<48).length;
  damage.set(a.id,(damage.get(a.id)||0)+Math.max(.4,pb*.00125/shareB*(b.retreating?.35:1))*(0.8+sim.rng.next()*.4));damage.set(b.id,(damage.get(b.id)||0)+Math.max(.4,pa*.00125/shareA*(a.retreating?.35:1))*(0.8+sim.rng.next()*.4));
  const key=[a.id,b.id].sort().join(':');if(!sim.serial['battle_'+key]||sim.time-sim.serial['battle_'+key]>180){sim.serial['battle_'+key]=sim.time;event(sim,'battle',sim.npcs[a.commanderId].name+' ปะทะ '+sim.npcs[b.commanderId].name,'แนวรบใกล้'+nearestNode(sim,a).name+' • '+a.troops.toLocaleString()+' ต่อ '+b.troops.toLocaleString()+' นาย ขวัญและการส่งกำลังมีผลต่อการสูญเสีย',{side:a.side,unitId:a.id,nodeId:nearestNode(sim,a).id});}
 }
 for(const u of active){if(engaged.has(u.id)||damage.has(u.id)){if(!u.retreating)u.status='engaged';const n=lose(sim,u,damage.get(u.id)||0);u.morale=clamp(u.morale-n/Math.max(1,u.troops)*100*.7-.005);u.fatigue=clamp(u.fatigue+.07);u.cohesion=clamp(u.cohesion-.025);
   if(!u.retreating&&u.troops>0&&(u.morale<29||u.troops<u.initialTroops*.22)){const base=retreatBase(sim,u);const anchor=nearestNode(sim,u); // a stopped contact can lie between nodes: preserve x/y via connector distance below
    if(base){anchorReturn(sim,u,base.id);event(sim,'retreat',sim.npcs[u.commanderId].name+' สั่งถอนกำลัง','ขวัญ '+Math.round(u.morale)+' กำลังเหลือ '+u.troops.toLocaleString()+' นาย ถอนสู่'+base.name,{side:u.side,unitId:u.id,npcId:u.commanderId,nodeId:anchor.id});E.remember(sim.npcs[u.commanderId],'lb2_attack',-5,'เสียกำลังในการปะทะ จึงต้องถอนทัพ',sim.time/60,{importance:70});}
   }
  }else if(u.status==='engaged'){u.status=u.route.length?'moving':'holding';}
 }
}
// Returns through the current edge instead of teleporting a formation to an old node.
function anchorReturn(sim,u,target){
 const waterOnly=['naval','fire'].includes(u.type);
 if(u.route.length>1){
  const a=sim.nodes.find(n=>n.id===u.route[0]),b=sim.nodes.find(n=>n.id===u.route[1]),p=u.edgeProgress;
  const back=findRoute(sim,a.id,target,{waterOnly}),ahead=findRoute(sim,b.id,target,{waterOnly});
  const length=route=>route.slice(1).reduce((sum,id,i)=>sum+dist(sim.nodes.find(n=>n.id===route[i]),sim.nodes.find(n=>n.id===id)),0);
  const backCost=back.length?dist(a,b)*p+length(back):Infinity,aheadCost=ahead.length?dist(a,b)*(1-p)+length(ahead):Infinity;
  if(backCost<=aheadCost&&back.length){u.route=[b.id,...back];u.edgeProgress=1-p;u.nodeId=b.id;}
  else if(ahead.length)u.route=[a.id,...ahead];
  else return false;
  u.target=target;u.order='ถอนทัพรักษากำลัง';u.status='moving';
 }else if(!orderMove(sim,u,target,'ถอนทัพรักษากำลัง'))return false;
 u.retreating=true;return true;
}
function updateCamps(sim){
 for(const c of sim.camps){const workers=sim.units.filter(u=>u.buildCamp===c.id&&u.troops>0&&!u.route.length&&dist(u,c)<65&&u.status!=='engaged');if(c.progress<100&&workers.length){const progress=workers.reduce((s,u)=>s+(.45+card(u.commanderId).stats.logistics/100),0);c.progress=clamp(c.progress+progress);c.defense=8+c.progress*.22;if(c.progress>=100){sim.metrics.campBuilt++;for(const u of workers){u.buildCamp=null;u.status='holding';}event(sim,'camp',c.name+' พร้อมใช้งาน','คูและรั้วเสร็จแล้ว ช่วยการตั้งรับ พักทหาร และกระจายเสบียงที่เก็บไว้',{side:c.side,nodeId:c.nodeId,npcId:c.commanderId});}}

 }
}
function updateEnvironment(sim){
 if(sim.time%180===1){const roll=sim.rng.next();sim.weather.wind=roll<.34?'SE':roll<.7?'NW':roll<.86?'NE':'SW';sim.weather.strength=1+Math.floor(sim.rng.next()*4);sim.weather.rain=sim.rng.next()<.18;}
 const alive=sim.units.filter(u=>u.troops>0),firefighters=alive.filter(u=>u.firefightUntil>sim.time&&!u.route.length),spreaders=alive.filter(u=>u.burning>30).map(u=>({...u}));
 for(const u of alive){
  if(sim.scenario==='chibi'&&['naval','fire'].includes(u.type)){
   const desired=u.spacingTarget??60;u.fleetSpacing=clamp((u.fleetSpacing??60)+Math.sign(desired-(u.fleetSpacing??60))*Math.min(.8,Math.abs(desired-(u.fleetSpacing??60))));
   const crowded=alive.filter(v=>v.id!==u.id&&v.side===u.side&&dist(v,u)<100).length,care=!u.route.length&&u.status!=='engaged'&&sim.nodes.some(n=>n.owner===u.side&&n.stock>0&&dist(n,u)<60);
   if(care){const rate=u.medicalUntil>sim.time?.04:.012;u.sick=clamp(u.sick-rate);if(u.medicalUntil>sim.time)sim.metrics.medicalCareMinutes++;}
   else if(card(u.commanderId).stats.naval<70)u.sick=clamp(u.sick+.002+crowded*.0015);
  }
  if(u.type==='fire'&&u.status==='preparing'){u.firePreparation=clamp(u.firePreparation+.5+card(u.commanderId).stats.naval*.003);if(u.firePreparation>=100){u.fireCharges=2;u.status='holding';u.lastDecision=-1000;event(sim,'fire','เรือเพลิงเตรียมพร้อม',sim.npcs[u.commanderId].name+' เตรียมเรือได้ 2 ชุด รอลม ฝนและข่าวข้าศึก',{side:u.side,unitId:u.id,npcId:u.commanderId,nodeId:u.nodeId});}}
 }
 for(const u of alive){
  if(u.fireMission&&u.fireCharges>0){const victims=alive.filter(v=>v.side!==u.side&&dist(v,u)<100);if(victims.length){u.fireCharges--;u.fireMission=false;sim.metrics.fireAttacks++;const favorable=sim.weather.wind==='SE'&&!sim.weather.rain;for(const v of victims)v.burning=clamp(v.burning+(favorable?75:20)*(1-(v.fleetSpacing||0)*.006));for(const c of sim.camps.filter(c=>c.side!==u.side&&dist(c,u)<130))c.burning=favorable?75:15;event(sim,'fire','เรือเพลิงเข้าถึงแนวข้าศึก',sim.npcs[u.commanderId].name+' จุดไฟกระทบ '+victims.length+' กอง ระยะกระจายเรือและกำลังดับไฟมีผลต่อความเสียหาย',{side:u.side,unitId:u.id,npcId:u.commanderId,nodeId:u.nodeId});E.remember(sim.npcs[u.commanderId],'lb2_fireattack',favorable?5:-2,'ผลของเรือเพลิง',sim.time/60);}}
 }
 for(const u of alive){
  if(u.burning>0){const help=firefighters.filter(v=>v.side===u.side&&dist(v,u)<130).length,mitigation=card(u.commanderId).preset.personality.discipline;lose(sim,u,Math.max(1,u.troops*u.burning/100*.003)*(help?.55:1));u.morale=clamp(u.morale-.08);u.burning=clamp(u.burning-.15-mitigation*.003-(sim.weather.rain?.5:0)-help*.85);if(help)sim.metrics.firefightingMinutes++;}
  if(u.status==='firefighting'&&u.firefightUntil<=sim.time){u.status='holding';u.lastDecision=-1000;}
 }
 for(const c of sim.camps){if(c.burning>0){const help=firefighters.filter(v=>v.side===c.side&&dist(v,c)<130).length;const burnt=c.stock*.002;c.stock-=burnt;sim.metrics.rationsLost+=burnt;c.defense=Math.max(2,c.defense-.02);c.burning=Math.max(0,c.burning-.3-help*.9-(sim.weather.rain?.5:0));}}
 if(sim.scenario==='chibi'&&sim.time%5===0&&!sim.weather.rain)for(const a of spreaders)for(const u of alive){if(a.id===u.id||u.burning>10||dist(a,u)>85)continue;const risk=.16*(1-(u.fleetSpacing||0)/110)*(sim.weather.strength/4);if(sim.rng.next()<risk){u.burning=clamp(u.burning+30);sim.metrics.fireSpread++;if(sim.time-(sim.serial['spread_'+u.id]||-99)>45){sim.serial['spread_'+u.id]=sim.time;event(sim,'fire','ไฟลามถึง'+sim.npcs[u.commanderId].name,'ไฟจากหน่วยใกล้เคียงลามตามลม เรือกระจายและการดับไฟช่วยจำกัดความเสียหาย',{side:u.side,unitId:u.id,nodeId:u.nodeId});}}}
}

function captureNodes(sim){
 for(const n of sim.nodes){
  if(n.type==='transit')continue;
  const at=sim.units.filter(u=>u.troops>0&&!u.retreating&&!u.route.length&&dist(u,n)<55);
  const present=sim.units.filter(u=>u.troops>0&&!u.retreating&&dist(u,n)<55),sides=new Set(present.map(u=>u.side));
  if(sides.size!==1||!at.length){n.control=0;n.claimSide=null;continue;}
  const side=at[0].side;
  if(side===n.owner){n.control=0;n.claimSide=null;continue;}
  if(n.claimSide!==side){n.claimSide=side;n.control=0;}
  const force=at.reduce((sum,u)=>sum+u.troops,0);
  const needed=['hq','depot'].includes(n.type)?500:150;
  if(force<needed||operations().hostileCamp(sim,n.id,side)){n.control=0;continue;}
  n.control++;
  if(n.control>=30){const old=n.owner;n.owner=side;n.control=0;n.claimSide=null;event(sim,'capture',sideLabel(sim,side)+' ควบคุม'+n.name,'หน่วยของ'+sim.npcs[at[0].commanderId].name+' รักษาพื้นที่ต่อเนื่อง 30 นาทีจนเปลี่ยนการควบคุม'+(old==='neutral'?'':'จาก '+sideLabel(sim,old)),{side,nodeId:n.id,unitId:at[0].id});}
 }
}
function otherSide(sim,side){return side===sim.side?sim.opponent:sim.side;}
function sideLabel(sim,side){return D.SCENARIOS[sim.scenario].sides.find(s=>s.id===side)?.name||'พื้นที่กลาง';}
function totals(sim,side){const units=sim.units.filter(u=>u.side===side&&u.troops>0&&u.status!=='merged'),troops=units.reduce((s,u)=>s+u.troops,0);return{troops,losses:sim.metrics.losses[side],units:units.length,moving:units.filter(u=>u.route.length>1).length,morale:troops?units.reduce((s,u)=>s+u.morale*u.troops,0)/troops:0,rations:units.reduce((s,u)=>s+u.rations,0),stock:sim.nodes.filter(n=>n.owner===side).reduce((s,n)=>s+n.stock,0),camps:sim.camps.filter(c=>c.side===side).length,sites:sim.nodes.filter(n=>n.owner===side&&n.type!=='transit').length};}
function complete(sim,winner,reason){if(sim.status==='completed')return;sim.status='completed';sim.outcome={winner,reason,time:sim.time,result:winner===sim.side?'victory':winner?'defeat':'draw'};event(sim,'outcome',winner?sideLabel(sim,winner)+' ได้ชัย':'จบยุทธการโดยยังไม่ชี้ขาด',reason,{side:'all'});}
function effectiveFieldForce(sim,side,near=null,radius=Infinity,navalOnly=false){
 return sim.units.filter(u=>u.side===side&&u.troops>0&&u.status!=='merged'&&!u.retreating&&u.morale>=35&&(!navalOnly||['naval','fire'].includes(u.type))&&(!near||dist(u,near)<radius)).reduce((sum,u)=>sum+u.troops,0);
}
function campaignScore(sim,side){
 const sites=sim.nodes.filter(n=>n.type!=='transit'),weight=n=>['channel','shoal'].includes(n.type)?.3:(n.value||1);
 const home=sites.filter(n=>n.originalOwner===side),enemyHome=sites.filter(n=>n.originalOwner!==side&&n.originalOwner!=='neutral'),neutral=sites.filter(n=>n.originalOwner==='neutral');
 const sum=arr=>arr.reduce((v,n)=>v+weight(n),0),owned=arr=>sum(arr.filter(n=>n.owner===side));
 const force=totals(sim,side).troops/sim.initialTotals[side];
 return round(force*60+owned(home)/Math.max(1,sum(home))*25+owned(enemyHome)/Math.max(1,sum(enemyHome))*15+owned(neutral)/Math.max(1,sum(neutral))*5);
}
function checkOutcome(sim,elapsed=1){
 if(sim.status==='completed')return;
 for(const side of[sim.side,sim.opponent]){
  if(totals(sim,side).troops<sim.initialTotals[side]*.2){complete(sim,otherSide(sim,side),'ฝ่ายตรงข้ามสูญเสียกำลังจัดรูปขบวนรบเกิน 80%');return;}
 }
 const goal=(side,id,title,ready,details,required=180)=>{
  const key=side+':'+id,progress=ready?(sim.objectiveProgress[key]||0)+elapsed:0;
  sim.objectiveProgress[key]=progress;
  const g={id,title,ready,progress,required,details,completed:progress>=required};
  (sim.objectives[side]||(sim.objectives[side]=[])).push(g);return g;
 };
 sim.objectives={};
 const occupied=(n,side)=>n.owner===side&&effectiveFieldForce(sim,side,n,80)>=500&&effectiveFieldForce(sim,otherSide(sim,side),n,80)===0;
 for(const side of[sim.side,sim.opponent]){
  const targets=sim.nodes.filter(n=>n.type==='hq'&&n.originalOwner===otherSide(sim,side)&&(sim.scenario!=='boma'||side==='cao'||n.id==='boma'));
  const captured=targets.find(n=>occupied(n,side));
  const hq=goal(side,'hq','ยึด'+(sim.scenario==='boma'&&side==='yuan'?'เมืองไป๋หม่า':'ศูนย์บัญชาการฝ่ายตรงข้าม'),Boolean(captured),captured?'มีกำลังรักษา '+captured.name+' และไม่มีหน่วยข้าศึกขัดขวาง':'ต้องยึดพื้นที่และมีกำลังรบพร้อมอย่างน้อย 500 นาย');
  sim.hqControl[side]=hq.progress;
  if(hq.completed){complete(sim,side,'รักษา'+captured.name+' ต่อเนื่องครบ 180 นาที');return;}
 }
 if(sim.scenario==='boma'){
  const city=sim.nodes.find(n=>n.id==='boma'),threat=effectiveFieldForce(sim,'yuan',city,300),guard=effectiveFieldForce(sim,'cao',city,80);
  const lifted=city.owner==='cao'&&guard>=500&&threat<=sim.initialSiegeThreat*.25;
  const relief=goal('cao','relief','ช่วยไป๋หม่าและคลายวงล้อม',lifted,'ทัพปิดล้อมที่ยังพร้อมรบใกล้เมือง '+Math.round(threat).toLocaleString()+' นาย • เป้าหมายไม่เกิน '+Math.round(sim.initialSiegeThreat*.25).toLocaleString()+' นาย');
  if(relief.completed){complete(sim,'cao','ช่วยไป๋หม่า รักษาเมืองและลดทัพปิดล้อมต่อเนื่องครบ 180 นาที');return;}
 }else{
  const city=sim.nodes.find(n=>n.id==='chibi'),fleet=effectiveFieldForce(sim,'wei',null,Infinity,true),alliedFleet=effectiveFieldForce(sim,'allied',null,Infinity,true);
  const ready=city.owner==='allied'&&effectiveFieldForce(sim,'allied',city,80)>=500&&fleet<=sim.initialNavalTotals.wei*.35&&alliedFleet>=sim.initialNavalTotals.allied*.25;
  const naval=goal('allied','naval','ทำลายกำลังเรือและรักษาผาแดง',ready,'เรือฝ่ายเหนือที่ยังคุมแนวรบได้ '+Math.round(fleet).toLocaleString()+' นาย • เป้าหมายไม่เกิน '+Math.round(sim.initialNavalTotals.wei*.35).toLocaleString()+' นาย');
  if(naval.completed){complete(sim,'allied','ทำให้กองเรือเหนือเสียการควบคุมแนวรบ พร้อมรักษาผาแดงและกองเรือพันธมิตรต่อเนื่อง 180 นาที');return;}
 }
 if(sim.time>=D.SCENARIOS[sim.scenario].hours*60){const a=campaignScore(sim,sim.side),b=campaignScore(sim,sim.opponent),winner=Math.abs(a-b)<6?null:a>b?sim.side:sim.opponent;complete(sim,winner,'ถึงขีดเวลายุทธการ ประเมินกำลังคงเหลือ การรักษาฐานเดิม และการรุกยึดฐานฝ่ายตรงข้าม ('+sideLabel(sim,sim.side)+' '+a+' : '+sideLabel(sim,sim.opponent)+' '+b+')');}
}
function step(sim,minutes=1){
 if(sim?.campaign)return (root.LongCampaign||require('./long-campaign')).step(sim,minutes);
 if(!sim||sim.status==='completed')return sim;minutes=Math.floor(clamp(minutes,1,120));
 for(let k=0;k<minutes&&sim.status!=='completed';k++){
 sim.time++;updateEnvironment(sim);
 if(sim.time===1||sim.time%30===0){updateSight(sim);for(const u of sim.units)think(sim,u);}
 for(const u of sim.units)move(sim,u);updateLogistics(sim);resolveCombat(sim);updateCamps(sim);operations().update(sim);captureNodes(sim);
 if(sim.time%15===0)updateSight(sim);checkOutcome(sim,1);
 }
 return sim;
}
function clock(sim){if(sim.campaign)return (root.LongCampaign||require('./long-campaign')).clock(sim);const minutes=sim.time+360,day=Math.floor(minutes/1440)+1;return{day,hour:Math.floor(minutes%1440/60),minute:Math.floor(minutes%60),text:'วันที่ '+day+' · '+String(Math.floor(minutes%1440/60)).padStart(2,'0')+':'+String(Math.floor(minutes%60)).padStart(2,'0')};}
const api={VERSION,E,D,M,createSimulation,step,autoRoster,validateRoster,findRoute,orderMove,constructCamp,canBuild,splitUnit,mergeUnit,freeOfficers,supplyDays,totals,clock,sideLabel,dist,card,event,campaignScore,sideColor,defenseAt,getOps:operations,diagnostics:{power,resolveCombat,captureNodes,checkOutcome,anchorReturn,think,effectiveFieldForce,retreatBase,updateEnvironment,launchConvoy}};root.LivingBattle=api;if(typeof module==='object')module.exports=api;
})(typeof globalThis!=='undefined'?globalThis:this);
