'use strict';
const A=require('node:assert/strict'),C=require('../src/battle-core');let count=0;
function test(name,fn){fn();console.log('PASS '+name);count++;}
function isolate(sim,list){sim.units=list;for(const side of[sim.side,sim.opponent]){sim.initialTotals[side]=list.filter(u=>u.side===side).reduce((s,u)=>s+u.troops,0);sim.metrics.losses[side]=0;}return sim;}
test('180 occupation minutes mean exactly 3 hours, with a stationed field force',()=>{
 const s=C.createSimulation(),hq=s.nodes.find(n=>n.id==='wulin'),a=s.units.find(u=>u.side===s.side),b=s.units.find(u=>u.side!==s.side);a.x=hq.x;a.y=hq.y;a.nodeId=hq.id;a.route=[];b.x=9999;b.y=9999;hq.owner=s.side;isolate(s,[a,b]);
 for(let i=1;i<180;i++){s.time=i;C.diagnostics.checkOutcome(s,1);A.notEqual(s.status,'completed');}s.time=180;C.diagnostics.checkOutcome(s,1);A.equal(s.status,'completed');A.equal(s.outcome.winner,s.side);
});
test('occupation timer resets when an opposing field force contests the headquarters',()=>{
 const s=C.createSimulation(),hq=s.nodes.find(n=>n.id==='wulin'),a=s.units.find(u=>u.side===s.side),b=s.units.find(u=>u.side!==s.side);a.x=hq.x;a.y=hq.y;a.nodeId=hq.id;hq.owner=s.side;b.x=9999;b.y=9999;isolate(s,[a,b]);for(let i=0;i<100;i++)C.diagnostics.checkOutcome(s,1);A.equal(s.hqControl[s.side],100);b.x=hq.x;b.y=hq.y;C.diagnostics.checkOutcome(s,1);A.equal(s.hqControl[s.side],0);A.notEqual(s.status,'completed');
});
test('a new claimant cannot inherit another side’s partial capture progress',()=>{
 const s=C.createSimulation({scenario:'boma',side:'cao'}),n=s.nodes.find(n=>n.id==='east_wood'),a=s.units.find(u=>u.side===s.side),b=s.units.find(u=>u.side!==s.side);a.x=n.x;a.y=n.y;a.route=[];b.x=9999;b.y=9999;isolate(s,[a,b]);for(let i=0;i<20;i++)C.diagnostics.captureNodes(s);A.equal(n.control,20);a.x=9999;a.y=9999;b.x=n.x;b.y=n.y;b.route=[];for(let i=0;i<10;i++)C.diagnostics.captureNodes(s);A.equal(n.owner,'neutral');A.equal(n.control,10);for(let i=0;i<20;i++)C.diagnostics.captureNodes(s);A.equal(n.owner,b.side);
});
test('one enemy’s damage budget is shared, rather than duplicated against four formations',()=>{
 const s=C.createSimulation(),friends=s.units.filter(u=>u.side===s.side).slice(0,4),enemy=s.units.find(u=>u.side!==s.side);for(const u of[...friends,enemy]){u.x=1100;u.y=1000;u.route=[];u.nodeId='south_grain';u.morale=85;u.troops=5000;u.initialTroops=5000;u.rations=15000;u.status='holding';}isolate(s,[...friends,enemy]);const budget=C.diagnostics.power(s,enemy)*.00125;C.diagnostics.resolveCombat(s);const received=s.metrics.losses[s.side];A.ok(received>0);A.ok(received<=budget*1.2+friends.length,'a single enemy does not gain four firing budgets');
});
test('retreating formations remain vulnerable to enemy attacks',()=>{
 const s=C.createSimulation(),a=s.units.find(u=>u.side===s.side),b=s.units.find(u=>u.side!==s.side);for(const u of[a,b]){u.x=1100;u.y=1000;u.route=[];u.nodeId='south_grain';u.troops=5000;u.initialTroops=5000;}a.retreating=true;isolate(s,[a,b]);const before=a.troops;C.diagnostics.resolveCombat(s);A.ok(a.troops<before);A.notEqual(a.status,'engaged');
});
test('withdrawal reverses the current edge without creating transit nodes or teleporting',()=>{
 const s=C.createSimulation(),u=s.units.find(u=>u.side===s.side&&u.role==='field'),a=s.nodes.find(n=>n.id==='fankou'),b=s.nodes.find(n=>n.id==='east_landing');u.route=[a.id,b.id];u.nodeId=a.id;u.edgeProgress=.4;u.x=a.x+(b.x-a.x)*.4;u.y=a.y+(b.y-a.y)*.4;const p={x:u.x,y:u.y},nodes=s.nodes.length;A.ok(C.diagnostics.anchorReturn(s,u,a.id));A.deepEqual({x:u.x,y:u.y},p);A.equal(s.nodes.length,nodes);A.deepEqual(u.route,[b.id,a.id]);A.ok(Math.abs(u.edgeProgress-.6)<1e-9);
});
console.log(count+' regression groups passed.');
