
(function(globalScope) {
  "use strict";
  const __MODULES = {};
  const __CACHE = {};
  function __require(name) {
    if (__CACHE[name]) return __CACHE[name].exports;
    const m = { exports: {} };
    __CACHE[name] = m;
    __MODULES[name](m, m.exports, __require, globalScope);
    return m.exports;
  }
  __MODULES['utils'] = function(module, exports, require, globalThis) {
'use strict';

/**
 * Deterministic RNG, Hashing, Math Utilities, and Structured Engine Errors
 * Ensures 100% reproducible behavior across Node.js and Browser runtimes.
 */

const ENGINE_VERSION = '2.0.0';
const HUMAN_SCHEMA_VERSION = 1;
const EXTENSION_SCHEMA_VERSION = 1;

class NpcEngineError extends Error {
  constructor(code, message, details = {}) {
    super(message);
    this.name = 'NpcEngineError';
    this.code = code;
    this.details = details;
  }
}

const ERROR_CODES = Object.freeze({
  INVALID_NPC: 'ERR_INVALID_NPC',
  INVALID_ID: 'ERR_INVALID_ID',
  INVALID_AXIS: 'ERR_INVALID_AXIS',
  INVALID_SCHEMA: 'ERR_INVALID_SCHEMA',
  NEWER_SCHEMA: 'ERR_NEWER_SCHEMA',
  INVALID_CAPABILITY: 'ERR_INVALID_CAPABILITY',
  INVALID_ACTION_DEF: 'ERR_INVALID_ACTION_DEF',
  UNKNOWN_ACTION: 'ERR_UNKNOWN_ACTION',
  INVALID_OBSERVATION: 'ERR_INVALID_OBSERVATION',
  INVALID_OUTCOME: 'ERR_INVALID_OUTCOME',
  INVALID_GOAL: 'ERR_INVALID_GOAL',
  INVALID_KNOWLEDGE: 'ERR_INVALID_KNOWLEDGE',
  INVALID_TECHNIQUE: 'ERR_INVALID_TECHNIQUE',
  INVALID_SAVE: 'ERR_INVALID_SAVE',
  LOCKED_IDENTITY_MUTATION: 'ERR_LOCKED_IDENTITY_MUTATION'
});

function clamp(v, a = 0, b = 100) {
  return Math.max(a, Math.min(b, Number.isFinite(v) ? v : 50));
}

function clampStrict(v, a = 0, b = 100, fallback = 0) {
  return Math.max(a, Math.min(b, Number.isFinite(v) ? v : fallback));
}

function round(v) {
  const n = Math.round(v * 100) / 100;
  return n === 0 ? 0 : n;
}

function isObject(v) {
  return !!v && typeof v === 'object' && !Array.isArray(v);
}

/**
 * FNV-1a 32-bit deterministic string hash (exact match with Human Foundation v1)
 */
function hash(s) {
  let h = 2166136261;
  for (const c of String(s)) {
    h ^= c.charCodeAt(0);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

/**
 * Xorshift32 deterministic PRNG stream (exact match with Human Foundation v1)
 */
function random(seed) {
  let s = hash(seed) || 1;
  return () => {
    s ^= s << 13;
    s ^= s >>> 17;
    s ^= s << 5;
    return (s >>> 0) / 4294967296;
  };
}

/**
 * Creates a rich deterministic RNG object from a seed or wraps a custom RNG function.
 */
function createRng(seedOrFn, contextKey = '') {
  if (typeof seedOrFn === 'function') {
    return {
      next: () => clampStrict(seedOrFn(), 0, 0.999999999999, 0.5),
      fork: (subKey) => createRng(hash(String(subKey) + ':' + String(Math.floor(seedOrFn() * 1e9))))
    };
  }
  const baseSeed = contextKey ? `${String(seedOrFn)}:${String(contextKey)}` : String(seedOrFn ?? 0);
  const fn = random(baseSeed);
  return {
    next: () => clampStrict(fn(), 0, 0.999999999999, 0.5),
    fork: (subKey) => createRng(`${baseSeed}:${String(subKey)}`)
  };
}

/**
 * Exact 3-dice bell-curve roll from Human Foundation v1
 */
function rollValue(seed, axisId, min = 18, max = 94) {
  const r = random(String(seed) + ':' + String(axisId));
  return Math.round(min + ((r() + r() + r()) / 3) * (max - min));
}

function readPath(obj, path) {
  return path.split('.').reduce((o, k) => o?.[k], obj);
}

function setPath(target, path, value) {
  const keys = path.split('.');
  let p = target;
  for (const k of keys.slice(0, -1)) {
    if (!p[k] || typeof p[k] !== 'object') p[k] = {};
    p = p[k];
  }
  p[keys[keys.length - 1]] = value;
}

function deepClone(obj) {
  if (obj === null || typeof obj !== 'object') return obj;
  if (Array.isArray(obj)) return obj.map(deepClone);
  const out = {};
  for (const [k, v] of Object.entries(obj)) {
    out[k] = deepClone(v);
  }
  return out;
}

module.exports = {
  ENGINE_VERSION,
  HUMAN_SCHEMA_VERSION,
  EXTENSION_SCHEMA_VERSION,
  NpcEngineError,
  ERROR_CODES,
  clamp,
  clampStrict,
  round,
  isObject,
  hash,
  random,
  createRng,
  rollValue,
  readPath,
  setPath,
  deepClone
};

  };
  __MODULES['identity_core'] = function(module, exports, require, globalThis) {
'use strict';

/**
 * Canonical 68-Axis Human Foundation v1
 * Preserves 100% compatibility with NPC_Identity_Engine_ThreeKingdoms_v1:
 * - 8 Life Values
 * - 14 Personality Axes
 * - 14 Physical Capacities (11 human.body + 3 core.physiology)
 * - 12 Cognitive Capacities (2 top-level + 10 human.cognition)
 * - 6 Aptitude Domains
 * - 14 Interest Dimensions
 * - Exact FNV-1a / Xorshift32 seeding and fingerprint hashes
 */

const {
  HUMAN_SCHEMA_VERSION,
  NpcEngineError,
  ERROR_CODES,
  clamp,
  round,
  isObject,
  hash,
  random,
  rollValue,
  readPath,
  setPath
} = __require('utils');

const VERSION = HUMAN_SCHEMA_VERSION;

const VALUE_DIMENSIONS_8 = Object.freeze([
  { id: 'familyClan', nameTh: 'ครอบครัวและสายเลือด', labelEn: 'Family & Clan' },
  { id: 'sectDuty', nameTh: 'สำนักและส่วนรวม', labelEn: 'State/Faction Duty & Common Good' },
  { id: 'martialPeak', nameTh: 'วิถียุทธ์และมรรคาเต๋า', labelEn: 'Martial Way & Mastery' },
  { id: 'knowledgeCraft', nameTh: 'ความรู้และศาสตร์วิชา', labelEn: 'Knowledge & Craft' },
  { id: 'freedom', nameTh: 'อิสรภาพและวิถีเสรี', labelEn: 'Freedom & Autonomy' },
  { id: 'wealthResource', nameTh: 'ทรัพย์สินและทรัพยากร', labelEn: 'Wealth & Resources' },
  { id: 'powerStatus', nameTh: 'อำนาจและบารมี', labelEn: 'Power & Authority' },
  { id: 'honorLegacy', nameTh: 'เกียรติยศและการสืบทอด', labelEn: 'Honor & Legacy' }
]);

const PERSONALITY_AXES_14 = Object.freeze([
  { id: 'ambition', nameTh: 'ความทะเยอทะยาน', labelEn: 'Ambition' },
  { id: 'discipline', nameTh: 'วินัยและความเพียร', labelEn: 'Discipline' },
  { id: 'caution', nameTh: 'ความรอบคอบระแวดระวัง', labelEn: 'Caution' },
  { id: 'curiosity', nameTh: 'ความใฝ่รู้', labelEn: 'Curiosity' },
  { id: 'creativity', nameTh: 'ความคิดสร้างสรรค์', labelEn: 'Creativity' },
  { id: 'rationality', nameTh: 'ความเป็นเหตุเป็นผล', labelEn: 'Rationality' },
  { id: 'empathy', nameTh: 'ความเมตตาเห็นอกเห็นใจ', labelEn: 'Empathy' },
  { id: 'trustfulness', nameTh: 'ความเปิดใจไว้ใจผู้อื่น', labelEn: 'Trustfulness' },
  { id: 'loyalty', nameTh: 'ความภักดีและกตัญญู', labelEn: 'Loyalty' },
  { id: 'integrity', nameTh: 'ความซื่อตรงและยุติธรรม', labelEn: 'Integrity' },
  { id: 'aggression', nameTh: 'ความดุดันก้าวร้าว', labelEn: 'Aggression' },
  { id: 'courage', nameTh: 'ความกล้าหาญเด็ดเดี่ยว', labelEn: 'Courage' },
  { id: 'pride', nameTh: 'ความหยิ่งทะนงในศักดิ์ศรี', labelEn: 'Pride' },
  { id: 'composure', nameTh: 'ความมั่นคงทางอารมณ์', labelEn: 'Composure' }
]);

const APTITUDE_DOMAINS_6 = Object.freeze([
  { id: 'cultivation', nameTh: 'พรสวรรค์บ่มเพาะปราณ', labelEn: 'Internal Conditioning & Vitality Aptitude' },
  { id: 'comprehension', nameTh: 'ความเข้าใจมรรคาและคัมภีร์', labelEn: 'Doctrine & Treatise Comprehension Aptitude' },
  { id: 'combat', nameTh: 'สัญชาตญาณการต่อสู้', labelEn: 'Martial Combat Instinct' },
  { id: 'crafting', nameTh: 'พรสวรรค์ศาสตร์การผลิต', labelEn: 'Engineering & Craft Aptitude' },
  { id: 'command', nameTh: 'พรสวรรค์นำทัพและกลยุทธ์', labelEn: 'Military Command & Strategy Aptitude' },
  { id: 'socialCommerce', nameTh: 'พรสวรรค์วาทศิลป์และการค้า', labelEn: 'Rhetoric, Diplomacy & Commerce Aptitude' }
]);

const bodyDefs = Object.freeze([
  ['strength', 'แรงกล้ามเนื้อ', 'แรงยกและงานหนัก'],
  ['power', 'พลังระเบิด', 'กำลังปะทะและงานใช้แรงช่วงสั้น'],
  ['agility', 'ความคล่องตัว', 'เดินทางและต่อสู้'],
  ['dexterity', 'ความละเอียดของมือ', 'งานประณีตและโอสถ'],
  ['coordination', 'การประสานร่างกาย', 'งานที่ใช้มือและเคลื่อนที่'],
  ['balance', 'การทรงตัว', 'เดินทางและป้องกันตัว'],
  ['mobility', 'ช่วงการเคลื่อนไหว', 'การเคลื่อนไหวและงานภาคสนาม'],
  ['durability', 'ความทนต่อแรงกระแทก', 'ลดความเสียหายจากการปะทะ'],
  ['metabolism', 'อัตราใช้พลังงาน', 'สูงแล้วหิวเร็วขึ้น'],
  ['painTolerance', 'การทนความเจ็บ', 'ความพร้อมขณะเจ็บ'],
  ['immuneResilience', 'ความทนทานทางชีวภาพ', 'พักฟื้นและสลายพิษสะสม'],
  ['endurance', 'ความอึด', 'ความล้าและงานต่อเนื่อง', 'physiology'],
  ['recoveryRate', 'การฟื้นตัว', 'พักฟื้นและบาดแผล', 'physiology'],
  ['senseAcuity', 'การรับรู้ประสาทสัมผัส', 'สังเกตและสำรวจ', 'physiology']
].map(([id, label, meaning, source]) => Object.freeze({
  id,
  label,
  meaning,
  source: source || 'human',
  path: source ? 'core.physiology.' + id : 'core.human.body.' + id
})));

const cognitiveDefs = Object.freeze([
  ['reasoning', 'การให้เหตุผล', 'เข้าใจความสัมพันธ์และเรียนรู้', 'intelligence'],
  ['planning', 'การวางแผน', 'จัดลำดับและประเมินงาน', 'planning'],
  ['workingMemory', 'ความจำใช้งาน', 'จัดการหลายขั้นตอน'],
  ['attention', 'การคงสมาธิ', 'งานละเอียดและความชัดเจน'],
  ['episodicMemory', 'การจำเหตุการณ์', 'ระยะคงอยู่ของประสบการณ์'],
  ['processingSpeed', 'ความเร็วประมวลผล', 'ความเร็วงานและการตัดสินใจ'],
  ['numeracy', 'ความเข้าใจเชิงปริมาณ', 'ค้า สัดส่วนยา และคำนวณ'],
  ['spatialReasoning', 'ความเข้าใจพื้นที่', 'สำรวจ งานช่าง และต่อสู้'],
  ['verbalComprehension', 'ความเข้าใจภาษา', 'ตำราและการสื่อสาร'],
  ['systemsThinking', 'ความเข้าใจระบบ', 'เชื่อมโยงสูตรและศาสตร์'],
  ['socialInsight', 'การเข้าใจผู้อื่น', 'สัมพันธ์และเจรจา'],
  ['metacognition', 'การรู้ข้อจำกัดตน', 'ประเมินความสามารถและความเสี่ยง']
].map(([id, label, meaning, path]) => Object.freeze({
  id,
  label,
  meaning,
  source: path ? 'original' : 'human',
  path: path || 'core.human.cognition.' + id
})));

const interestDefs = Object.freeze([
  ['analysis', 'วิเคราะห์และค้นเหตุผล'],
  ['creation', 'สร้างสิ่งใหม่'],
  ['competition', 'แข่งขันและท้าประลอง'],
  ['exploration', 'ค้นพบและเดินทาง'],
  ['care', 'ดูแลและช่วยเหลือ'],
  ['exchange', 'ซื้อขายและต่อรอง'],
  ['expression', 'แสดงออกและถ่ายทอด'],
  ['companionship', 'อยู่ร่วมกับผู้คน'],
  ['practice', 'ฝึกฝนซ้ำจนชำนาญ'],
  ['tranquility', 'ความสงบและสันโดษ'],
  ['leadership', 'นำและรับผิดชอบกลุ่ม'],
  ['nature', 'อยู่กับธรรมชาติ'],
  ['exertion', 'ใช้แรงและเคลื่อนไหว'],
  ['risk', 'เสี่ยงและตื่นเต้น']
].map(([id, label]) => Object.freeze({
  id,
  label,
  path: 'core.human.interests.' + id
})));

const parts = Object.freeze(['head', 'torso', 'leftArm', 'rightArm', 'leftLeg', 'rightLeg']);
const partLabels = Object.freeze({
  head: 'ศีรษะ',
  torso: 'ลำตัว',
  leftArm: 'แขนซ้าย',
  rightArm: 'แขนขวา',
  leftLeg: 'ขาซ้าย',
  rightLeg: 'ขาขวา'
});

const ids = a => new Set(a.map(d => d.id));
const validAxisGroups = Object.freeze({
  valueWeights: ids(VALUE_DIMENSIONS_8),
  personalityWeights: ids(PERSONALITY_AXES_14),
  aptitudeWeights: ids(APTITUDE_DOMAINS_6),
  bodyWeights: ids(bodyDefs),
  cognitiveWeights: ids(cognitiveDefs),
  interestWeights: ids(interestDefs)
});

const axisDefinitions = Object.freeze({
  values: VALUE_DIMENSIONS_8,
  personality: PERSONALITY_AXES_14,
  body: bodyDefs,
  cognition: cognitiveDefs,
  aptitudes: APTITUDE_DOMAINS_6,
  interests: interestDefs
});

function raw(n, kind, id) {
  if (kind === 'aptitude') return clamp(n.core.aptitudes[id]);
  const def = ({ body: bodyDefs, cognition: cognitiveDefs, interest: interestDefs }[kind] || []).find(d => d.id === id);
  if (!def) throw new NpcEngineError(ERROR_CODES.INVALID_AXIS, 'Unknown human dimension ' + kind + '.' + id);
  return clamp(readPath(n, def.path));
}

function validate(n) {
  if (!n || !isObject(n) || !n.core || !isObject(n.core) || !n.core.human) {
    throw new NpcEngineError(ERROR_CODES.INVALID_NPC, 'โครงสร้างตัวตน NPC ไม่ครบ');
  }
  const h = n.core.human;
  const check = (v, p) => {
    if (!Number.isFinite(v) || v < 0 || v > 100) {
      throw new NpcEngineError(ERROR_CODES.INVALID_AXIS, 'ข้อมูลตัวตนไม่ถูกต้อง: ' + p, { path: p, value: v });
    }
  };
  for (const d of [...bodyDefs, ...cognitiveDefs, ...interestDefs]) check(readPath(n, d.path), d.path);
  for (const d of VALUE_DIMENSIONS_8) check(n.core.values?.[d.id], 'values.' + d.id);
  for (const d of PERSONALITY_AXES_14) check(n.personality?.[d.id], 'personality.' + d.id);
  for (const d of APTITUDE_DOMAINS_6) check(n.core.aptitudes?.[d.id], 'aptitudes.' + d.id);
  for (const k of ['autonomy', 'competence', 'stimulation', 'pain', 'grief']) check(h.state?.[k], k);
  for (const p of parts) check(h.state?.parts?.[p], p);
  if (
    !h.form ||
    !Number.isFinite(h.form.heightCm) || h.form.heightCm <= 0 ||
    !Number.isFinite(h.form.massKg) || h.form.massKg <= 0 ||
    !h.experience?.skills ||
    !h.experience?.beliefs ||
    !Array.isArray(h.experience?.reflections)
  ) {
    throw new NpcEngineError(ERROR_CODES.INVALID_SCHEMA, 'โครงสร้างตัวตน NPC ไม่ครบ');
  }
  if (!['left', 'right', 'both'].includes(h.form.handedness) || ![h.form.skinTone, h.form.hairTone].every(c => /^#[0-9a-f]{6}$/i.test(c))) {
    throw new NpcEngineError(ERROR_CODES.INVALID_SCHEMA, 'ข้อมูลสรีระ NPC ไม่ถูกต้อง');
  }
  if (Array.isArray(h.experience.skills) || Array.isArray(h.experience.beliefs) || !Number.isFinite(h.experience.completed) || h.experience.completed < 0) {
    throw new NpcEngineError(ERROR_CODES.INVALID_SCHEMA, 'ข้อมูลประสบการณ์ NPC ไม่ถูกต้อง');
  }
  for (const [id, s] of Object.entries(h.experience.skills)) {
    check(s?.level, 'skills.' + id);
    if (!Number.isFinite(s.practice) || s.practice < 0) {
      throw new NpcEngineError(ERROR_CODES.INVALID_SCHEMA, 'ข้อมูลการฝึกไม่ถูกต้อง: ' + id);
    }
  }
  for (const [id, b] of Object.entries(h.experience.beliefs)) {
    if (!Number.isInteger(b.count) || b.count < 1 || !Number.isFinite(b.total) || !Number.isFinite(b.lastAt) || !Number.isFinite(b.expected) || Math.abs(b.expected) > 20) {
      throw new NpcEngineError(ERROR_CODES.INVALID_SCHEMA, 'ข้อมูลความทรงจำไม่ถูกต้อง: ' + id);
    }
  }
  return true;
}

function ensure(n, seed = 0, { fresh = false } = {}) {
  if (!n?.core) throw new NpcEngineError(ERROR_CODES.INVALID_NPC, 'Human identity requires the original NPC core');
  if (fresh) delete n.core.human;
  if (n.core.human?.schemaVersion > VERSION) {
    throw new NpcEngineError(ERROR_CODES.NEWER_SCHEMA, 'เซฟใช้รากฐานตัวตน NPC รุ่นใหม่กว่าเกมนี้');
  }
  if (n.core.human?.schemaVersion === VERSION) {
    validate(n);
    return n.core.human;
  }
  if (n.core.human) {
    throw new NpcEngineError(ERROR_CODES.INVALID_SCHEMA, 'ไม่รู้จักรุ่นข้อมูลตัวตน NPC');
  }
  const key = seed + ':' + n.id + ':human-v1';
  const r = random(key + ':form');
  const roll = id => {
    const f = random(key + ':' + id);
    return Math.round(18 + ((f() + f() + f()) / 3) * 76);
  };
  const h = {
    schemaVersion: VERSION,
    identityId: 'JI-' + hash(seed + ':' + n.id).toString(16).padStart(8, '0'),
    body: {},
    cognition: {},
    interests: {},
    form: {
      heightCm: Math.round(150 + r() * 43),
      massKg: Math.round(45 + r() * 47),
      handedness: r() < 0.11 ? 'left' : r() < 0.06 ? 'both' : 'right',
      skinTone: ['#d5ad85', '#bc8e66', '#e4c6a0', '#a87854'][Math.floor(r() * 4)],
      hairTone: ['#263833', '#463d31', '#6c6050', '#393945'][Math.floor(r() * 4)],
      eyeTone: ['น้ำตาล', 'ดำ', 'อำพัน'][Math.floor(r() * 3)]
    },
    state: {
      autonomy: 25,
      competence: 25,
      stimulation: 20,
      pain: 0,
      grief: 0,
      parts: Object.fromEntries(parts.map(p => [p, 0]))
    },
    experience: {
      skills: {},
      beliefs: {},
      reflections: [],
      completed: 0
    }
  };
  for (const d of bodyDefs) if (d.source === 'human') h.body[d.id] = roll('body:' + d.id);
  for (const d of cognitiveDefs) if (d.source === 'human') h.cognition[d.id] = roll('cognition:' + d.id);
  for (const d of interestDefs) h.interests[d.id] = Math.round(8 + random(key + ':interest:' + d.id)() * 84);
  n.core.human = h;
  if (fresh) {
    n.intelligence = roll('cognition:reasoning');
    n.planning = roll('cognition:planning');
  }
  return h;
}

function mapOrCreate(parent, key, label) {
  if (parent[key] === undefined || parent[key] === null) parent[key] = {};
  if (!isObject(parent[key])) throw new NpcEngineError(ERROR_CODES.INVALID_NPC, 'Invalid NPC identity map: ' + label);
  return parent[key];
}

function ensureNumber(obj, key, seed, axisId, label) {
  if (obj[key] === undefined || obj[key] === null) {
    obj[key] = rollValue(seed, axisId);
    return;
  }
  if (!Number.isFinite(obj[key]) || obj[key] < 0 || obj[key] > 100) {
    throw new NpcEngineError(ERROR_CODES.INVALID_AXIS, 'Invalid NPC axis ' + label + '.' + key + '; expected 0..100');
  }
}

function attach(n, seed = 0, options = {}) {
  if (!n || typeof n !== 'object') throw new NpcEngineError(ERROR_CODES.INVALID_NPC, 'NPC must be an object');
  if (n.id === undefined || n.id === null || String(n.id).trim() === '') {
    throw new NpcEngineError(ERROR_CODES.INVALID_ID, 'NPC requires a stable id');
  }
  n.id = String(n.id);
  if (n.core === undefined || n.core === null) n.core = {};
  if (!isObject(n.core)) throw new NpcEngineError(ERROR_CODES.INVALID_NPC, 'NPC core must be an object');
  const key = String(seed) + ':' + n.id + ':identity-v1';
  const values = mapOrCreate(n.core, 'values', 'core.values');
  const personality = mapOrCreate(n, 'personality', 'personality');
  const aptitudes = mapOrCreate(n.core, 'aptitudes', 'core.aptitudes');
  const physiology = mapOrCreate(n.core, 'physiology', 'core.physiology');
  const conditionState = mapOrCreate(n.core, 'condition', 'core.condition');

  for (const d of VALUE_DIMENSIONS_8) ensureNumber(values, d.id, key, 'values:' + d.id, 'values');
  for (const d of PERSONALITY_AXES_14) ensureNumber(personality, d.id, key, 'personality:' + d.id, 'personality');
  for (const d of APTITUDE_DOMAINS_6) ensureNumber(aptitudes, d.id, key, 'aptitude:' + d.id, 'aptitudes');
  for (const d of bodyDefs.filter(x => x.source === 'physiology')) ensureNumber(physiology, d.id, key, 'body:' + d.id, 'physiology');
  for (const d of cognitiveDefs.filter(x => x.source === 'original')) {
    const path = d.path.split('.');
    const parent = path.length === 1 ? n : readPath(n, path.slice(0, -1).join('.'));
    const k = path[path.length - 1];
    if (!parent || typeof parent !== 'object') throw new NpcEngineError(ERROR_CODES.INVALID_NPC, 'Missing cognition path ' + d.path);
    ensureNumber(parent, k, key, 'cognition:' + d.id, d.path);
  }
  for (const k of ['fatigue', 'moodStress']) {
    if (conditionState[k] === undefined || conditionState[k] === null) conditionState[k] = 0;
    if (!Number.isFinite(conditionState[k]) || conditionState[k] < 0 || conditionState[k] > 100) {
      throw new NpcEngineError(ERROR_CODES.INVALID_SCHEMA, 'Invalid condition ' + k);
    }
  }
  if (!Number.isFinite(n.health)) n.health = 100;
  if (n.health < 0 || n.health > 240) throw new NpcEngineError(ERROR_CODES.INVALID_SCHEMA, 'Invalid NPC health; expected 0..240');
  if (n.stageLocal === undefined || n.stageLocal === null) n.stageLocal = {};
  if (!isObject(n.stageLocal)) throw new NpcEngineError(ERROR_CODES.INVALID_SCHEMA, 'stageLocal must be an object');
  const sl = n.stageLocal;
  if (sl.needs === undefined || sl.needs === null) sl.needs = {};
  if (!isObject(sl.needs)) throw new NpcEngineError(ERROR_CODES.INVALID_SCHEMA, 'stageLocal.needs must be an object');
  for (const k of ['hunger', 'social', 'safety']) {
    if (sl.needs[k] === undefined || sl.needs[k] === null) sl.needs[k] = 0;
    if (!Number.isFinite(sl.needs[k]) || sl.needs[k] < 0 || sl.needs[k] > 100) {
      throw new NpcEngineError(ERROR_CODES.INVALID_SCHEMA, 'Invalid need ' + k);
    }
  }
  if (!Array.isArray(sl.memories)) {
    if (sl.memories === undefined || sl.memories === null) sl.memories = [];
    else throw new NpcEngineError(ERROR_CODES.INVALID_SCHEMA, 'stageLocal.memories must be an array');
  }
  if (sl.mode === undefined) sl.mode = 'idle';
  if (sl.action === undefined) sl.action = null;
  if (sl.lastWork === undefined) sl.lastWork = null;
  if (!Number.isFinite(sl.danger)) sl.danger = 0;
  if (n.name === undefined || n.name === null) n.name = n.id;

  ensure(n, seed, { fresh: !!options.fresh });
  return n;
}

function getAxis(n, group, id) {
  if (group === 'values') return n.core.values[id];
  if (group === 'personality') return n.personality[id];
  if (group === 'aptitudes') return n.core.aptitudes[id];
  if (group === 'body') return raw(n, 'body', id);
  if (group === 'cognition') return raw(n, 'cognition', id);
  if (group === 'interests') return raw(n, 'interest', id);
  throw new NpcEngineError(ERROR_CODES.INVALID_AXIS, 'Unknown identity group ' + group);
}

function setAxis(n, group, id, value) {
  if (!Number.isFinite(value) || value < 0 || value > 100) {
    throw new NpcEngineError(ERROR_CODES.INVALID_AXIS, 'Axis values must be finite numbers in 0..100');
  }
  const defMap = {
    values: VALUE_DIMENSIONS_8,
    personality: PERSONALITY_AXES_14,
    aptitudes: APTITUDE_DOMAINS_6,
    body: bodyDefs,
    cognition: cognitiveDefs,
    interests: interestDefs
  };
  const defs = defMap[group];
  if (!defs) throw new NpcEngineError(ERROR_CODES.INVALID_AXIS, 'Unknown identity group ' + group);
  const def = defs.find(d => d.id === id);
  if (!def) throw new NpcEngineError(ERROR_CODES.INVALID_AXIS, 'Unknown identity axis ' + group + '.' + id);
  if (group === 'values') n.core.values[id] = value;
  else if (group === 'personality') n.personality[id] = value;
  else if (group === 'aptitudes') n.core.aptitudes[id] = value;
  else if (group === 'interests') n.core.human.interests[id] = value;
  else setPath(n, def.path, value);
  return value;
}

function fingerprint(n) {
  return hash(JSON.stringify({
    values: n.core.values,
    personality: PERSONALITY_AXES_14.map(d => n.personality[d.id]),
    body: bodyDefs.map(d => raw(n, 'body', d.id)),
    cognition: cognitiveDefs.map(d => raw(n, 'cognition', d.id)),
    aptitudes: n.core.aptitudes,
    interests: n.core.human.interests,
    form: n.core.human.form,
    physiology: n.core.physiology
  })).toString(16).padStart(8, '0');
}

function differences(a, b) {
  const rows = [];
  for (const [kind, defs] of [['body', bodyDefs], ['cognition', cognitiveDefs], ['interest', interestDefs]]) {
    for (const d of defs) rows.push({ kind, label: d.label, a: raw(a, kind, d.id), b: raw(b, kind, d.id) });
  }
  for (const [kind, defs, read] of [
    ['value', VALUE_DIMENSIONS_8, n => n.core.values],
    ['personality', PERSONALITY_AXES_14, n => n.personality],
    ['aptitude', APTITUDE_DOMAINS_6, n => n.core.aptitudes]
  ]) {
    for (const d of defs) rows.push({ kind, label: d.nameTh, a: read(a)[d.id], b: read(b)[d.id] });
  }
  return rows.map(r => ({ ...r, delta: round(r.a - r.b) })).sort((x, y) => Math.abs(y.delta) - Math.abs(x.delta));
}

function getIdentity(n) {
  validate(n);
  const group = (defs, name) => Object.fromEntries(defs.map(d => [d.id, getAxis(n, name, d.id)]));
  return {
    schemaVersion: VERSION,
    identityId: n.core.human.identityId,
    axisCount: 68,
    values: group(VALUE_DIMENSIONS_8, 'values'),
    personality: group(PERSONALITY_AXES_14, 'personality'),
    body: group(bodyDefs, 'body'),
    cognition: group(cognitiveDefs, 'cognition'),
    aptitudes: group(APTITUDE_DOMAINS_6, 'aptitudes'),
    interests: group(interestDefs, 'interests'),
    form: { ...n.core.human.form },
    state: { ...n.core.human.state, parts: { ...n.core.human.state.parts } },
    experience: {
      completed: n.core.human.experience.completed,
      skills: { ...n.core.human.experience.skills },
      beliefs: { ...n.core.human.experience.beliefs },
      reflections: [...n.core.human.experience.reflections]
    }
  };
}

module.exports = {
  VERSION,
  axisCount: 68,
  VALUE_DIMENSIONS_8,
  PERSONALITY_AXES_14,
  APTITUDE_DOMAINS_6,
  bodyDefs,
  cognitiveDefs,
  interestDefs,
  parts,
  partLabels,
  validAxisGroups,
  axisDefinitions,
  raw,
  validate,
  ensure,
  attach,
  getAxis,
  setAxis,
  fingerprint,
  differences,
  getIdentity
};

  };
  __MODULES['capability_ontology'] = function(module, exports, require, globalThis) {
'use strict';

/**
 * Complete Three Kingdoms Capability Ontology (v1.0 Frozen Ontology)
 *
 * Covers all 15 mandatory capability categories across the foreseeable systems
 * of a historically inspired Three Kingdoms simulation game:
 *  7.1  individual_combat      — Individual martial and physical combat
 *  7.2  land_warfare           — Land warfare, tactics, and operations
 *  7.3  naval_warfare          — Naval and river warfare
 *  7.4  intelligence_deception — Intelligence, reconnaissance, and deception
 *  7.5  strategy_doctrine      — Strategy, doctrine, and military knowledge
 *  7.6  command_leadership     — Command, leadership, morale, and organization
 *  7.7  logistics_sustainment  — Logistics and campaign sustainment
 *  7.8  siege_engineering      — Siegecraft and military engineering
 *  7.9  diplomacy_politics     — Diplomacy, politics, and covert influence
 *  7.10 civil_administration   — Civil administration, economy, and society
 *  7.11 medicine_care          — Medicine, recovery, and animal care
 *  7.12 craft_production       — Craft, production, and technology
 *  7.13 scholarship_planning   — Scholarship, communication, and planning tools
 *  7.14 travel_survival        — Travel, terrain, survival, and environment
 *  7.15 social_household       — Social, household, and personal development
 *
 * NOTE: This ontology does NOT add any new innate personality/identity axes.
 * Every domain maps to the existing 68-axis foundation for natural capacity,
 * learning rate, and interest, while storing mutable mastery, knowledge, and
 * techniques in the NPC's experience/cognition state.
 */

const { NpcEngineError, ERROR_CODES } = __require('utils');

const CAPABILITY_FAMILIES = Object.freeze([
  { id: 'individual_combat', code: '7.1', nameEn: 'Individual Martial and Physical Combat', nameTh: 'การต่อสู้ส่วนบุคคลและยุทธศิลป์' },
  { id: 'land_warfare', code: '7.2', nameEn: 'Land Warfare, Tactics, and Operations', nameTh: 'ยุทธวิธีและการรบทางบก' },
  { id: 'naval_warfare', code: '7.3', nameEn: 'Naval and River Warfare', nameTh: 'การรบทางน้ำและกองเรือ' },
  { id: 'intelligence_deception', code: '7.4', nameEn: 'Intelligence, Reconnaissance, and Deception', nameTh: 'ข่าวกรอง การลาดตระเวน และกลลวง' },
  { id: 'strategy_doctrine', code: '7.5', nameEn: 'Strategy, Doctrine, and Military Knowledge', nameTh: 'ยุทธศาสตร์และพิชัยสงคราม' },
  { id: 'command_leadership', code: '7.6', nameEn: 'Command, Leadership, Morale, and Organization', nameTh: 'การบังคับบัญชา ขวัญกำลังใจ และการจัดองค์กร' },
  { id: 'logistics_sustainment', code: '7.7', nameEn: 'Logistics and Campaign Sustainment', nameTh: 'พลาธิการและการส่งกำลังบำรุง' },
  { id: 'siege_engineering', code: '7.8', nameEn: 'Siegecraft and Military Engineering', nameTh: 'การล้อมเมืองและวิศวกรรมทหาร' },
  { id: 'diplomacy_politics', code: '7.9', nameEn: 'Diplomacy, Politics, and Covert Influence', nameTh: 'การทูต การเมือง และอิทธิพลทางลับ' },
  { id: 'civil_administration', code: '7.10', nameEn: 'Civil administration, Economy, and Society', nameTh: 'การปกครอง เศรษฐกิจ และสังคม' },
  { id: 'medicine_care', code: '7.11', nameEn: 'Medicine, Recovery, and Animal Care', nameTh: 'การแพทย์ การฟื้นฟู และการดูแลสัตว์ศึก' },
  { id: 'craft_production', code: '7.12', nameEn: 'Craft, Production, and Technology', nameTh: 'งานช่าง การผลิต และเทคโนโลยี' },
  { id: 'scholarship_planning', code: '7.13', nameEn: 'Scholarship, Communication, and Planning Tools', nameTh: 'วิชาการ การสื่อสาร และเครื่องมือวางแผน' },
  { id: 'travel_survival', code: '7.14', nameEn: 'Travel, Terrain, Survival, and Environment', nameTh: 'การเดินทาง ภูมิประเทศ และการยังชีพ' },
  { id: 'social_household', code: '7.15', nameEn: 'Social, Household, and Personal Development', nameTh: 'ความสัมพันธ์ ครัวเรือน และการพัฒนาตน' }
]);

const CAPABILITY_DOMAINS = Object.freeze({
  // =========================================================================
  // 7.1 Individual Martial and Physical Combat
  // =========================================================================
  individual_combat: {
    id: 'individual_combat',
    familyId: 'individual_combat',
    displayName: 'Individual Martial & Physical Combat',
    displayNameTh: 'การต่อสู้ส่วนบุคคลและอาวุธประจำกาย',
    legacyAliases: ['combat', 'duel_combat'],
    subCapabilities: [
      'unarmed_grappling',
      'melee_weapons_sword_spear_halberd_shield',
      'ranged_archery_crossbow',
      'mounted_combat_horsemanship',
      'dueling_and_formation_fighting'
    ],
    semanticDefinition: 'Personal physical fighting skill, weapon handling (sword/jian, saber/dao, spear, halberd/ji, staff, shield, bow, crossbow), mounted riding and cavalry combat, dueling judgment, defensive movement, weapon maintenance, and fighting within a formation as an individual warrior.',
    boundaries: 'Covers personal combat proficiency and immediate weapon/mount control. Distinct from commanding an army (command_leadership) or formulating battle tactics (land_warfare).',
    prerequisites: {
      capabilities: {},
      minimumBody: { coordination: 20, balance: 20 }
    },
    relatedDomains: ['land_warfare', 'travel_survival', 'craft_production'],
    axisWeights: {
      bodyWeights: { strength: 0.22, power: 0.22, agility: 0.2, coordination: 0.16, balance: 0.1, endurance: 0.1 },
      cognitiveWeights: { spatialReasoning: 0.35, processingSpeed: 0.3, attention: 0.2, metacognition: 0.15 },
      aptitudeWeights: { combat: 0.85, command: 0.15 },
      interestWeights: { competition: 0.4, exertion: 0.3, practice: 0.2, risk: 0.1 },
      valueWeights: { martialPeak: 0.35, honorLegacy: 0.25, powerStatus: 0.15 },
      personalityWeights: { courage: 0.28, discipline: 0.2, aggression: 0.18, composure: 0.18 }
    },
    perceptionAndInference: {
      canPerceiveBetter: [
        'opponent_weapon_reach_and_stance',
        'personal_stamina_and_wound_severity',
        'armor_weak_points_and_mount_stability',
        'immediate_melee_terrain_footing'
      ],
      inferenceBonus: 0.25,
      cannotInfer: [
        'hidden_enemy_strategic_reserves',
        'distant_campaign_supply_lines',
        'diplomatic_treaty_secret_clauses'
      ]
    },
    unlockedAffordances: {
      candidateActions: ['duel', 'personal_guard_charge', 'mounted_archery_skirmish', 'hold_breach_personally'],
      techniques: ['halberd_sweep', 'mounted_lance_charge', 'shield_wall_brace', 'precision_crossbow_volley'],
      masteryThresholds: { basic: 15, competent: 40, expert: 70 }
    },
    executionModifiers: {
      qualityWeight: 0.55,
      speedWeight: 0.25,
      costReductionWeight: 0.15,
      coordinationWeight: 0.15,
      errorRiskReductionWeight: 0.45,
      recoveryWeight: 0.2
    },
    learningEvidence: {
      increaseTriggers: ['duel_outcome', 'personal_melee_engagement', 'weapon_drill', 'mounted_skirmish'],
      decreaseOrConfidenceLossTriggers: ['severe_limb_injury', 'duel_defeat_by_technique_gap'],
      requiresDirectParticipation: true
    },
    contextualModifiers: {
      sensitiveBodyParts: ['leftArm', 'rightArm', 'leftLeg', 'rightLeg', 'torso'],
      requiredEquipmentTypes: ['weapon', 'armor', 'mount'],
      fatiguePenaltyScale: 1.35,
      weatherSensitivity: ['heavy_rain', 'mud', 'extreme_heat']
    },
    verificationScenarios: ['duel_mastery_vs_novice', 'arm_injury_impairs_archery_and_duel']
  },

  // =========================================================================
  // 7.2 Land Warfare, Tactics, and Operations
  // =========================================================================
  land_warfare: {
    id: 'land_warfare',
    familyId: 'land_warfare',
    displayName: 'Land Warfare, Tactics & Operations',
    displayNameTh: 'ยุทธวิธีและการปฏิบัติการรบทางบก',
    legacyAliases: ['tactics', 'defense'],
    subCapabilities: [
      'combined_arms_infantry_cavalry_ranged',
      'flanking_encirclement_and_reserves',
      'ambush_feint_and_night_operations',
      'retreat_delaying_and_pursuit_tactics',
      'terrain_and_formation_deployment'
    ],
    semanticDefinition: 'Tactical judgment and operational execution on land: deploying infantry, cavalry, and crossbowmen/archers, reserves, flanking, encirclement, pursuit, fighting withdrawal, delaying actions, feints, ambush and counter-ambush, night raids, scouting screens, river crossings, and mountain pass defense.',
    boundaries: 'Covers battlefield and operational land maneuvers. Distinct from individual dueling (individual_combat), high-level grand doctrine (strategy_doctrine), and naval fleet handling (naval_warfare).',
    prerequisites: {
      capabilities: { command_leadership: 10 },
      minimumCognition: { planning: 25, spatialReasoning: 25 }
    },
    relatedDomains: ['command_leadership', 'strategy_doctrine', 'intelligence_deception', 'logistics_sustainment'],
    axisWeights: {
      bodyWeights: { endurance: 0.4, senseAcuity: 0.35, mobility: 0.25 },
      cognitiveWeights: { spatialReasoning: 0.28, planning: 0.26, workingMemory: 0.16, processingSpeed: 0.15, metacognition: 0.15 },
      aptitudeWeights: { command: 0.65, combat: 0.35 },
      interestWeights: { analysis: 0.3, leadership: 0.3, competition: 0.2, risk: 0.2 },
      valueWeights: { sectDuty: 0.25, powerStatus: 0.22, honorLegacy: 0.2, martialPeak: 0.15 },
      personalityWeights: { caution: 0.22, rationality: 0.22, composure: 0.2, courage: 0.18, creativity: 0.18 }
    },
    perceptionAndInference: {
      canPerceiveBetter: [
        'chokepoint_and_ambush_terrain',
        'enemy_formation_flank_vulnerability',
        'unit_spacing_and_cohesion_drift',
        'weather_impact_on_cavalry_and_bows'
      ],
      inferenceBonus: 0.3,
      cannotInfer: [
        'unscouted_enemy_force_behind_mountains',
        'private_political_betrayal_in_capital'
      ]
    },
    unlockedAffordances: {
      candidateActions: ['ambush', 'defend_city', 'flank_maneuver', 'fighting_retreat', 'night_raid', 'hold_mountain_pass'],
      techniques: ['eight_gates_formation', 'feigned_retreat_lure', 'crossbow_shield_screen', 'cavalry_pincer_envelopment'],
      masteryThresholds: { basic: 15, competent: 40, expert: 70 }
    },
    executionModifiers: {
      qualityWeight: 0.5,
      speedWeight: 0.25,
      costReductionWeight: 0.25,
      coordinationWeight: 0.45,
      errorRiskReductionWeight: 0.45,
      recoveryWeight: 0.25
    },
    learningEvidence: {
      increaseTriggers: ['land_battle_command', 'ambush_execution', 'defensive_stand', 'tactical_maneuver'],
      decreaseOrConfidenceLossTriggers: ['ambush_walked_into', 'formation_collapse_under_flank'],
      requiresDirectParticipation: true
    },
    contextualModifiers: {
      sensitiveBodyParts: ['head', 'torso'],
      requiredEquipmentTypes: ['signaling_gear', 'unit_banners'],
      fatiguePenaltyScale: 1.15,
      weatherSensitivity: ['fog', 'heavy_rain', 'gale_wind']
    },
    verificationScenarios: ['ambush_specialist_vs_novice_tactician', 'fighting_retreat_under_pressure']
  },

  // =========================================================================
  // 7.3 Naval and River Warfare (Mandatory First-Release Domain)
  // =========================================================================
  naval_warfare: {
    id: 'naval_warfare',
    familyId: 'naval_warfare',
    displayName: 'Naval & River Warfare',
    displayNameTh: 'การรบทางน้ำและยุทธนาวี',
    legacyAliases: ['naval', 'seamanship'],
    subCapabilities: [
      'seamanship_vessel_handling_and_navigation',
      'river_current_and_wind_assessment',
      'fleet_formation_and_convoy_escort',
      'ship_boarding_ranged_and_fire_attacks',
      'amphibious_landing_and_river_blockade'
    ],
    semanticDefinition: 'Complete Three Kingdoms riverine and coastal warfare competence: seamanship, vessel handling (mengchong assault boats, doujian warships, louchuan tower ships), river-current and wind awareness, fleet organization, ship-to-ship boarding and anti-boarding, ranged attacks from decks, fire-ship attacks, river blockades, convoy escort, and amphibious landings.',
    boundaries: 'Covers operations on rivers, lakes, and coasts. High land command or strategy aptitude does NOT grant seamanship or current/wind mastery without naval training and experience.',
    prerequisites: {
      capabilities: { travel_survival: 10 },
      minimumBody: { balance: 25 },
      minimumCognition: { spatialReasoning: 25 }
    },
    relatedDomains: ['land_warfare', 'command_leadership', 'logistics_sustainment', 'craft_production', 'travel_survival'],
    axisWeights: {
      bodyWeights: { balance: 0.35, endurance: 0.25, senseAcuity: 0.2, coordination: 0.2 },
      cognitiveWeights: { spatialReasoning: 0.3, planning: 0.25, systemsThinking: 0.2, attention: 0.15, metacognition: 0.1 },
      aptitudeWeights: { command: 0.55, combat: 0.25, crafting: 0.2 },
      interestWeights: { exploration: 0.3, analysis: 0.25, leadership: 0.25, nature: 0.2 },
      valueWeights: { sectDuty: 0.25, powerStatus: 0.2, knowledgeCraft: 0.2, honorLegacy: 0.15 },
      personalityWeights: { caution: 0.25, composure: 0.25, rationality: 0.2, creativity: 0.15, courage: 0.15 }
    },
    perceptionAndInference: {
      canPerceiveBetter: [
        'seasonal_wind_shifts_and_eddies',
        'river_shoals_sandbars_and_current_speed',
        'chained_fleet_fire_vulnerability',
        'crew_seasickness_and_deck_stability'
      ],
      inferenceBonus: 0.35,
      cannotInfer: [
        'unobserved_inland_cavalry_movements',
        'hidden_shore_ambush_without_reconnaissance'
      ]
    },
    unlockedAffordances: {
      candidateActions: [
        'scout_river_route',
        'organize_fleet_formation',
        'escort_supply_convoy_by_river',
        'launch_fire_attack',
        'conduct_amphibious_landing',
        'enforce_river_blockade'
      ],
      techniques: [
        'mengchong_ramming_screen',
        'wind_aligned_fire_ship_release',
        'river_current_flanking_drift',
        'anti_boarding_grapnel_defense'
      ],
      masteryThresholds: { basic: 15, competent: 40, expert: 70 }
    },
    executionModifiers: {
      qualityWeight: 0.6,
      speedWeight: 0.3,
      costReductionWeight: 0.25,
      coordinationWeight: 0.5,
      errorRiskReductionWeight: 0.55,
      recoveryWeight: 0.2
    },
    learningEvidence: {
      increaseTriggers: ['river_navigation', 'fleet_maneuver_drill', 'naval_engagement', 'convoy_river_escort'],
      decreaseOrConfidenceLossTriggers: ['shipwreck_in_rapids', 'fire_ship_backfire_from_wind_misread'],
      requiresDirectParticipation: true
    },
    contextualModifiers: {
      sensitiveBodyParts: ['head', 'leftLeg', 'rightLeg'],
      requiredEquipmentTypes: ['vessels', 'naval_crews', 'incendiary_materials'],
      fatiguePenaltyScale: 1.25,
      weatherSensitivity: ['gale_wind', 'adverse_wind', 'fog', 'rapid_current']
    },
    verificationScenarios: ['zhou_yu_vs_northern_general_on_river', 'fire_ship_requires_wind_and_naval_technique']
  },

  // =========================================================================
  // 7.4 Intelligence, Reconnaissance, and Deception
  // =========================================================================
  intelligence_deception: {
    id: 'intelligence_deception',
    familyId: 'intelligence_deception',
    displayName: 'Intelligence, Reconnaissance & Deception',
    displayNameTh: 'ข่าวกรอง การลาดตระเวน และกลอุบาย',
    legacyAliases: ['intrigue', 'scouting'],
    subCapabilities: [
      'reconnaissance_scouting_and_tracking',
      'intelligence_analysis_and_source_evaluation',
      'espionage_infiltration_and_covert_comms',
      'counterintelligence_and_opsec',
      'deception_disinformation_and_counter_deception'
    ],
    semanticDefinition: 'Gathering, verifying, and manipulating information: field scouting, tracking, map reading, source reliability grading, interrogation, covert networks, infiltration, counterintelligence, planting false rumors, detecting traps/feints, and operational security.',
    boundaries: 'Improves observation accuracy, rumor discrimination, and deception execution. NEVER grants omniscient access to unobserved world truth.',
    prerequisites: {
      capabilities: {},
      minimumCognition: { attention: 25, socialInsight: 20 }
    },
    relatedDomains: ['strategy_doctrine', 'land_warfare', 'diplomacy_politics', 'travel_survival'],
    axisWeights: {
      bodyWeights: { senseAcuity: 0.45, agility: 0.3, mobility: 0.25 },
      cognitiveWeights: { socialInsight: 0.24, metacognition: 0.22, attention: 0.2, reasoning: 0.18, spatialReasoning: 0.16 },
      aptitudeWeights: { socialCommerce: 0.45, command: 0.35, comprehension: 0.2 },
      interestWeights: { analysis: 0.35, exploration: 0.3, risk: 0.2, tranquility: 0.15 },
      valueWeights: { powerStatus: 0.25, knowledgeCraft: 0.2, sectDuty: 0.2, freedom: 0.15 },
      personalityWeights: { caution: 0.28, rationality: 0.24, curiosity: 0.2, creativity: 0.16, trustfulness: -0.12 }
    },
    perceptionAndInference: {
      canPerceiveBetter: [
        'campfire_count_and_march_dust_estimation',
        'inconsistencies_in_defector_or_scout_reports',
        'signs_of_hidden_ambush_or_forged_letters',
        'supply_wagon_wheel_rut_depth'
      ],
      inferenceBonus: 0.45,
      cannotInfer: [
        'events_with_zero_observational_or_report_trace',
        'exact_thoughts_of_unobserved_rulers'
      ]
    },
    unlockedAffordances: {
      candidateActions: ['scout', 'intrigue', 'verify_intelligence_report', 'plant_disinformation', 'counter_espionage_sweep'],
      techniques: ['double_agent_turn', 'false_campfire_deception', 'deep_reconnaissance_screen', 'cipher_courier_network'],
      masteryThresholds: { basic: 15, competent: 40, expert: 70 }
    },
    executionModifiers: {
      qualityWeight: 0.55,
      speedWeight: 0.3,
      costReductionWeight: 0.2,
      coordinationWeight: 0.25,
      errorRiskReductionWeight: 0.55,
      recoveryWeight: 0.15
    },
    learningEvidence: {
      increaseTriggers: ['reconnaissance_mission', 'deception_operation', 'false_report_exposed', 'spy_network_handling'],
      decreaseOrConfidenceLossTriggers: ['deceived_by_false_defector', 'scout_party_captured_due_to_poor_opsec'],
      requiresDirectParticipation: true
    },
    contextualModifiers: {
      sensitiveBodyParts: ['head', 'leftLeg', 'rightLeg'],
      requiredEquipmentTypes: ['recon_mounts', 'cover_identities', 'cipher_tools'],
      fatiguePenaltyScale: 1.2,
      weatherSensitivity: ['fog', 'night', 'heavy_rain']
    },
    verificationScenarios: ['source_reliability_filtering', 'detecting_feigned_retreat_or_false_report']
  },

  // =========================================================================
  // 7.5 Strategy, Doctrine, and Military Knowledge
  // =========================================================================
  strategy_doctrine: {
    id: 'strategy_doctrine',
    familyId: 'strategy_doctrine',
    displayName: 'Strategy, Doctrine & Military Knowledge',
    displayNameTh: 'ยุทธศาสตร์ หลักนิยม และพิชัยสงคราม',
    legacyAliases: ['strategy'],
    subCapabilities: [
      'military_treatises_and_historical_precedents',
      'campaign_planning_and_operational_sequencing',
      'contingency_planning_and_branching_plans',
      'enemy_intent_modeling_and_forecasting',
      'strategic_cost_benefit_and_risk_calibration'
    ],
    semanticDefinition: 'High-level campaign planning, operational sequencing, contingency formulation, enemy commander modeling, strategic cost-benefit analysis, and application of classical military doctrine to multi-step objectives.',
    boundaries: 'Distinguishes theoretical military knowledge from field execution. Knowing a treatise unlocks strategic options, but executing them in battle requires land_warfare/naval_warfare and command_leadership.',
    prerequisites: {
      capabilities: { scholarship_planning: 10 },
      minimumCognition: { reasoning: 30, planning: 30, systemsThinking: 25 }
    },
    relatedDomains: ['land_warfare', 'naval_warfare', 'command_leadership', 'logistics_sustainment', 'intelligence_deception', 'scholarship_planning'],
    axisWeights: {
      bodyWeights: { endurance: 0.5, senseAcuity: 0.5 },
      cognitiveWeights: { planning: 0.28, systemsThinking: 0.24, reasoning: 0.2, metacognition: 0.16, workingMemory: 0.12 },
      aptitudeWeights: { command: 0.6, comprehension: 0.4 },
      interestWeights: { analysis: 0.45, leadership: 0.25, creation: 0.15, practice: 0.15 },
      valueWeights: { knowledgeCraft: 0.3, sectDuty: 0.25, honorLegacy: 0.2, powerStatus: 0.15 },
      personalityWeights: { rationality: 0.28, caution: 0.22, creativity: 0.2, composure: 0.15, curiosity: 0.15 }
    },
    perceptionAndInference: {
      canPerceiveBetter: [
        'long_term_campaign_bottlenecks',
        'multi_front_strategic_exposure',
        'enemy_commander_doctrinal_habits',
        'opportunity_cost_of_protracted_siege'
      ],
      inferenceBonus: 0.4,
      cannotInfer: [
        'tactical_terrain_details_without_maps_or_scouts',
        'exact_troop_counts_without_intelligence'
      ]
    },
    unlockedAffordances: {
      candidateActions: ['research_strategy', 'formulate_campaign_plan', 'prepare_contingency_reserve', 'indirect_strategic_approach'],
      techniques: ['empty_fort_psychological_deterrence', 'divide_and_conquer_coalition', 'cut_supply_before_battle_doctrine', 'protracted_attrition_defense'],
      masteryThresholds: { basic: 15, competent: 40, expert: 70 }
    },
    executionModifiers: {
      qualityWeight: 0.5,
      speedWeight: 0.2,
      costReductionWeight: 0.35,
      coordinationWeight: 0.4,
      errorRiskReductionWeight: 0.5,
      recoveryWeight: 0.3
    },
    learningEvidence: {
      increaseTriggers: ['campaign_planning_review', 'treatise_study_and_wargaming', 'multi_step_plan_completion'],
      decreaseOrConfidenceLossTriggers: ['strategic_miscalculation', 'contingency_failure'],
      requiresDirectParticipation: true
    },
    contextualModifiers: {
      sensitiveBodyParts: ['head'],
      requiredEquipmentTypes: ['maps', 'military_records'],
      fatiguePenaltyScale: 1.25,
      weatherSensitivity: []
    },
    verificationScenarios: ['zhuge_liang_multi_step_planning', 'theoretical_scholar_vs_field_veteran']
  },

  // =========================================================================
  // 7.6 Command, Leadership, Morale, and Organization
  // =========================================================================
  command_leadership: {
    id: 'command_leadership',
    familyId: 'command_leadership',
    displayName: 'Command, Leadership, Morale & Organization',
    displayNameTh: 'การบังคับบัญชา ขวัญกำลังใจ และการจัดทัพ',
    legacyAliases: ['command', 'training', 'recruitment', 'patrol'],
    subCapabilities: [
      'authority_and_command_communication',
      'delegation_and_subordinate_assessment',
      'troop_training_drill_and_discipline',
      'morale_maintenance_and_cohesion',
      'inter_commander_coordination_and_conflict_resolution'
    ],
    semanticDefinition: 'Leading, organizing, drilling, and motivating soldiers and subordinate officers: issuing clear orders, delegating tasks, maintaining discipline and unit cohesion, assessing personnel fit, recruiting officers, resolving inter-unit friction, and sustaining morale under fire.',
    boundaries: 'Personality and values shape leadership style (benevolent vs strict), whereas command_leadership mastery determines how effectively orders are transmitted, understood, and obeyed without confusion.',
    prerequisites: {
      capabilities: {},
      minimumCognition: { planning: 20, socialInsight: 20 }
    },
    relatedDomains: ['land_warfare', 'naval_warfare', 'strategy_doctrine', 'diplomacy_politics', 'social_household'],
    axisWeights: {
      bodyWeights: { endurance: 0.6, senseAcuity: 0.4 },
      cognitiveWeights: { planning: 0.28, socialInsight: 0.24, workingMemory: 0.18, verbalComprehension: 0.16, metacognition: 0.14 },
      aptitudeWeights: { command: 0.7, socialCommerce: 0.3 },
      interestWeights: { leadership: 0.4, practice: 0.2, companionship: 0.2, expression: 0.2 },
      valueWeights: { sectDuty: 0.28, powerStatus: 0.24, honorLegacy: 0.24, familyClan: 0.14 },
      personalityWeights: { discipline: 0.24, composure: 0.2, courage: 0.18, integrity: 0.14, ambition: 0.14, loyalty: 0.1 }
    },
    perceptionAndInference: {
      canPerceiveBetter: [
        'subordinate_fatigue_and_wavering_morale',
        'officer_rivalry_and_insubordination_risk',
        'unit_drill_readiness_and_command_lag'
      ],
      inferenceBonus: 0.3,
      cannotInfer: [
        'engineering_structural_load_of_bridges',
        'herbal_pharmacology_dosages'
      ]
    },
    unlockedAffordances: {
      candidateActions: ['command_army', 'train_troops', 'recruit', 'patrol', 'delegate_detachment', 'rally_wavering_troops'],
      techniques: ['strict_martial_law_cadence', 'benevolent_shared_hardship_rally', 'tiered_banner_drum_signaling', 'merit_reward_and_reprimand'],
      masteryThresholds: { basic: 15, competent: 40, expert: 70 }
    },
    executionModifiers: {
      qualityWeight: 0.5,
      speedWeight: 0.3,
      costReductionWeight: 0.2,
      coordinationWeight: 0.6,
      errorRiskReductionWeight: 0.4,
      recoveryWeight: 0.3
    },
    learningEvidence: {
      increaseTriggers: ['command_army_execution', 'troop_training_cycle', 'successful_rally_under_stress', 'multi_officer_coordination'],
      decreaseOrConfidenceLossTriggers: ['mutiny_or_rout', 'order_miscommunication_disaster'],
      requiresDirectParticipation: true
    },
    contextualModifiers: {
      sensitiveBodyParts: ['head', 'torso'],
      requiredEquipmentTypes: ['command_tally', 'drums_and_banners'],
      fatiguePenaltyScale: 1.15,
      weatherSensitivity: ['gale_wind', 'heavy_rain']
    },
    verificationScenarios: ['delegation_and_multi_agent_coordination', 'rallying_low_morale_unit']
  },

  // =========================================================================
  // 7.7 Logistics and Campaign Sustainment
  // =========================================================================
  logistics_sustainment: {
    id: 'logistics_sustainment',
    familyId: 'logistics_sustainment',
    displayName: 'Logistics & Campaign Sustainment',
    displayNameTh: 'พลาธิการ เสบียง และการส่งกำลังบำรุง',
    legacyAliases: ['logistics'],
    subCapabilities: [
      'supply_estimation_and_rationing',
      'transport_baggage_and_route_planning',
      'camp_placement_and_supply_line_security',
      'foraging_and_tuntian_military_farming',
      'reinforcement_and_medical_evacuation_logistics'
    ],
    semanticDefinition: 'Sustaining armies in the field: grain and fodder calculation, rationing, transport carts/oxen/boats, marching pace vs attrition, camp placement, supply depot security, foraging without destroying discipline, tuntian agricultural sustainment, and casualty evacuation.',
    boundaries: 'Governs resource feasibility and campaign endurance. Even the most brilliant tactical plan fails if logistics_sustainment cannot keep the army fed and equipped.',
    prerequisites: {
      capabilities: {},
      minimumCognition: { numeracy: 25, planning: 25 }
    },
    relatedDomains: ['strategy_doctrine', 'command_leadership', 'civil_administration', 'travel_survival', 'medicine_care'],
    axisWeights: {
      bodyWeights: { endurance: 0.55, strength: 0.25, senseAcuity: 0.2 },
      cognitiveWeights: { numeracy: 0.3, planning: 0.28, systemsThinking: 0.2, workingMemory: 0.12, spatialReasoning: 0.1 },
      aptitudeWeights: { command: 0.45, socialCommerce: 0.35, crafting: 0.2 },
      interestWeights: { analysis: 0.3, exchange: 0.25, practice: 0.2, care: 0.15, leadership: 0.1 },
      valueWeights: { sectDuty: 0.3, wealthResource: 0.3, familyClan: 0.15, honorLegacy: 0.15 },
      personalityWeights: { discipline: 0.28, caution: 0.24, rationality: 0.24, integrity: 0.14, composure: 0.1 }
    },
    perceptionAndInference: {
      canPerceiveBetter: [
        'days_of_grain_remaining_and_spoilage_rate',
        'supply_convoy_bottlenecks_and_raid_exposure',
        'forage_carrying_capacity_of_local_valley',
        'march_attrition_from_terrain_and_season'
      ],
      inferenceBonus: 0.35,
      cannotInfer: [
        'personal_martial_arts_secret_techniques',
        'court_factional_poetry_allusions'
      ]
    },
    unlockedAffordances: {
      candidateActions: ['logistics', 'establish_supply_depot', 'fortify_supply_line', 'organize_tuntian_garrison', 'enforce_emergency_rationing'],
      techniques: ['staged_granary_relay', 'wooden_ox_transport_organization', 'protected_baggage_corridor', 'winter_fodder_prepositioning'],
      masteryThresholds: { basic: 15, competent: 40, expert: 70 }
    },
    executionModifiers: {
      qualityWeight: 0.5,
      speedWeight: 0.25,
      costReductionWeight: 0.5,
      coordinationWeight: 0.4,
      errorRiskReductionWeight: 0.45,
      recoveryWeight: 0.3
    },
    learningEvidence: {
      increaseTriggers: ['convoy_delivery', 'campaign_supply_management', 'depot_defense', 'famine_march_mitigation'],
      decreaseOrConfidenceLossTriggers: ['supply_train_burned', 'starvation_attrition_from_miscount'],
      requiresDirectParticipation: true
    },
    contextualModifiers: {
      sensitiveBodyParts: ['head', 'torso'],
      requiredEquipmentTypes: ['transport_carts', 'pack_animals', 'grain_stores'],
      fatiguePenaltyScale: 1.1,
      weatherSensitivity: ['heavy_rain', 'mud', 'snow_freeze']
    },
    verificationScenarios: ['reject_infeasible_offensive_when_supplies_low', 'secure_supply_line_before_advance']
  },

  // =========================================================================
  // 7.8 Siegecraft and Military Engineering
  // =========================================================================
  siege_engineering: {
    id: 'siege_engineering',
    familyId: 'siege_engineering',
    displayName: 'Siegecraft & Military Engineering',
    displayNameTh: 'การล้อมเมืองและวิศวกรรมสนาม',
    legacyAliases: ['siegecraft'],
    subCapabilities: [
      'city_assault_and_fortification_defense',
      'siege_engines_rams_ladders_catapults',
      'earthworks_trenches_mounds_and_mining',
      'bridge_road_and_river_crossing_works',
      'demolition_sabotage_and_structural_repair'
    ],
    semanticDefinition: 'Attacking and defending fortified cities and altering battlefield terrain: evaluating walls, gates, and moats, constructing and operating siege engines (cloud ladders, battering rams, trebuchets/catapults, mobile towers), digging trenches and saps, building pontoon bridges and field fortifications, and repairing breaches.',
    boundaries: 'Requires tools, timber/materials, labor, and time in addition to engineering knowledge. High siege_engineering without materials cannot conjure siege engines out of thin air.',
    prerequisites: {
      capabilities: { craft_production: 10 },
      minimumCognition: { spatialReasoning: 25, numeracy: 20 }
    },
    relatedDomains: ['land_warfare', 'craft_production', 'logistics_sustainment', 'command_leadership'],
    axisWeights: {
      bodyWeights: { endurance: 0.4, strength: 0.35, coordination: 0.25 },
      cognitiveWeights: { spatialReasoning: 0.28, planning: 0.24, systemsThinking: 0.22, numeracy: 0.16, workingMemory: 0.1 },
      aptitudeWeights: { crafting: 0.5, command: 0.5 },
      interestWeights: { creation: 0.35, analysis: 0.3, practice: 0.2, leadership: 0.15 },
      valueWeights: { knowledgeCraft: 0.28, sectDuty: 0.24, powerStatus: 0.2, wealthResource: 0.18 },
      personalityWeights: { discipline: 0.26, rationality: 0.24, caution: 0.2, creativity: 0.18, composure: 0.12 }
    },
    perceptionAndInference: {
      canPerceiveBetter: [
        'rammed_earth_wall_structural_weakness',
        'gatehouse_kill_zone_and_moat_depth',
        'timber_and_labor_hours_for_siege_engines',
        'tunneling_soil_stability_and_flooding_risk'
      ],
      inferenceBonus: 0.35,
      cannotInfer: [
        'court_diplomatic_alliances',
        'internal_illness_diagnosis'
      ]
    },
    unlockedAffordances: {
      candidateActions: ['siege', 'construct_siege_engines', 'fortify_camp_earthworks', 'build_pontoon_bridge', 'undermine_wall_section'],
      techniques: ['counterweight_trebuchet_battery', 'double_moat_circumvallation', 'counter_tunnel_listening_jars', 'rapid_palisade_erection'],
      masteryThresholds: { basic: 15, competent: 40, expert: 70 }
    },
    executionModifiers: {
      qualityWeight: 0.55,
      speedWeight: 0.3,
      costReductionWeight: 0.35,
      coordinationWeight: 0.35,
      errorRiskReductionWeight: 0.45,
      recoveryWeight: 0.2
    },
    learningEvidence: {
      increaseTriggers: ['siege_operation', 'field_fortification_build', 'bridge_construction', 'wall_defense_repair'],
      decreaseOrConfidenceLossTriggers: ['siege_tower_collapse', 'breach_defense_failure'],
      requiresDirectParticipation: true
    },
    contextualModifiers: {
      sensitiveBodyParts: ['head', 'leftArm', 'rightArm'],
      requiredEquipmentTypes: ['engineering_tools', 'timber_and_iron', 'labor_corps'],
      fatiguePenaltyScale: 1.2,
      weatherSensitivity: ['heavy_rain', 'mud', 'high_wind']
    },
    verificationScenarios: ['siege_requires_materials_and_engineering', 'fortification_assessment_and_defense']
  },

  // =========================================================================
  // 7.9 Diplomacy, Politics, and Covert Influence
  // =========================================================================
  diplomacy_politics: {
    id: 'diplomacy_politics',
    familyId: 'diplomacy_politics',
    displayName: 'Diplomacy, Politics & Covert Influence',
    displayNameTh: 'การทูต การเมือง และการเจรจาต่อรอง',
    legacyAliases: ['diplomacy'],
    subCapabilities: [
      'envoy_negotiation_persuasion_and_rhetoric',
      'alliance_building_treaties_and_guarantees',
      'court_etiquette_faction_politics_and_legitimacy',
      'officer_persuasion_defection_and_loyalty_management',
      'political_mediation_and_succession_maneuvering'
    ],
    semanticDefinition: 'Inter-faction and intra-court statecraft: formal negotiation, persuasive rhetoric, reading social cues, evaluating incentives, forging alliances, treaty drafting, hostage/guarantee reasoning, court faction management, cultivating legitimacy, inducing defection, and managing succession/power struggles.',
    boundaries: 'Allows an NPC to infer interlocutor motives from behavioral cues with explicit uncertainty; never grants telepathic knowledge of private motives.',
    prerequisites: {
      capabilities: {},
      minimumCognition: { socialInsight: 25, verbalComprehension: 25 }
    },
    relatedDomains: ['intelligence_deception', 'civil_administration', 'command_leadership', 'scholarship_planning', 'social_household'],
    axisWeights: {
      bodyWeights: { endurance: 0.5, senseAcuity: 0.5 },
      cognitiveWeights: { socialInsight: 0.32, verbalComprehension: 0.28, planning: 0.16, metacognition: 0.14, reasoning: 0.1 },
      aptitudeWeights: { socialCommerce: 0.75, command: 0.15, comprehension: 0.1 },
      interestWeights: { expression: 0.28, exchange: 0.25, companionship: 0.22, analysis: 0.15, leadership: 0.1 },
      valueWeights: { powerStatus: 0.22, honorLegacy: 0.22, sectDuty: 0.2, familyClan: 0.18, wealthResource: 0.18 },
      personalityWeights: { composure: 0.22, rationality: 0.2, empathy: 0.18, creativity: 0.15, caution: 0.15, trustfulness: 0.1 }
    },
    perceptionAndInference: {
      canPerceiveBetter: [
        'envoy_hesitation_and_leverage_points',
        'court_faction_grievances_and_ambition',
        'treaty_breach_incentives_of_rival_lords'
      ],
      inferenceBonus: 0.4,
      cannotInfer: [
        'unobserved_private_oaths_without_behavioral_clues',
        'metallurgical_quench_temperatures'
      ]
    },
    unlockedAffordances: {
      candidateActions: ['diplomacy', 'negotiate_alliance', 'mediate_faction_dispute', 'induce_enemy_defection', 'petition_imperial_court'],
      techniques: ['mutual_threat_coalition_framing', 'ritual_legitimacy_invocation', 'silver_and_title_inducement', 'hostage_guarantee_protocol'],
      masteryThresholds: { basic: 15, competent: 40, expert: 70 }
    },
    executionModifiers: {
      qualityWeight: 0.6,
      speedWeight: 0.2,
      costReductionWeight: 0.35,
      coordinationWeight: 0.45,
      errorRiskReductionWeight: 0.45,
      recoveryWeight: 0.25
    },
    learningEvidence: {
      increaseTriggers: ['diplomatic_envoy_mission', 'treaty_negotiation', 'court_debate', 'officer_recruitment_parley'],
      decreaseOrConfidenceLossTriggers: ['diplomatic_insult_incident', 'betrayed_after_naive_guarantee'],
      requiresDirectParticipation: true
    },
    contextualModifiers: {
      sensitiveBodyParts: ['head'],
      requiredEquipmentTypes: ['credentials_seal', 'diplomatic_gifts'],
      fatiguePenaltyScale: 1.15,
      weatherSensitivity: []
    },
    verificationScenarios: ['alliance_envoy_persuasion', 'inferring_interlocutor_motives_with_uncertainty']
  },

  // =========================================================================
  // 7.10 Civil Administration, Economy, and Society
  // =========================================================================
  civil_administration: {
    id: 'civil_administration',
    familyId: 'civil_administration',
    displayName: 'Civil Administration, Economy & Society',
    displayNameTh: 'การปกครองเมือง เศรษฐกิจ และสังคม',
    legacyAliases: ['governance', 'trade'],
    subCapabilities: [
      'city_governance_taxation_and_budgeting',
      'agriculture_irrigation_and_granary_management',
      'trade_market_regulation_and_procurement',
      'public_order_law_and_census_registries',
      'famine_relief_refugee_settlement_and_legitimacy'
    ],
    semanticDefinition: 'Governing commanderies and counties: taxation, treasury budgeting, market trade, agricultural expansion, irrigation works, granary reserves, corvée labor allocation, household census, law and magistrate justice, famine relief, refugee integration, and balancing military requisitions against civilian welfare.',
    boundaries: 'Provides complete support for future city/province management and economic simulation through the unified decision engine.',
    prerequisites: {
      capabilities: {},
      minimumCognition: { numeracy: 20, planning: 20 }
    },
    relatedDomains: ['logistics_sustainment', 'diplomacy_politics', 'scholarship_planning', 'craft_production', 'medicine_care'],
    axisWeights: {
      bodyWeights: { endurance: 0.7, senseAcuity: 0.3 },
      cognitiveWeights: { planning: 0.24, numeracy: 0.22, systemsThinking: 0.22, socialInsight: 0.18, verbalComprehension: 0.14 },
      aptitudeWeights: { socialCommerce: 0.55, command: 0.3, comprehension: 0.15 },
      interestWeights: { care: 0.25, leadership: 0.25, analysis: 0.25, exchange: 0.25 },
      valueWeights: { sectDuty: 0.28, wealthResource: 0.24, familyClan: 0.18, honorLegacy: 0.18, powerStatus: 0.12 },
      personalityWeights: { integrity: 0.22, discipline: 0.2, rationality: 0.2, empathy: 0.18, caution: 0.12, composure: 0.08 }
    },
    perceptionAndInference: {
      canPerceiveBetter: [
        'tax_evasion_and_corvee_burden_unrest',
        'harvest_yield_forecast_and_irrigation_silting',
        'market_grain_hoarding_and_price_inflation',
        'refugee_influx_strain_on_public_order'
      ],
      inferenceBonus: 0.35,
      cannotInfer: [
        'tactical_cavalry_skirmish_angles',
        'unreported_border_raids_without_couriers'
      ]
    },
    unlockedAffordances: {
      candidateActions: [
        'govern_city',
        'trade',
        'audit_tax_and_census_registers',
        'organize_famine_relief',
        'expand_irrigation_works',
        'settle_displaced_refugees'
      ],
      techniques: ['ever_normal_granary_stabilization', 'household_mutual_responsibility_register', 'graduated_corvee_rotation', 'merchant_caravan_charter'],
      masteryThresholds: { basic: 15, competent: 40, expert: 70 }
    },
    executionModifiers: {
      qualityWeight: 0.55,
      speedWeight: 0.25,
      costReductionWeight: 0.45,
      coordinationWeight: 0.4,
      errorRiskReductionWeight: 0.45,
      recoveryWeight: 0.35
    },
    learningEvidence: {
      increaseTriggers: ['city_governance_term', 'famine_relief_administration', 'tax_census_audit', 'trade_procurement'],
      decreaseOrConfidenceLossTriggers: ['peasant_revolt_from_overtaxation', 'granary_rot_from_neglect'],
      requiresDirectParticipation: true
    },
    contextualModifiers: {
      sensitiveBodyParts: ['head'],
      requiredEquipmentTypes: ['census_bamboo_slips', 'treasury_funds', 'granary_access'],
      fatiguePenaltyScale: 1.1,
      weatherSensitivity: ['drought', 'flood']
    },
    verificationScenarios: ['city_famine_relief_vs_heavy_taxation', 'trade_and_granary_stabilization']
  },

  // =========================================================================
  // 7.11 Medicine, Recovery, and Animal Care
  // =========================================================================
  medicine_care: {
    id: 'medicine_care',
    familyId: 'medicine_care',
    displayName: 'Medicine, Recovery & Animal Care',
    displayNameTh: 'การแพทย์ การฟื้นฟู และการดูแลม้าศึก',
    legacyAliases: ['recovery', 'medicine'],
    subCapabilities: [
      'battlefield_first_aid_trauma_and_triage',
      'herbal_pharmacology_and_wound_treatment',
      'camp_sanitation_and_epidemic_containment',
      'convalescence_and_recovery_planning',
      'veterinary_warhorse_and_pack_animal_care'
    ],
    semanticDefinition: 'Premodern Han/Three Kingdoms medical and veterinary care: arrow extraction, wound cauterization/stitching, herbal decoctions (e.g., Shanghan Lun traditions), battlefield triage, camp water/latrine sanitation to curb pestilence, recovery management, and warhorse/oxen veterinary care.',
    boundaries: 'Historically grounded premodern medicine with explicit prognostic uncertainty. Cannot perform instantaneous miracle cures; requires herbs, clean water, rest time, and sanitation.',
    prerequisites: {
      capabilities: {},
      minimumBody: { dexterity: 25 },
      minimumCognition: { attention: 25 }
    },
    relatedDomains: ['logistics_sustainment', 'scholarship_planning', 'travel_survival', 'social_household'],
    axisWeights: {
      bodyWeights: { dexterity: 0.4, senseAcuity: 0.3, recoveryRate: 0.15, immuneResilience: 0.15 },
      cognitiveWeights: { attention: 0.25, reasoning: 0.22, systemsThinking: 0.2, numeracy: 0.18, episodicMemory: 0.15 },
      aptitudeWeights: { comprehension: 0.4, crafting: 0.35, cultivation: 0.25 },
      interestWeights: { care: 0.45, analysis: 0.25, nature: 0.15, practice: 0.15 },
      valueWeights: { knowledgeCraft: 0.35, familyClan: 0.25, sectDuty: 0.25, honorLegacy: 0.15 },
      personalityWeights: { empathy: 0.3, caution: 0.25, composure: 0.2, discipline: 0.15, rationality: 0.1 }
    },
    perceptionAndInference: {
      canPerceiveBetter: [
        'wound_infection_and_fever_progression',
        'camp_water_contamination_and_epidemic_signs',
        'medicinal_herb_potency_and_toxicity',
        'warhorse_hoof_and_respiratory_ailments'
      ],
      inferenceBonus: 0.4,
      cannotInfer: [
        'enemy_battle_order_of_march',
        'siege_catapult_counterweight_geometry'
      ]
    },
    unlockedAffordances: {
      candidateActions: ['rest', 'treat_battle_wounds', 'enforce_camp_sanitation', 'prepare_herbal_remedies', 'tend_warhorses'],
      techniques: ['arrow_extraction_and_debridement', 'camp_quarantine_and_boiled_water', 'shanghan_fever_decoction', 'equine_hoof_and_forage_rehab'],
      masteryThresholds: { basic: 15, competent: 40, expert: 70 }
    },
    executionModifiers: {
      qualityWeight: 0.6,
      speedWeight: 0.2,
      costReductionWeight: 0.25,
      coordinationWeight: 0.25,
      errorRiskReductionWeight: 0.55,
      recoveryWeight: 0.65
    },
    learningEvidence: {
      increaseTriggers: ['wound_treatment_case', 'epidemic_containment', 'herbal_compounding', 'veterinary_care_cycle'],
      decreaseOrConfidenceLossTriggers: ['patient_sepsis_after_botched_care', 'camp_plague_outbreak_unnoticed'],
      requiresDirectParticipation: true
    },
    contextualModifiers: {
      sensitiveBodyParts: ['leftArm', 'rightArm', 'head'],
      requiredEquipmentTypes: ['medical_herbs', 'clean_bandages', 'surgical_knives'],
      fatiguePenaltyScale: 1.25,
      weatherSensitivity: ['damp_heat', 'freezing_cold']
    },
    verificationScenarios: ['physician_treats_wounded_general_and_prevents_epidemic', 'dexterity_and_herbs_affect_treatment_risk']
  },

  // =========================================================================
  // 7.12 Craft, Production, and Technology
  // =========================================================================
  craft_production: {
    id: 'craft_production',
    familyId: 'craft_production',
    displayName: 'Craft, Production & Technology',
    displayNameTh: 'งานช่าง การผลิตอาวุธยุทโธปกรณ์ และเทคโนโลยี',
    legacyAliases: ['crafting'],
    subCapabilities: [
      'metallurgy_weapon_and_armor_smithing',
      'carpentry_shipbuilding_and_wagon_making',
      'bowyer_fletcher_and_crossbow_mechanism_craft',
      'textiles_leatherworking_and_food_preservation',
      'toolmaking_surveying_and_workshop_management'
    ],
    semanticDefinition: 'Material fabrication, maintenance, and workshop production: forging steel blades and lamellar armor, casting bronze crossbow triggers, shipbuilding and hull repair, wagon and siege-part carpentry, leather curing, food salting/drying, and resource-efficient workshop organization.',
    boundaries: 'Output quality and speed depend jointly on craft_production mastery, material quality, tools, labor, and time.',
    prerequisites: {
      capabilities: {},
      minimumBody: { dexterity: 20, strength: 20 }
    },
    relatedDomains: ['siege_engineering', 'naval_warfare', 'individual_combat', 'logistics_sustainment'],
    axisWeights: {
      bodyWeights: { dexterity: 0.35, strength: 0.25, coordination: 0.2, endurance: 0.2 },
      cognitiveWeights: { spatialReasoning: 0.28, numeracy: 0.24, attention: 0.22, systemsThinking: 0.16, planning: 0.1 },
      aptitudeWeights: { crafting: 0.8, comprehension: 0.2 },
      interestWeights: { creation: 0.45, practice: 0.3, analysis: 0.15, exertion: 0.1 },
      valueWeights: { knowledgeCraft: 0.4, wealthResource: 0.25, sectDuty: 0.2, honorLegacy: 0.15 },
      personalityWeights: { discipline: 0.3, caution: 0.22, creativity: 0.22, rationality: 0.16, composure: 0.1 }
    },
    perceptionAndInference: {
      canPerceiveBetter: [
        'steel_quench_temper_and_armor_brittleness',
        'crossbow_trigger_casting_tolerances',
        'ship_hull_timber_seasoning_and_rot',
        'workshop_material_waste_and_bottlenecks'
      ],
      inferenceBonus: 0.35,
      cannotInfer: [
        'diplomatic_alliance_secret_terms',
        'distant_enemy_cavalry_scouting_routes'
      ]
    },
    unlockedAffordances: {
      candidateActions: ['forge_weapons_and_armor', 'repair_fleet_vessels', 'manufacture_crossbow_triggers', 'preserve_campaign_rations'],
      techniques: ['hundred_refinements_steel_forging', 'standardized_bronze_crossbow_lock', 'watertight_compartment_caulking', 'lamellar_armor_lacing'],
      masteryThresholds: { basic: 15, competent: 40, expert: 70 }
    },
    executionModifiers: {
      qualityWeight: 0.65,
      speedWeight: 0.3,
      costReductionWeight: 0.45,
      coordinationWeight: 0.25,
      errorRiskReductionWeight: 0.5,
      recoveryWeight: 0.15
    },
    learningEvidence: {
      increaseTriggers: ['weapon_armor_forging_batch', 'ship_hull_construction', 'crossbow_mechanism_assembly', 'equipment_field_repair'],
      decreaseOrConfidenceLossTriggers: ['failed_smelt_or_cracked_batch', 'structural_failure_of_crafted_gear'],
      requiresDirectParticipation: true
    },
    contextualModifiers: {
      sensitiveBodyParts: ['leftArm', 'rightArm', 'torso'],
      requiredEquipmentTypes: ['forge_and_tools', 'raw_iron_timber_leather'],
      fatiguePenaltyScale: 1.25,
      weatherSensitivity: ['high_humidity']
    },
    verificationScenarios: ['craftsman_repairs_weapons_and_builds_ship_components']
  },

  // =========================================================================
  // 7.13 Scholarship, Communication, and Planning Tools
  // =========================================================================
  scholarship_planning: {
    id: 'scholarship_planning',
    familyId: 'scholarship_planning',
    displayName: 'Scholarship, Communication & Planning Tools',
    displayNameTh: 'อักษรศาสตร์ การแผนที่ การคำนวณ และสารสนเทศ',
    legacyAliases: ['scholarship'],
    subCapabilities: [
      'literacy_official_memorials_and_recordkeeping',
      'cartography_map_reading_and_geography',
      'arithmetic_measurement_and_accounting',
      'calendar_astronomy_and_weather_observation',
      'historical_classics_and_translation'
    ],
    semanticDefinition: 'Intellectual and informational tools of the Han/Three Kingdoms literati: reading and drafting official memorials/orders, recordkeeping, cartography and map interpretation, arithmetic/Nine Chapters calculation, calendar and meteorological observation, historical annals, and cross-dialect/frontier translation.',
    boundaries: 'Provides the foundational literacy, numeracy, cartographic, and meteorological tools that amplify strategy, logistics, administration, and intelligence.',
    prerequisites: {
      capabilities: {},
      minimumCognition: { verbalComprehension: 25, reasoning: 20 }
    },
    relatedDomains: ['strategy_doctrine', 'civil_administration', 'logistics_sustainment', 'diplomacy_politics', 'medicine_care'],
    axisWeights: {
      bodyWeights: { senseAcuity: 0.6, dexterity: 0.4 },
      cognitiveWeights: { verbalComprehension: 0.25, reasoning: 0.22, numeracy: 0.2, episodicMemory: 0.18, systemsThinking: 0.15 },
      aptitudeWeights: { comprehension: 0.7, socialCommerce: 0.3 },
      interestWeights: { analysis: 0.4, expression: 0.25, tranquility: 0.2, practice: 0.15 },
      valueWeights: { knowledgeCraft: 0.45, honorLegacy: 0.25, sectDuty: 0.2, freedom: 0.1 },
      personalityWeights: { curiosity: 0.3, rationality: 0.25, discipline: 0.2, caution: 0.15, composure: 0.1 }
    },
    perceptionAndInference: {
      canPerceiveBetter: [
        'cartographic_scale_errors_and_terrain_corridors',
        'seasonal_monsoon_and_river_flood_patterns',
        'accounting_discrepancies_in_ledgers',
        'historical_precedents_for_political_crises'
      ],
      inferenceBonus: 0.4,
      cannotInfer: [
        'immediate_melee_feint_timing',
        'unrecorded_secret_troop_deployments'
      ]
    },
    unlockedAffordances: {
      candidateActions: ['compile_regional_map', 'forecast_seasonal_weather', 'draft_imperial_memorial', 'audit_campaign_archives'],
      techniques: ['peixiu_grid_cartography', 'jiuzhang_grain_volume_calculus', 'seasonal_barometric_sky_reading', 'chancery_edict_composition'],
      masteryThresholds: { basic: 15, competent: 40, expert: 70 }
    },
    executionModifiers: {
      qualityWeight: 0.55,
      speedWeight: 0.25,
      costReductionWeight: 0.3,
      coordinationWeight: 0.35,
      errorRiskReductionWeight: 0.5,
      recoveryWeight: 0.15
    },
    learningEvidence: {
      increaseTriggers: ['archive_study', 'map_survey_compilation', 'weather_observation_log', 'edict_and_ledger_drafting'],
      decreaseOrConfidenceLossTriggers: ['map_error_causes_march_delay', 'misread_weather_window'],
      requiresDirectParticipation: true
    },
    contextualModifiers: {
      sensitiveBodyParts: ['head', 'rightArm'],
      requiredEquipmentTypes: ['writing_materials', 'maps_and_scrolls', 'measuring_rods'],
      fatiguePenaltyScale: 1.2,
      weatherSensitivity: []
    },
    verificationScenarios: ['cartography_and_weather_forecasting_unlock_informed_plans']
  },

  // =========================================================================
  // 7.14 Travel, Terrain, Survival, and Environment
  // =========================================================================
  travel_survival: {
    id: 'travel_survival',
    familyId: 'travel_survival',
    displayName: 'Travel, Terrain, Survival & Environment',
    displayNameTh: 'การเดินทาง ภูมิประเทศ และการยังชีพในสนาม',
    legacyAliases: ['survival', 'expedition'],
    subCapabilities: [
      'land_and_river_route_finding_and_navigation',
      'mountain_forest_marsh_and_ford_traversal',
      'stealth_concealment_and_tracking',
      'camping_water_finding_hunting_and_foraging',
      'weather_exposure_and_pack_animal_handling'
    ],
    semanticDefinition: 'Moving and surviving across harsh Three Kingdoms landscapes (Qinling plank roads, Yangtze marshes, northern steppes, southern jungles): route selection, pathfinding, stealth movement, camp siting, finding clean water, hunting/foraging, enduring extreme weather, and handling mounts/pack animals.',
    boundaries: 'Covers environmental traversal and survival under scarcity. Distinct from large-scale supply administration (logistics_sustainment) and tactical combat formations (land_warfare).',
    prerequisites: {
      capabilities: {},
      minimumBody: { endurance: 20, mobility: 20 }
    },
    relatedDomains: ['intelligence_deception', 'logistics_sustainment', 'land_warfare', 'naval_warfare', 'medicine_care'],
    axisWeights: {
      bodyWeights: { endurance: 0.3, mobility: 0.25, agility: 0.2, senseAcuity: 0.15, balance: 0.1 },
      cognitiveWeights: { spatialReasoning: 0.35, attention: 0.25, planning: 0.2, metacognition: 0.2 },
      aptitudeWeights: { combat: 0.4, command: 0.3, cultivation: 0.3 },
      interestWeights: { exploration: 0.4, nature: 0.35, exertion: 0.15, risk: 0.1 },
      valueWeights: { freedom: 0.35, sectDuty: 0.25, familyClan: 0.2, martialPeak: 0.2 },
      personalityWeights: { caution: 0.25, courage: 0.25, composure: 0.25, curiosity: 0.15, discipline: 0.1 }
    },
    perceptionAndInference: {
      canPerceiveBetter: [
        'mountain_plank_road_rockfall_hazards',
        'flash_flood_watermarks_in_ravines',
        'forageable_roots_and_clean_spring_sources',
        'trail_spoor_age_and_party_size'
      ],
      inferenceBonus: 0.35,
      cannotInfer: [
        'capital_court_tax_legislation',
        'complex_siege_trebuchet_ballistics'
      ]
    },
    unlockedAffordances: {
      candidateActions: ['guide_mountain_march', 'forage_and_secure_water', 'establish_concealed_bivouac', 'traverse_marsh_shortcut'],
      techniques: ['plank_road_rope_traverse', 'smokeless_hidden_camp', 'river_ford_sounding', 'steppe_wind_shelter_bivouac'],
      masteryThresholds: { basic: 15, competent: 40, expert: 70 }
    },
    executionModifiers: {
      qualityWeight: 0.5,
      speedWeight: 0.45,
      costReductionWeight: 0.35,
      coordinationWeight: 0.25,
      errorRiskReductionWeight: 0.5,
      recoveryWeight: 0.35
    },
    learningEvidence: {
      increaseTriggers: ['wilderness_march', 'mountain_pass_crossing', 'foraging_expedition', 'harsh_weather_bivouac'],
      decreaseOrConfidenceLossTriggers: ['lost_in_mountain_fog', 'non_battle_exposure_casualties'],
      requiresDirectParticipation: true
    },
    contextualModifiers: {
      sensitiveBodyParts: ['leftLeg', 'rightLeg', 'torso'],
      requiredEquipmentTypes: ['travel_rations', 'rope_and_cloaks'],
      fatiguePenaltyScale: 1.3,
      weatherSensitivity: ['heavy_rain', 'snow_freeze', 'fog', 'extreme_heat']
    },
    verificationScenarios: ['mountain_march_survival_and_route_selection']
  },

  // =========================================================================
  // 7.15 Social, Household, and Personal Development
  // =========================================================================
  social_household: {
    id: 'social_household',
    familyId: 'social_household',
    displayName: 'Social, Household & Personal Development',
    displayNameTh: 'ความสัมพันธ์ ครัวเรือน และการพัฒนาตน',
    legacyAliases: ['social', 'household', 'mentoring'],
    subCapabilities: [
      'mentoring_teaching_and_knowledge_transfer',
      'self_reflection_and_learning_strategy',
      'household_clan_and_dependent_stewardship',
      'interpersonal_trust_and_conflict_mediation',
      'reputation_and_competing_obligation_management'
    ],
    semanticDefinition: 'Managing personal bonds, sworn brotherhoods, clan/household dependents, mentoring junior officers, self-reflection, reconciling competing duties (filial family vs state loyalty), and maintaining personal honor and composure.',
    boundaries: 'Grounded in the NPCs existing values, personality, relationships, and commitments. Shapes how NPCs teach others, manage personal stress/grief, and resolve loyalty dilemmas.',
    prerequisites: {
      capabilities: {},
      minimumCognition: { socialInsight: 15, metacognition: 15 }
    },
    relatedDomains: ['command_leadership', 'diplomacy_politics', 'scholarship_planning', 'medicine_care'],
    axisWeights: {
      bodyWeights: { endurance: 0.5, recoveryRate: 0.5 },
      cognitiveWeights: { socialInsight: 0.3, metacognition: 0.25, verbalComprehension: 0.2, episodicMemory: 0.15, planning: 0.1 },
      aptitudeWeights: { socialCommerce: 0.45, comprehension: 0.35, cultivation: 0.2 },
      interestWeights: { companionship: 0.3, care: 0.25, expression: 0.2, tranquility: 0.15, practice: 0.1 },
      valueWeights: { familyClan: 0.3, honorLegacy: 0.25, sectDuty: 0.2, knowledgeCraft: 0.15, freedom: 0.1 },
      personalityWeights: { empathy: 0.24, integrity: 0.2, loyalty: 0.2, composure: 0.18, discipline: 0.18 }
    },
    perceptionAndInference: {
      canPerceiveBetter: [
        'subordinate_or_sworn_sibling_grief_and_burnout',
        'clan_household_vulnerability_and_obligation_strain',
        'own_cognitive_fatigue_and_overconfidence_bias'
      ],
      inferenceBonus: 0.3,
      cannotInfer: [
        'enemy_naval_formation_signals',
        'metallurgical_alloy_ratios'
      ]
    },
    unlockedAffordances: {
      candidateActions: ['mentor_junior_officer', 'reconcile_ally_conflict', 'manage_clan_household', 'reflect_and_consolidate_lessons'],
      techniques: ['sworn_oath_bond_reinforcement', 'structured_case_mentoring', 'filial_and_state_duty_reconciliation', 'meditative_composure_recovery'],
      masteryThresholds: { basic: 15, competent: 40, expert: 70 }
    },
    executionModifiers: {
      qualityWeight: 0.5,
      speedWeight: 0.2,
      costReductionWeight: 0.2,
      coordinationWeight: 0.5,
      errorRiskReductionWeight: 0.4,
      recoveryWeight: 0.45
    },
    learningEvidence: {
      increaseTriggers: ['mentoring_session', 'interpersonal_mediation', 'reflection_consolidation', 'household_crisis_stewardship'],
      decreaseOrConfidenceLossTriggers: ['sworn_bond_rupture', 'unmanaged_burnout_breakdown'],
      requiresDirectParticipation: true
    },
    contextualModifiers: {
      sensitiveBodyParts: ['head'],
      requiredEquipmentTypes: [],
      fatiguePenaltyScale: 1.05,
      weatherSensitivity: []
    },
    verificationScenarios: ['mentoring_accelerates_junior_learning', 'resolving_ally_conflict_and_obligation_tension']
  }
});

// Build alias lookup table so legacy skillDomains ('combat', 'tactics', 'siegecraft', 'defense', 'governance', etc.)
// resolve seamlessly to the canonical 15 capability domains while preserving exact skill keys when requested.
const ALIAS_TO_DOMAIN_ID = Object.create(null);
for (const domain of Object.values(CAPABILITY_DOMAINS)) {
  ALIAS_TO_DOMAIN_ID[domain.id] = domain.id;
  for (const alias of domain.legacyAliases || []) {
    ALIAS_TO_DOMAIN_ID[alias] = domain.id;
  }
  for (const sub of domain.subCapabilities || []) {
    ALIAS_TO_DOMAIN_ID[sub] = domain.id;
  }
}

function resolveCapabilityDomainId(idOrAlias) {
  if (!idOrAlias) return null;
  return ALIAS_TO_DOMAIN_ID[String(idOrAlias)] || null;
}

function getCapabilityDomain(idOrAlias) {
  const canonicalId = resolveCapabilityDomainId(idOrAlias);
  if (!canonicalId) {
    throw new NpcEngineError(ERROR_CODES.INVALID_CAPABILITY, `Unknown capability domain: ${idOrAlias}`);
  }
  return CAPABILITY_DOMAINS[canonicalId];
}

function listCapabilityDomains() {
  return Object.values(CAPABILITY_DOMAINS);
}

module.exports = {
  CAPABILITY_FAMILIES,
  CAPABILITY_DOMAINS,
  ALIAS_TO_DOMAIN_ID,
  resolveCapabilityDomainId,
  getCapabilityDomain,
  listCapabilityDomains
};

  };
  __MODULES['condition_system'] = function(module, exports, require, globalThis) {
'use strict';

/**
 * Condition, Readiness, Injuries, Emotions, and Time Advancement Module
 * Preserves 100% compatibility with v1.0 condition/effective/injure/recover/tick/emotions
 * while adding structured campaign readiness, morale, illness/exposure, and equipment state.
 */

const { clamp, round, hash, isObject } = __require('utils');
const { raw, parts } = __require('identity_core');

function ensureExtendedConditionState(npc) {
  if (!npc.stageLocal) npc.stageLocal = {};
  if (!isObject(npc.stageLocal.readiness)) {
    npc.stageLocal.readiness = {
      morale: 80,
      illness: 0,
      exposure: 0,
      supplyDays: 30,
      equipmentReadiness: 100
    };
  }
  return npc.stageLocal.readiness;
}

/**
 * Computes condition summary (exact v1.0 fields + extended readiness fields)
 */
function condition(n) {
  const h = n.core.human;
  const s = n.stageLocal?.needs || {};
  const c = n.core.condition || {};
  const r = n.stageLocal?.readiness || {};
  const max = n.stageLocal?.boss ? 240 : 100;
  const fatigue = clamp(c.fatigue ?? 0);
  const hunger = clamp(s.hunger ?? 0);
  const stress = clamp(c.moodStress ?? 0);
  const pain = h.state.pain * (1 - raw(n, 'body', 'painTolerance') * 0.005);
  const healthRatio = clamp(n.health, 0, max) / max;
  const morale = clamp(r.morale ?? 80);
  const illness = clamp(r.illness ?? 0);
  const exposure = clamp(r.exposure ?? 0);
  const supplyDays = Math.max(0, Number.isFinite(r.supplyDays) ? r.supplyDays : 30);
  const equipmentReadiness = clamp(r.equipmentReadiness ?? 100);

  return {
    fatigue,
    hunger,
    stress,
    pain: round(pain),
    healthRatio: round(healthRatio),
    morale,
    illness,
    exposure,
    supplyDays,
    equipmentReadiness
  };
}

/**
 * Effective axis value accounting for fatigue, hunger, stress, pain, illness, and body-part injuries.
 * Preserves exact v1.0 formula when illness/exposure are 0.
 */
function effective(n, kind, id) {
  const base = raw(n, kind, id);
  if (kind === 'body' && ['recoveryRate', 'immuneResilience', 'metabolism', 'painTolerance'].includes(id)) {
    return base;
  }
  const s = condition(n);
  const p = n.core.human.state.parts;
  let loss = kind === 'cognition'
    ? s.fatigue * 0.0022 + s.hunger * 0.0013 + s.stress * 0.0017 + s.pain * 0.0012 + s.illness * 0.002
    : s.fatigue * 0.002 + s.hunger * 0.0011 + (1 - s.healthRatio) * 0.2 + s.pain * 0.0015 + s.illness * 0.0025 + s.exposure * 0.0015;

  if (kind === 'body') {
    loss += p.torso * 0.0015;
    if (['dexterity', 'strength', 'power', 'coordination'].includes(id)) {
      loss += (p.leftArm + p.rightArm) * 0.003;
    }
    if (['agility', 'balance', 'mobility', 'endurance'].includes(id)) {
      loss += (p.leftLeg + p.rightLeg) * 0.003;
    }
    if (id === 'senseAcuity') {
      loss += p.head * 0.004;
    }
  } else {
    loss += p.head * 0.004 + p.torso * 0.0005;
  }
  return round(clamp(base * Math.max(0.25, 1 - loss)));
}

function weighted(n, kind, weights, eff = true) {
  let sum = 0;
  let total = 0;
  for (const [k, w] of Object.entries(weights || {})) {
    sum += (eff ? effective(n, kind, k) : raw(n, kind, k)) * w;
    total += w;
  }
  return total ? sum / total : 50;
}

function clarity(n) {
  return round(weighted(n, 'cognition', {
    reasoning: 0.14,
    planning: 0.2,
    workingMemory: 0.12,
    attention: 0.2,
    processingSpeed: 0.1,
    metacognition: 0.24
  }));
}

function temperature(n) {
  return round(clamp(15 - clarity(n) * 0.12, 4, 14));
}

function movement(n) {
  return clamp(
    0.65 + (
      effective(n, 'body', 'agility') * 0.36 +
      effective(n, 'body', 'balance') * 0.2 +
      effective(n, 'body', 'mobility') * 0.24 +
      effective(n, 'body', 'coordination') * 0.2
    ) * 0.007,
    0.4,
    1.35
  );
}

function carryLimit(n) {
  return Math.floor(8 + raw(n, 'body', 'strength') * 0.18 + raw(n, 'body', 'endurance') * 0.1);
}

function load(n) {
  return (n.jianghu?.ledgerV140?.materialStacks || []).reduce((s, x) => s + Math.max(0, x.count || 0), 0);
}

function travelSpeed(n, base = 48) {
  const burden = Math.max(0.6, 1 - Math.max(0, load(n) - carryLimit(n)) * 0.015);
  return base * movement(n) * burden;
}

function combat(n) {
  return clamp(
    0.7 + (
      effective(n, 'body', 'strength') * 0.24 +
      effective(n, 'body', 'power') * 0.24 +
      effective(n, 'body', 'agility') * 0.18 +
      effective(n, 'body', 'coordination') * 0.12 +
      effective(n, 'cognition', 'spatialReasoning') * 0.12 +
      effective(n, 'body', 'balance') * 0.1
    ) * 0.006,
    0.45,
    1.3
  );
}

function damageMultiplier(n) {
  return clamp(1.17 - effective(n, 'body', 'durability') * 0.0034, 0.82, 1.2);
}

function recovery(n) {
  return clamp(0.55 + (raw(n, 'body', 'recoveryRate') * 0.7 + raw(n, 'body', 'immuneResilience') * 0.3) * 0.009, 0.55, 1.45);
}

function injure(n, amount, time = 0, targetPart = null) {
  const h = n.core.human;
  if (!h) return;
  const p = targetPart && parts.includes(targetPart)
    ? targetPart
    : parts[(hash(n.id) + Math.floor(time * 10)) % parts.length];
  h.state.parts[p] = round(clamp(h.state.parts[p] + amount * 0.16));
  h.state.pain = round(clamp(h.state.pain + amount * 0.5));
}

function recover(n, amount) {
  const s = n.core.human.state;
  s.pain = round(clamp(s.pain - amount));
  for (const p of parts) {
    s.parts[p] = round(clamp(s.parts[p] - amount * 0.35));
  }
  if (n.stageLocal?.readiness) {
    n.stageLocal.readiness.illness = round(clamp((n.stageLocal.readiness.illness || 0) - amount * 0.4));
    n.stageLocal.readiness.exposure = round(clamp((n.stageLocal.readiness.exposure || 0) - amount * 0.5));
  }
}

function tick(n, dt) {
  const h = n.core.human;
  const s = n.stageLocal;
  if (!s?.needs) return;
  s.needs.hunger = clamp(s.needs.hunger + dt * 0.12 * (0.65 + raw(n, 'body', 'metabolism') * 0.007));
  s.needs.social = clamp(s.needs.social + dt * (0.025 + raw(n, 'interest', 'companionship') * 0.0005));
  s.needs.safety = clamp(100 - n.health);
  h.state.autonomy = clamp(h.state.autonomy + dt * 0.025);
  h.state.competence = clamp(h.state.competence + dt * 0.03);
  h.state.stimulation = clamp(h.state.stimulation + dt * (s.lastWork !== null && s.lastWork === s.action ? 0.06 : 0.025));
  h.state.grief = Math.max(0, h.state.grief - dt * 0.01);

  const active = ['travel', 'combat', 'working'].includes(s.mode) && !['rest', 'heal', 'eat', 'seclusion'].includes(s.action);
  if (active) {
    n.core.condition.fatigue = clamp(
      n.core.condition.fatigue + dt * (0.018 + (100 - raw(n, 'body', 'endurance')) * 0.0007) * (s.mode === 'combat' ? 2 : 1)
    );
  } else if (['rest', 'heal'].includes(s.action)) {
    const rec = recovery(n);
    n.core.condition.fatigue = clamp(n.core.condition.fatigue - dt * 0.08 * rec);
    recover(n, dt * 0.05 * rec);
  }

  n.core.condition.moodStress = clamp(
    s.needs.hunger * 0.16 +
    s.needs.social * 0.15 +
    (100 - n.health) * 0.25 +
    h.state.pain * 0.15 +
    (h.state.autonomy + h.state.competence + h.state.stimulation) * 0.045 +
    h.state.grief * 0.2
  );
  if (n.jianghu?.poisonAccumulated > 0) {
    n.jianghu.poisonAccumulated = Math.max(0, n.jianghu.poisonAccumulated - dt * raw(n, 'body', 'immuneResilience') * 0.0004);
  }
  if (s.readiness && Number.isFinite(s.readiness.illness) && s.readiness.illness > 0) {
    s.readiness.illness = round(Math.max(0, s.readiness.illness - dt * raw(n, 'body', 'immuneResilience') * 0.0005));
  }
}

function emotions(n) {
  const s = n.core.human.state;
  const c = condition(n);
  return {
    valence: round(clamp(80 - c.stress * 0.7 - s.grief * 0.25)),
    arousal: round(clamp(25 + (n.stageLocal?.danger || 0) * 0.4 + c.stress * 0.2)),
    fear: round(clamp((n.stageLocal?.danger || 0) * 0.5 + c.pain * 0.25 + (1 - c.healthRatio) * 35)),
    confidence: round(clamp(25 + clarity(n) * 0.5 - s.competence * 0.12 + Math.min(20, n.core.human.experience.completed))),
    grief: round(s.grief)
  };
}

module.exports = {
  ensureExtendedConditionState,
  condition,
  effective,
  weighted,
  clarity,
  temperature,
  movement,
  carryLimit,
  load,
  travelSpeed,
  combat,
  damageMultiplier,
  recovery,
  injure,
  recover,
  tick,
  emotions
};

  };
  __MODULES['knowledge_system'] = function(module, exports, require, globalThis) {
'use strict';

/**
 * Capability Mastery, Explicit Knowledge, and Learned Techniques System
 *
 * Enforces strict separation between:
 * 1. Innate Identity/Personality/Values (priorities, risk tolerance, style)
 * 2. Innate Aptitudes & Physical/Cognitive Capacities (learning rate & foundation)
 * 3. Capability-Domain Mastery (demonstrated competence in a Three Kingdoms domain)
 * 4. Explicit Knowledge (facts, treatises, maps, doctrines, local geography — with source & confidence)
 * 5. Learned Techniques (procedural methods with capability & knowledge prerequisites)
 * 6. Interests (willingness & persistence — never grants competence)
 */

const { NpcEngineError, ERROR_CODES, clamp, round, isObject } = __require('utils');
const { raw } = __require('identity_core');
const { condition, effective, weighted } = __require('condition_system');
const {
  CAPABILITY_DOMAINS,
  resolveCapabilityDomainId,
  getCapabilityDomain
} = __require('capability_ontology');

function ensureKnowledgeAndTechniqueState(npc) {
  const h = npc?.core?.human;
  if (!h) throw new NpcEngineError(ERROR_CODES.INVALID_NPC, 'NPC requires core.human before initializing knowledge state');
  if (!isObject(h.experience.knowledge)) h.experience.knowledge = {};
  if (!isObject(h.experience.techniques)) h.experience.techniques = {};
  if (!isObject(h.experience.domainAttribution)) h.experience.domainAttribution = {};
  return h.experience;
}

/**
 * Reads the learned skill/mastery level (0..100) for a skillDomain or capabilityId.
 * Checks exact key first (for 100% legacy compatibility), then canonical capability domain ID and its aliases.
 */
function getSkillLevel(npc, domainOrSkillId) {
  const skills = npc?.core?.human?.experience?.skills || {};
  if (skills[domainOrSkillId] && Number.isFinite(skills[domainOrSkillId].level)) {
    return skills[domainOrSkillId].level;
  }
  const canonicalId = resolveCapabilityDomainId(domainOrSkillId);
  if (canonicalId && skills[canonicalId] && Number.isFinite(skills[canonicalId].level)) {
    return skills[canonicalId].level;
  }
  if (canonicalId && CAPABILITY_DOMAINS[canonicalId]) {
    for (const alias of CAPABILITY_DOMAINS[canonicalId].legacyAliases || []) {
      if (skills[alias] && Number.isFinite(skills[alias].level)) {
        return skills[alias].level;
      }
    }
  }
  return 0;
}

/**
 * Sets or initializes starting capability mastery (e.g., for scenario/preset initialization).
 * Synchronizes both canonical capability domain ID and primary legacy alias if applicable.
 */
function setCapabilityMastery(npc, domainId, level, practice = null) {
  if (!Number.isFinite(level) || level < 0 || level > 100) {
    throw new NpcEngineError(ERROR_CODES.INVALID_CAPABILITY, `Mastery level must be 0..100 for ${domainId}`);
  }
  const canonicalId = resolveCapabilityDomainId(domainId) || String(domainId);
  const skills = npc.core.human.experience.skills;
  const computedPractice = Number.isFinite(practice) && practice >= 0 ? round(practice) : round(level * 1.2);
  skills[canonicalId] = { level: round(level), practice: computedPractice };
  if ( domainId !== canonicalId ) {
    skills[domainId] = { level: round(level), practice: computedPractice };
  }
  const domainDef = CAPABILITY_DOMAINS[canonicalId];
  if (domainDef && Array.isArray(domainDef.legacyAliases)) {
    for (const alias of domainDef.legacyAliases) {
      if (!skills[alias] || skills[alias].level < level) {
        skills[alias] = { level: round(level), practice: computedPractice };
      }
    }
  }
  return skills[canonicalId];
}

/**
 * Grants or updates an explicit Knowledge record on the NPC.
 * Knowledge has: id, category, domainId, confidence (0..1), source, acquiredAt, lastVerifiedAt, practiced (bool), details.
 */
function grantKnowledge(npc, knowledgeRecord) {
  ensureKnowledgeAndTechniqueState(npc);
  if (!isObject(knowledgeRecord) || !knowledgeRecord.id || String(knowledgeRecord.id).trim() === '') {
    throw new NpcEngineError(ERROR_CODES.INVALID_KNOWLEDGE, 'Knowledge record requires a non-empty id');
  }
  const id = String(knowledgeRecord.id).trim();
  const existing = npc.core.human.experience.knowledge[id];
  const confidence = clamp((knowledgeRecord.confidence ?? 0.85) * 100, 0, 100) / 100;
  const now = Number.isFinite(knowledgeRecord.acquiredAt) ? knowledgeRecord.acquiredAt : (existing?.acquiredAt ?? 0);

  const rec = {
    id,
    title: knowledgeRecord.title || id,
    category: knowledgeRecord.category || 'general', // 'doctrine' | 'geography' | 'treatise' | 'intelligence' | 'procedure' | 'person'
    domainId: resolveCapabilityDomainId(knowledgeRecord.domainId) || knowledgeRecord.domainId || 'scholarship_planning',
    confidence: round(confidence),
    source: knowledgeRecord.source || 'study', // 'witnessed' | 'study' | 'scout_report' | 'rumor' | 'mentor'
    acquiredAt: now,
    lastVerifiedAt: Number.isFinite(knowledgeRecord.lastVerifiedAt) ? knowledgeRecord.lastVerifiedAt : now,
    practiced: Boolean(knowledgeRecord.practiced ?? existing?.practiced ?? false),
    facts: isObject(knowledgeRecord.facts) ? { ...(existing?.facts || {}), ...knowledgeRecord.facts } : (existing?.facts || {})
  };
  npc.core.human.experience.knowledge[id] = rec;
  return rec;
}

function hasKnowledge(npc, knowledgeId, minConfidence = 0.4) {
  const rec = npc?.core?.human?.experience?.knowledge?.[knowledgeId];
  if (!rec) return false;
  return rec.confidence >= minConfidence;
}

function getKnowledge(npc, knowledgeId) {
  return npc?.core?.human?.experience?.knowledge?.[knowledgeId] || null;
}

/**
 * Grants or updates a learned Technique/Procedure on the NPC.
 * Checks prerequisites unless `{ force: true }` is passed during scenario setup.
 */
function learnTechnique(npc, techniqueDef, options = {}) {
  ensureKnowledgeAndTechniqueState(npc);
  if (!isObject(techniqueDef) || !techniqueDef.id || String(techniqueDef.id).trim() === '') {
    throw new NpcEngineError(ERROR_CODES.INVALID_TECHNIQUE, 'Technique requires a stable id');
  }
  const id = String(techniqueDef.id).trim();
  const domainId = resolveCapabilityDomainId(techniqueDef.domainId) || techniqueDef.domainId || 'individual_combat';
  const requiredMastery = Number.isFinite(techniqueDef.requiredMastery) ? techniqueDef.requiredMastery : 15;
  const requiredKnowledge = Array.isArray(techniqueDef.requiredKnowledge) ? techniqueDef.requiredKnowledge : [];

  if (!options.force) {
    const currentMastery = getSkillLevel(npc, domainId);
    if (currentMastery < requiredMastery) {
      return {
        learned: false,
        reason: 'INSUFFICIENT_DOMAIN_MASTERY',
        domainId,
        currentMastery,
        requiredMastery
      };
    }
    for (const kId of requiredKnowledge) {
      if (!hasKnowledge(npc, kId, 0.5)) {
        return {
          learned: false,
          reason: 'MISSING_PREREQUISITE_KNOWLEDGE',
          missingKnowledgeId: kId
        };
      }
    }
  }

  const existing = npc.core.human.experience.techniques[id];
  const proficiency = clamp(techniqueDef.proficiency ?? existing?.proficiency ?? 50, 0, 100);
  const rec = {
    id,
    name: techniqueDef.name || id,
    domainId,
    requiredMastery,
    requiredKnowledge,
    proficiency: round(proficiency),
    uses: Number.isInteger(techniqueDef.uses) ? techniqueDef.uses : (existing?.uses ?? 0),
    learnedAt: Number.isFinite(techniqueDef.learnedAt) ? techniqueDef.learnedAt : (existing?.learnedAt ?? 0)
  };
  npc.core.human.experience.techniques[id] = rec;
  return { learned: true, technique: rec };
}

function hasTechnique(npc, techniqueId, minProficiency = 1) {
  const rec = npc?.core?.human?.experience?.techniques?.[techniqueId];
  return !!rec && rec.proficiency >= minProficiency;
}

/**
 * Evaluates full capability profile for a canonical capability domain on an NPC.
 * Explicitly separates:
 * - naturalFoundation (effective body + effective cognition)
 * - innateAptitude (raw aptitude for learning rate & natural ease — does NOT grant mastery or facts)
 * - domainMastery (demonstrated procedural skill 0..100)
 * - domainKnowledgeCount & practicedRatio
 * - interestScore (willingness & persistence — does NOT add to competence!)
 * - conditionModifier (injury, fatigue, morale, equipment effects)
 * - effectiveCompetence (execution competence combining foundation, mastery, and condition)
 */
function evaluateCapabilityDomain(npc, domainIdOrAlias, context = {}) {
  const domain = getCapabilityDomain(domainIdOrAlias);
  const bodyScore = weighted(npc, 'body', domain.axisWeights.bodyWeights, true);
  const cognitionScore = weighted(npc, 'cognition', domain.axisWeights.cognitiveWeights, true);
  const rawBodyScore = weighted(npc, 'body', domain.axisWeights.bodyWeights, false);
  const rawCognitionScore = weighted(npc, 'cognition', domain.axisWeights.cognitiveWeights, false);
  const aptitudeScore = weighted(npc, 'aptitude', domain.axisWeights.aptitudeWeights, false);

  const mastery = getSkillLevel(npc, domain.id);
  const interest = round(clamp(
    50 + Object.entries(domain.axisWeights.interestWeights || {}).reduce(
      (s, [k, w]) => s + (raw(npc, 'interest', k) - 50) * w,
      0
    )
  ));

  const hasBody = Object.keys(domain.axisWeights.bodyWeights || {}).length > 0;
  const hasMind = Object.keys(domain.axisWeights.cognitiveWeights || {}).length > 0;
  const effectiveFoundation = hasBody && hasMind
    ? bodyScore * 0.45 + cognitionScore * 0.55
    : hasBody ? bodyScore : cognitionScore;
  const rawFoundation = hasBody && hasMind
    ? rawBodyScore * 0.45 + rawCognitionScore * 0.55
    : hasBody ? rawBodyScore : rawCognitionScore;

  // Condition impairment ratio on this specific domain
  const cond = condition(npc);
  const partsState = npc.core.human.state.parts || {};
  let partPenalty = 0;
  for (const part of domain.contextualModifiers.sensitiveBodyParts || []) {
    partPenalty += (partsState[part] || 0) * 0.22;
  }
  const fatigueScale = domain.contextualModifiers.fatiguePenaltyScale || 1.0;
  const conditionPenalty = round(clamp(
    partPenalty +
    (rawFoundation - effectiveFoundation) * 0.8 +
    (cond.fatigue * 0.12 * fatigueScale) +
    (cond.illness * 0.25),
    0,
    70
  ));

  // Knowledge & techniques in this domain
  const knowledgeMap = npc.core.human?.experience?.knowledge || {};
  const domainKnowledge = Object.values(knowledgeMap).filter(
    k => resolveCapabilityDomainId(k.domainId) === domain.id && k.confidence >= 0.4
  );
  const techniquesMap = npc.core.human?.experience?.techniques || {};
  const domainTechniques = Object.values(techniquesMap).filter(
    t => resolveCapabilityDomainId(t.domainId) === domain.id
  );

  // Effective competence: Notice how high aptitude helps baseline potential slightly,
  // but true high competence requires demonstrated mastery (0..100) and uninjured condition.
  // Interest NEVER increases effectiveCompetence.
  const knowledgeBonus = Math.min(10, domainKnowledge.reduce((s, k) => s + k.confidence * (k.practiced ? 3.5 : 2.0), 0));
  const techniqueBonus = Math.min(12, domainTechniques.reduce((s, t) => s + (t.proficiency / 100) * 4.0, 0));

  const rawCompetence = effectiveFoundation * 0.38 + aptitudeScore * 0.14 + mastery * 0.48 + knowledgeBonus + techniqueBonus - partPenalty * 0.4;
  const effectiveCompetence = round(clamp(rawCompetence, 5, 100));

  // Learning rate in this domain: driven by cognitive capacity + innate aptitude + curiosity/practice interest
  const domainLearningRate = round(clamp(
    0.45 + rawCognitionScore * 0.006 + aptitudeScore * 0.0045 + (interest - 50) * 0.0015,
    0.35,
    1.65
  ));

  // Execution metrics (0..100 or multipliers)
  const mod = domain.executionModifiers;
  const executionQuality = round(clamp(
    effectiveCompetence * mod.qualityWeight +
    effectiveFoundation * (1 - mod.qualityWeight) -
    (context.weatherPenalty || 0),
    5,
    100
  ));
  const errorRisk = round(clamp(
    (100 - effectiveCompetence) * mod.errorRiskReductionWeight +
    cond.fatigue * 0.18 +
    cond.stress * 0.12 +
    partPenalty * 0.35,
    2,
    95
  ));
  const speedMultiplier = round(clamp(0.6 + (effectiveCompetence / 100) * 0.75 * (1 + mod.speedWeight * 0.3), 0.45, 1.55));
  const coordinationScore = round(clamp(effectiveCompetence * mod.coordinationWeight + cognitionScore * (1 - mod.coordinationWeight), 10, 100));

  // Unlocked tier
  const thresholds = domain.unlockedAffordances.masteryThresholds;
  const masteryTier = mastery >= thresholds.expert
    ? 'expert'
    : mastery >= thresholds.competent
      ? 'competent'
      : mastery >= thresholds.basic
        ? 'basic'
        : 'novice';

  return {
    domainId: domain.id,
    displayName: domain.displayName,
    masteryTier,
    body: round(bodyScore),
    cognition: round(cognitionScore),
    aptitude: round(aptitudeScore),
    mastery: round(mastery),
    interest,
    conditionPenalty,
    knowledgeCount: domainKnowledge.length,
    techniques: domainTechniques.map(t => t.id),
    learningRate: domainLearningRate,
    effectiveCompetence,
    executionQuality,
    errorRisk,
    speedMultiplier,
    coordinationScore
  };
}

function inspectAllCapabilities(npc, context = {}) {
  const result = {};
  for (const domainId of Object.keys(CAPABILITY_DOMAINS)) {
    result[domainId] = evaluateCapabilityDomain(npc, domainId, context);
  }
  return result;
}

module.exports = {
  ensureKnowledgeAndTechniqueState,
  getSkillLevel,
  setCapabilityMastery,
  grantKnowledge,
  hasKnowledge,
  getKnowledge,
  learnTechnique,
  hasTechnique,
  evaluateCapabilityDomain,
  inspectAllCapabilities
};

  };
  __MODULES['belief_system'] = function(module, exports, require, globalThis) {
'use strict';

/**
 * Partial Observation, Epistemic Belief State, Source Reliability & Uncertainty Calibration
 *
 * Enforces the hard boundary between:
 * - Objective World Truth (owned by the external simulation)
 * - Observations / Reports delivered to the NPC
 * - Beliefs & Inferences held by the NPC (with confidence, provenance, age, and deception flags)
 *
 * High intelligence, scouting, or domain competence improves:
 *  1. Signal extraction from noisy observations
 *  2. Detection of contradictions / suspicious disinformation patterns
 *  3. Inference of secondary facts from observed clues
 *  4. Calibration of confidence (avoiding overconfidence on weak rumors)
 * It NEVER grants omniscient access to unobserved world state.
 */

const { NpcEngineError, ERROR_CODES, clamp, round, isObject } = __require('utils');
const { getAxis } = __require('identity_core');
const { effective } = __require('condition_system');
const { evaluateCapabilityDomain } = __require('knowledge_system');
const { resolveCapabilityDomainId } = __require('capability_ontology');

function ensureBeliefState(npc) {
  if (!npc.stageLocal) npc.stageLocal = {};
  if (!isObject(npc.stageLocal.beliefs)) {
    npc.stageLocal.beliefs = {
      facts: {},          // key -> { key, value, confidence, source, sourceReliability, observedAt, updatedAt, isInferred, suspectedDeception, history }
      sourceTrust: {},    // sourceId -> reliability score (0..1)
      observationLog: []  // bounded recent observation entries
    };
  }
  return npc.stageLocal.beliefs;
}

/**
 * Computes how well the NPC evaluates report credibility and detects deception.
 */
function getEpistemicAcuity(npc, relevantDomainId = 'intelligence_deception') {
  const intelCap = evaluateCapabilityDomain(npc, 'intelligence_deception');
  const domainCap = relevantDomainId && relevantDomainId !== 'intelligence_deception'
    ? evaluateCapabilityDomain(npc, relevantDomainId)
    : intelCap;
  const reasoning = effective(npc, 'cognition', 'reasoning');
  const meta = effective(npc, 'cognition', 'metacognition');
  const socialInsight = effective(npc, 'cognition', 'socialInsight');
  const trustfulness = getAxis(npc, 'personality', 'trustfulness');
  const caution = getAxis(npc, 'personality', 'caution');

  // Skepticism helps catch deception; excessive trustfulness makes NPC more gullible to unverified rumors
  const skepticism = clamp(50 + (caution - 50) * 0.4 - (trustfulness - 50) * 0.35 + (meta - 50) * 0.25, 10, 95);
  const analysisScore = clamp(
    intelCap.effectiveCompetence * 0.4 +
    domainCap.effectiveCompetence * 0.25 +
    reasoning * 0.2 +
    socialInsight * 0.15,
    10,
    100
  );

  return {
    analysisScore: round(analysisScore),
    skepticism: round(skepticism),
    perceptionBonus: round((intelCap.effectiveCompetence + domainCap.effectiveCompetence) / 200)
  };
}

/**
 * Delivers an observation or intelligence report to the NPC and updates the NPC's belief state.
 *
 * Supported observation structure:
 * {
 *   time: number,
 *   source: 'direct_observation' | 'scout_report' | 'envoy' | 'rumor' | 'defector' | 'order',
 *   sourceId?: string,
 *   sourceReliability?: number (0..1),
 *   domainId?: string,
 *   clarity?: number (0..1), // visibility / signal quality
 *   deceptionIndicators?: number (0..1), // observable anomalies (e.g. too few cookfires, inconsistent tracks)
 *   facts: { [key]: value },
 *   clues?: Array<{ clueType: string, targetFactKey: string, inferredValue: any, requiredDomain?: string, minCompetence?: number }>
 * }
 */
function observe(npc, observation = {}) {
  if (!npc || !isObject(npc)) throw new NpcEngineError(ERROR_CODES.INVALID_NPC, 'observe requires a valid NPC');
  if (!isObject(observation)) throw new NpcEngineError(ERROR_CODES.INVALID_OBSERVATION, 'observation must be an object');

  const beliefState = ensureBeliefState(npc);
  const now = Number.isFinite(observation.time) ? observation.time : 0;
  const sourceType = observation.source || 'direct_observation';
  const sourceId = observation.sourceId || sourceType;
  const domainId = resolveCapabilityDomainId(observation.domainId) || 'intelligence_deception';
  const acuity = getEpistemicAcuity(npc, domainId);

  const defaultReliabilities = {
    direct_observation: 0.92,
    order: 0.9,
    scout_report: 0.78,
    ally_report: 0.75,
    envoy: 0.58,
    defector: 0.45,
    rumor: 0.35
  };
  const baseReliability = Number.isFinite(observation.sourceReliability)
    ? clamp(observation.sourceReliability * 100, 5, 100) / 100
    : (beliefState.sourceTrust[sourceId] ?? defaultReliabilities[sourceType] ?? 0.6);

  const signalClarity = Number.isFinite(observation.clarity) ? clamp(observation.clarity * 100, 10, 100) / 100 : 0.85;
  const deceptionIndicators = Number.isFinite(observation.deceptionIndicators)
    ? clamp(observation.deceptionIndicators * 100, 0, 100) / 100
    : 0;

  // Determine whether the NPC detects suspicious patterns in the report
  const detectionCapability = (acuity.analysisScore * 0.65 + acuity.skepticism * 0.35) / 100;
  const deceptionScore = deceptionIndicators * (0.45 + detectionCapability * 0.75);
  const suspectedDeception = deceptionScore >= 0.42;

  // Calibrate confidence in incoming facts
  let calibratedConfidence = baseReliability * (0.65 + signalClarity * 0.35);
  if (sourceType !== 'direct_observation') {
    // High gullibility (low skepticism) inflates confidence in weak sources; high metacognition calibrates it
    const gullibilityAdj = ((50 - acuity.skepticism) / 100) * 0.22;
    calibratedConfidence = clamp((calibratedConfidence + gullibilityAdj) * 100, 5, 98) / 100;
  } else {
    // Direct observation scales with senseAcuity & domain competence
    const sense = effective(npc, 'body', 'senseAcuity') / 100;
    calibratedConfidence = clamp((calibratedConfidence * (0.8 + sense * 0.2 + acuity.perceptionBonus * 0.1)) * 100, 15, 99) / 100;
  }

  if (suspectedDeception) {
    calibratedConfidence = clamp(calibratedConfidence * (1 - deceptionScore * 0.75) * 100, 5, 95) / 100;
  }

  const updatedKeys = [];
  const rejectedDeceptions = [];
  const inferredKeys = [];

  // Process explicit facts in the observation
  if (isObject(observation.facts)) {
    for (const [key, value] of Object.entries(observation.facts)) {
      const existing = beliefState.facts[key];

      // If deception is strongly suspected and the NPC already holds a high-confidence contradictory belief,
      // do not overwrite the trusted belief—record the suspected deception instead.
      if (suspectedDeception && existing && existing.confidence >= calibratedConfidence + 0.15 && existing.value !== value) {
        existing.suspectedDeceptionAttempt = {
          reportedValue: value,
          source: sourceId,
          time: now,
          deceptionScore: round(deceptionScore)
        };
        rejectedDeceptions.push(key);
        continue;
      }

      // Bayesian-like belief revision when updating an existing belief
      let finalConfidence = calibratedConfidence;
      if (existing) {
        const ageDecay = Math.max(0.25, 1 - Math.max(0, now - existing.updatedAt) * 0.002);
        const priorConf = existing.confidence * ageDecay;
        if (existing.value === value) {
          // Corroborating report boosts confidence
          finalConfidence = Math.min(0.99, 1 - (1 - priorConf) * (1 - calibratedConfidence * 0.6));
        } else if (calibratedConfidence >= priorConf * 0.85 || sourceType === 'direct_observation') {
          // Contradictory report with higher/comparable authority revises the belief
          finalConfidence = calibratedConfidence;
        } else {
          // Weak contradictory rumor only slightly erodes existing belief without flipping it
          existing.confidence = round(Math.max(0.15, priorConf - calibratedConfidence * 0.2));
          existing.updatedAt = now;
          continue;
        }
      }

      beliefState.facts[key] = {
        key,
        value,
        confidence: round(finalConfidence),
        source: sourceType,
        sourceId,
        sourceReliability: round(baseReliability),
        observedAt: existing?.observedAt ?? now,
        updatedAt: now,
        isInferred: false,
        suspectedDeception
      };
      updatedKeys.push(key);
    }
  }

  // Process observational clues that require domain competence to infer
  if (Array.isArray(observation.clues)) {
    for (const clue of observation.clues) {
      if (!isObject(clue) || !clue.targetFactKey) continue;
      const reqDomain = resolveCapabilityDomainId(clue.requiredDomain || domainId) || 'intelligence_deception';
      const domainEval = evaluateCapabilityDomain(npc, reqDomain);
      const minComp = Number.isFinite(clue.minCompetence) ? clue.minCompetence : 45;

      if (domainEval.effectiveCompetence >= minComp) {
        const infConf = round(clamp(
          (calibratedConfidence * 0.75 + (domainEval.effectiveCompetence - minComp) * 0.005) * 100,
          20,
          92
        ) / 100);
        beliefState.facts[clue.targetFactKey] = {
          key: clue.targetFactKey,
          value: clue.inferredValue,
          confidence: infConf,
          source: 'inference',
          sourceId: `inferred_from_${clue.clueType || 'clue'}`,
          sourceReliability: round(baseReliability),
          observedAt: now,
          updatedAt: now,
          isInferred: true,
          clueType: clue.clueType || 'field_sign',
          suspectedDeception: false
        };
        inferredKeys.push(clue.targetFactKey);
      }
    }
  }

  beliefState.observationLog.unshift({
    time: now,
    source: sourceType,
    sourceId,
    updatedKeys,
    inferredKeys,
    rejectedDeceptions,
    suspectedDeception
  });
  if (beliefState.observationLog.length > 40) {
    beliefState.observationLog.length = 40;
  }

  return {
    updatedKeys,
    inferredKeys,
    rejectedDeceptions,
    suspectedDeception,
    calibratedConfidence: round(calibratedConfidence)
  };
}

/**
 * Retrieves the NPC's belief about a fact key at `currentTime`, accounting for information staleness.
 */
function getBelief(npc, key, currentTime = null) {
  const rec = npc?.stageLocal?.beliefs?.facts?.[key];
  if (!rec) return null;
  if (!Number.isFinite(currentTime) || currentTime <= rec.updatedAt) {
    return { ...rec, effectiveConfidence: rec.confidence, age: 0 };
  }
  const age = currentTime - rec.updatedAt;
  const retention = 300 + effective(npc, 'cognition', 'episodicMemory') * 8;
  const decayFactor = Math.max(0.2, 1 - age / (retention * 4));
  return {
    ...rec,
    age,
    effectiveConfidence: round(rec.confidence * decayFactor)
  };
}

/**
 * Returns a snapshot of all facts the NPC currently believes (above minConfidence).
 */
function getBeliefSnapshot(npc, { currentTime = null, minConfidence = 0.2 } = {}) {
  const facts = npc?.stageLocal?.beliefs?.facts || {};
  const out = {};
  for (const key of Object.keys(facts)) {
    const b = getBelief(npc, key, currentTime);
    if (b && b.effectiveConfidence >= minConfidence) {
      out[key] = b;
    }
  }
  return out;
}

/**
 * Updates source trust when a past report is proven true or false by real world outcomes.
 */
function calibrateSourceTrust(npc, sourceId, wasAccurate, weight = 0.2) {
  const beliefState = ensureBeliefState(npc);
  const current = beliefState.sourceTrust[sourceId] ?? 0.65;
  const target = wasAccurate ? 0.95 : 0.15;
  beliefState.sourceTrust[sourceId] = round(clamp((current + (target - current) * weight) * 100, 5, 99) / 100);
  return beliefState.sourceTrust[sourceId];
}

module.exports = {
  ensureBeliefState,
  getEpistemicAcuity,
  observe,
   updateBeliefs: observe,
  getBelief,
  getBeliefSnapshot,
  calibrateSourceTrust
};

  };
  __MODULES['goal_system'] = function(module, exports, require, globalThis) {
'use strict';

/**
 * Dynamic Goals, Motivations, Commitments, Relationships & Order Compliance Architecture
 *
 * Implements Section 9 & Section 14 of MASTER_PROMPT_EN.md:
 * - Multiple simultaneous motives and goals (mission orders, duty/oath, survival/health,
 *   protecting subordinates/family/civilians, ambition/legacy/wealth, relationships/debts/grievances)
 * - Explainable, data-configurable priority hierarchy
 * - Order evaluation: compliance, tactical reinterpretation, negotiation, refusal, or emergency withdrawal
 *   emerging from authority, trust, loyalty, personality, competence, perceived feasibility, and risk.
 */

const { NpcEngineError, ERROR_CODES, clamp, round, isObject } = __require('utils');
const { getAxis } = __require('identity_core');
const { condition } = __require('condition_system');
const { evaluateCapabilityDomain } = __require('knowledge_system');

const DEFAULT_PRIORITY_POLICY = Object.freeze({
  hardConstraintsFirst: true,
  tierWeights: Object.freeze({
    survival_critical: 1.45,
    active_order: 1.25,
    sacred_oath_obligation: 1.2,
    mission_objective: 1.15,
    protect_dependents_allies: 1.05,
    personal_ambition_value: 0.85,
    relationship_debt_grievance: 0.8,
    routine_need: 0.65
  })
});

function ensureGoalAndSocialState(npc) {
  if (!npc.stageLocal) npc.stageLocal = {};
  if (!isObject(npc.stageLocal.agency)) {
    npc.stageLocal.agency = {
      activeOrders: [],       // orders issued by superior / player
      goals: [],              // dynamic goals { id, type, priority, targetState, preferredDomains, PreferredActions, deadline, source, status }
      commitments: [],        // oaths, promises, duties { id, type, targetId, strength, description }
      relationships: {},      // targetNpcId -> { targetId, trust, loyalty, respect, resentment, debt, rivalry, role }
      activePlan: null,       // current multi-step plan & intention
      lastIntention: null,    // most recent committed intention
      failedActionHistory: {} // actionId -> { count, lastFailedAt, lastReason }
    };
  }
  return npc.stageLocal.agency;
}

/**
 * Sets or updates a relationship between `npc` and `targetId`.
 */
function setRelationship(npc, targetId, patch = {}) {
  const agency = ensureGoalAndSocialState(npc);
  if (!targetId || String(targetId).trim() === '') {
    throw new NpcEngineError(ERROR_CODES.INVALID_ID, 'Relationship requires a valid targetId');
  }
  const id = String(targetId).trim();
  const prev = agency.relationships[id] || {
    targetId: id,
    trust: 50,
    loyalty: 50,
    respect: 50,
    resentment: 0,
    debt: 0,
    rivalry: 0,
    role: 'peer' // 'liege' | 'commander' | 'sworn_sibling' | 'subordinate' | 'peer' | 'rival' | 'dependent'
  };
  agency.relationships[id] = {
    ...prev,
    ...patch,
    targetId: id,
    trust: clamp(patch.trust ?? prev.trust, 0, 100),
    loyalty: clamp(patch.loyalty ?? prev.loyalty, 0, 100),
    respect: clamp(patch.respect ?? prev.respect, 0, 100),
    resentment: clamp(patch.resentment ?? prev.resentment, 0, 100),
    debt: clamp(patch.debt ?? prev.debt, -100, 100),
    rivalry: clamp(patch.rivalry ?? prev.rivalry, 0, 100),
    role: patch.role || prev.role
  };
  return agency.relationships[id];
}

function getRelationship(npc, targetId) {
  return npc?.stageLocal?.agency?.relationships?.[targetId] || null;
}

/**
 * Adds a dynamic goal or commitment to the NPC.
 */
function addGoal(npc, goalDef) {
  const agency = ensureGoalAndSocialState(npc);
  if (!isObject(goalDef) || !goalDef.id) {
    throw new NpcEngineError(ERROR_CODES.INVALID_GOAL, 'Goal requires a valid id');
  }
  const existingIdx = agency.goals.findIndex(g => g.id === goalDef.id);
  const normalized = {
    id: String(goalDef.id),
    type: goalDef.type || 'mission_objective',
    label: goalDef.label || String(goalDef.id),
    basePriority: clamp(goalDef.priority ?? goalDef.basePriority ?? 60, 0, 100),
    desiredState: isObject(goalDef.desiredState) ? { ...goalDef.desiredState } : {},
    preferredActions: Array.isArray(goalDef.preferredActions) ? [...goalDef.preferredActions] : [],
    preferredDomains: Array.isArray(goalDef.preferredDomains) ? [...goalDef.preferredDomains] : [],
    avoidActions: Array.isArray(goalDef.avoidActions) ? [...goalDef.avoidActions] : [],
    targetId: goalDef.targetId || null,
    deadline: Number.isFinite(goalDef.deadline) ? goalDef.deadline : null,
    status: goalDef.status || 'active',
    createdAt: Number.isFinite(goalDef.createdAt) ? goalDef.createdAt : 0
  };
  if (existingIdx >= 0) {
    agency.goals[existingIdx] = normalized;
  } else {
    agency.goals.push(normalized);
  }
  return normalized;
}

/**
 * Issues an explicit mission order or emergency command to the NPC and evaluates the NPC's stance:
 * - 'comply': accepts the order as given
 * - 'reinterpret': accepts the mission objective/intent but substitutes a safer or more viable tactical method
 * - 'negotiate': flags serious feasibility/risk objections and proposes an alternative before committing
 * - 'withdraw': emergency survival/duty override forces withdrawal despite order
 * - 'refuse': refuses order due to extreme disloyalty/betrayal, moral violation, or suicidal impossibility
 */
function issueOrder(npc, orderDef, context = {}) {
  const agency = ensureGoalAndSocialState(npc);
  if (!isObject(orderDef) || !orderDef.id) {
    throw new NpcEngineError(ERROR_CODES.INVALID_GOAL, 'Order requires a valid id');
  }

  const issuerId = orderDef.issuerId || 'liege';
  const rel = getRelationship(npc, issuerId) || {
    trust: getAxis(npc, 'personality', 'trustfulness'),
    loyalty: getAxis(npc, 'personality', 'loyalty'),
    respect: 60,
    resentment: 0,
    role: 'liege'
  };

  const loyaltyAxis = getAxis(npc, 'personality', 'loyalty');
  const disciplineAxis = getAxis(npc, 'personality', 'discipline');
  const cautionAxis = getAxis(npc, 'personality', 'caution');
  const prideAxis = getAxis(npc, 'personality', 'pride');
  const integrityAxis = getAxis(npc, 'personality', 'integrity');
  const empathyAxis = getAxis(npc, 'personality', 'empathy');
  const ambitionAxis = getAxis(npc, 'personality', 'ambition');
  const freedomValue = getAxis(npc, 'values', 'freedom');
  const sectDutyValue = getAxis(npc, 'values', 'sectDuty');

  const cond = condition(npc);
  const authority = clamp(orderDef.authority ?? 80, 0, 100);
  const perceivedRisk = clamp(orderDef.estimatedRisk ?? context.estimatedRisk ?? 35, 0, 100);
  const perceivedFeasibility = clamp(orderDef.estimatedFeasibility ?? context.estimatedFeasibility ?? 75, 0, 100);
  const violatesEthics = Boolean(orderDef.violatesEthics || orderDef.harmsInnocents);
  const isEmergencyOrder = Boolean(orderDef.isEmergency);

  const stratCompetence = evaluateCapabilityDomain(npc, 'strategy_doctrine').effectiveCompetence;

  // Obedience propensity score
  let obedienceScore =
    loyaltyAxis * 0.25 +
    rel.loyalty * 0.25 +
    disciplineAxis * 0.18 +
    sectDutyValue * 0.14 +
    authority * 0.18 +
    (rel.trust - 50) * 0.15 -
    rel.resentment * 0.25 -
    (freedomValue - 50) * 0.1;

  if (isEmergencyOrder) obedienceScore += 10;
  if (violatesEthics) {
    obedienceScore -= Math.max(0, integrityAxis - 50) * 0.55 + Math.max(0, empathyAxis - 50) * 0.45;
  }

  // Survival & Collapse check
  const criticalCondition = cond.healthRatio < 0.22 || cond.morale < 18 || cond.supplyDays <= 0;

  let responseMode = 'comply';
  let reasonCode = 'ORDER_ACCEPTED';

  if (criticalCondition && perceivedRisk > 55 && loyaltyAxis < 95) {
    responseMode = 'withdraw';
    reasonCode = 'EMERGENCY_SURVIVAL_WITHDRAWAL';
  } else if (obedienceScore < 32 || (violatesEthics && integrityAxis >= 82 && empathyAxis >= 78)) {
    responseMode = 'refuse';
    reasonCode = violatesEthics ? 'REFUSED_MORAL_VIOLATION' : 'REFUSED_LOW_LOYALTY_OR_AUTHORITY';
  } else if (perceivedFeasibility < 35 && stratCompetence >= 65 && (cautionAxis >= 65 || prideAxis >= 65)) {
    if (rel.trust >= 55 && disciplineAxis >= 60) {
      responseMode = 'negotiate';
      reasonCode = 'NEGOTIATE_INFEASIBLE_ORDER';
    } else {
      responseMode = 'reinterpret';
      reasonCode = 'REINTERPRETED_TACTICAL_METHOD';
    }
  } else if (perceivedRisk > 75 && cautionAxis >= 75 && stratCompetence >= 60 && !orderDef.strictMethodLock) {
    responseMode = 'reinterpret';
    reasonCode = 'REINTERPRETED_TO_REDUCE_RISK';
  } else if (ambitionAxis >= 85 && prideAxis >= 80 && rel.loyalty < 45 && !isEmergencyOrder) {
    responseMode = 'reinterpret';
    reasonCode = 'REINTERPRETED_FOR_PERSONAL_GLORY';
  }

  const orderRecord = {
    id: String(orderDef.id),
    issuerId,
    label: orderDef.label || String(orderDef.id),
    desiredState: isObject(orderDef.desiredState) ? { ...orderDef.desiredState } : {},
    mandatedActionId: orderDef.mandatedActionId || null,
    preferredActions: Array.isArray(orderDef.preferredActions) ? [...orderDef.preferredActions] : [],
    alternativeActions: Array.isArray(orderDef.alternativeActions) ? [...orderDef.alternativeActions] : [],
    preferredDomains: Array.isArray(orderDef.preferredDomains) ? [...orderDef.preferredDomains] : [],
    priority: clamp(orderDef.priority ?? (isEmergencyOrder ? 95 : 82), 0, 100),
    deadline: Number.isFinite(orderDef.deadline) ? orderDef.deadline : null,
    isEmergency: isEmergencyOrder,
    responseMode,
    reasonCode,
    obedienceScore: round(obedienceScore),
    issuedAt: Number.isFinite(context.time) ? context.time : 0
  };

  // Replace existing order with same ID or prepend
  agency.activeOrders = agency.activeOrders.filter(o => o.id !== orderRecord.id);
  agency.activeOrders.unshift(orderRecord);

  // Synchronize corresponding goal in agency.goals unless refused
  if (responseMode !== 'refuse') {
    const effectiveActions = responseMode === 'reinterpret' || responseMode === 'negotiate'
      ? (orderRecord.alternativeActions.length > 0 ? orderRecord.alternativeActions : orderRecord.preferredActions)
      : (orderRecord.mandatedActionId ? [orderRecord.mandatedActionId, ...orderRecord.preferredActions] : orderRecord.preferredActions);

    addGoal(npc, {
      id: `order:${orderRecord.id}`,
      type: isEmergencyOrder ? 'active_order' : 'mission_objective',
      label: orderRecord.label,
      priority: orderRecord.priority,
      desiredState: responseMode === 'withdraw' ? { safe_withdrawal: true } : orderRecord.desiredState,
      preferredActions: responseMode === 'withdraw' ? ['fighting_retreat', 'rest'] : effectiveActions,
      preferredDomains: orderRecord.preferredDomains,
      deadline: orderRecord.deadline,
      createdAt: orderRecord.issuedAt
    });
  }

  return orderRecord;
}

/**
 * Synthesizes and prioritizes all active drives, needs, obligations, values, and orders for the current decision cycle.
 */
function evaluateActiveDrivesAndGoals(npc, context = {}) {
  const agency = ensureGoalAndSocialState(npc);
  const policy = { ...DEFAULT_PRIORITY_POLICY, ...(context.priorityPolicy || {}) };
  const cond = condition(npc);
  const synthesized = [];

  // 1. Critical Survival / Health / Rest Drive
  if (cond.healthRatio < 0.35 || cond.fatigue > 82 || cond.hunger > 85 || cond.supplyDays <= 1) {
    const urgency = round(clamp(
      (1 - cond.healthRatio) * 90 +
      Math.max(0, cond.fatigue - 65) * 1.2 +
      Math.max(0, cond.hunger - 70) * 1.1 +
      (cond.supplyDays <= 1 ? 45 : 0),
      50,
      100
    ));
    synthesized.push({
      id: 'drive:survival_and_sustainment',
      type: 'survival_critical',
      label: 'Preserve life, recover condition, or secure emergency supplies',
      effectivePriority: round(urgency * policy.tierWeights.survival_critical),
      desiredState: cond.supplyDays <= 1 ? { supplies_secured: true } : { recovered: true },
      preferredActions: cond.supplyDays <= 1
        ? ['logistics', 'forage_and_secure_water', 'enforce_emergency_rationing', 'fighting_retreat']
        : ['rest', 'treat_battle_wounds', 'fighting_retreat'],
      preferredDomains: ['medicine_care', 'logistics_sustainment', 'travel_survival']
    });
  }

  // 2. Explicit Active Goals & Orders
  for (const goal of agency.goals) {
    if (goal.status !== 'active') continue;
    const tierWeight = policy.tierWeights[goal.type] || 1.0;
    let deadlineUrgency = 0;
    if (Number.isFinite(goal.deadline) && Number.isFinite(context.time)) {
      const remaining = Math.max(1, goal.deadline - context.time);
      if (remaining <= 10) deadlineUrgency = (11 - remaining) * 2.5;
    }
    synthesized.push({
      ...goal,
      effectivePriority: round((goal.basePriority + deadlineUrgency) * tierWeight)
    });
  }

  // 3. Innate Value & Ambition Baseline Drive (when no explicit goals dominate)
  const ambition = getAxis(npc, 'personality', 'ambition');
  const duty = getAxis(npc, 'values', 'sectDuty');
  const knowledgeVal = getAxis(npc, 'values', 'knowledgeCraft');
  const familyVal = getAxis(npc, 'values', 'familyClan');

  if (duty >= 70) {
    synthesized.push({
      id: 'drive:faction_duty',
      type: 'personal_ambition_value',
      label: 'Advance faction readiness and civic/military duty',
      effectivePriority: round(duty * 0.7 * policy.tierWeights.personal_ambition_value),
      desiredState: {},
      preferredActions: ['command_army', 'govern_city', 'train_troops', 'patrol', 'logistics'],
      preferredDomains: ['command_leadership', 'civil_administration', 'logistics_sustainment']
    });
  }
  if (knowledgeVal >= 75) {
    synthesized.push({
      id: 'drive:scholarly_mastery',
      type: 'personal_ambition_value',
      label: 'Pursue strategic and scholarly mastery',
      effectivePriority: round(knowledgeVal * 0.65 * policy.tierWeights.personal_ambition_value),
      desiredState: {},
      preferredActions: ['research_strategy', 'compile_regional_map', 'forecast_seasonal_weather'],
      preferredDomains: ['strategy_doctrine', 'scholarship_planning']
    });
  }
  if (familyVal >= 75 && context.dependentsThreatened) {
    synthesized.push({
      id: 'drive:protect_clan_dependents',
      type: 'protect_dependents_allies',
      label: 'Protect family, sworn siblings, and civilian dependents',
      effectivePriority: round(familyVal * 1.1 * policy.tierWeights.protect_dependents_allies),
      desiredState: { dependents_safe: true },
      preferredActions: ['defend_city', 'settle_displaced_refugees', 'fighting_retreat'],
      preferredDomains: ['land_warfare', 'civil_administration', 'social_household']
    });
  }
  if (ambition >= 80) {
    synthesized.push({
      id: 'drive:ambition_and_status',
      type: 'personal_ambition_value',
      label: 'Achieve decisive distinction and status',
      effectivePriority: round(ambition * 0.68 * policy.tierWeights.personal_ambition_value),
      desiredState: {},
      preferredActions: ['command_army', 'duel', 'siege', 'launch_fire_attack'],
      preferredDomains: ['command_leadership', 'individual_combat', 'land_warfare', 'naval_warfare']
    });
  }

  synthesized.sort((a, b) => b.effectivePriority - a.effectivePriority);
  return synthesized;
}

module.exports = {
  DEFAULT_PRIORITY_POLICY,
  ensureGoalAndSocialState,
  setRelationship,
  getRelationship,
  addGoal,
  issueOrder,
  evaluateActiveDrivesAndGoals
};

  };
  __MODULES['action_registry'] = function(module, exports, require, globalThis) {
'use strict';

/**
 * Action Registry & Future-Proof Extension Contract
 *
 * Implements Section 11 of MASTER_PROMPT_EN.md:
 * - Supports both legacy `registerActivity` (100% compatible with v1.0) and full
 *   `registerAction` with preconditions, capability/knowledge/technique requirements,
 *   resource/time/effort costs, candidate effects, failure modes, estimator hooks,
 *   replanning triggers, and external adapter hooks.
 * - Future systems (naval warfare, siegecraft, city/economy, medicine, craft, scholarship)
 *   register actions using existing capability domain IDs and 68 identity axes without
 *   modifying the engine core.
 */

const { NpcEngineError, ERROR_CODES, clamp, round, isObject } = __require('utils');
const { validAxisGroups } = __require('identity_core');
const { condition } = __require('condition_system');
const {
  CAPABILITY_DOMAINS,
  resolveCapabilityDomainId
} = __require('capability_ontology');
const {
  getSkillLevel,
  hasKnowledge,
  hasTechnique,
  evaluateCapabilityDomain
} = __require('knowledge_system');
const { getBelief } = __require('belief_system');

const activities = Object.create(null);

const neutralDescriptor = Object.freeze({
  id: 'unknown',
  version: '1.0.0',
  label: 'กิจกรรม',
  category: 'general',
  skillDomain: 'general',
  capabilityDomain: 'command_leadership',
  effort: 30,
  timeCost: 1,
  risk: 0,
  valueWeights: Object.freeze({}),
  personalityWeights: Object.freeze({}),
  aptitudeWeights: Object.freeze({}),
  bodyWeights: Object.freeze({}),
  cognitiveWeights: Object.freeze({}),
  interestWeights: Object.freeze({}),
  needRelief: Object.freeze({}),
  preconditions: Object.freeze({}),
  requiredCapabilities: Object.freeze({}),
  optionalCapabilities: Object.freeze({}),
  requiredKnowledge: Object.freeze([]),
  requiredTechniques: Object.freeze([]),
  requiredEquipment: Object.freeze([]),
  requiredResources: Object.freeze({}),
  minAuthority: 0,
  minHealthRatio: 0.1,
  maxFatigue: 98,
  effects: Object.freeze({}),
  failureModes: Object.freeze(['execution_error']),
  replanTriggers: Object.freeze(['action_failed', 'precondition_invalidated']),
  learningEvidence: Object.freeze({ primaryDomain: 'command_leadership', basePractice: 1 })
});

/**
 * Validates an activity or extended action definition.
 * Throws NpcEngineError(ERROR_CODES.INVALID_ACTION_DEF) if invalid.
 */
function validateActionDefinition(def) {
  if (!isObject(def) || typeof def.id !== 'string' || !/^[-\w:.]+$/.test(def.id) || !def.label || typeof def.label !== 'string') {
    throw new NpcEngineError(ERROR_CODES.INVALID_ACTION_DEF, 'Activity needs stable id and label');
  }

  for (const [group, valid] of Object.entries(validAxisGroups)) {
    const weights = def[group] || {};
    if (!isObject(weights)) {
      throw new NpcEngineError(ERROR_CODES.INVALID_ACTION_DEF, `Invalid weight map for ${group}`);
    }
    for (const [k, w] of Object.entries(weights)) {
      if (!valid.has(k) || !Number.isFinite(w)) {
        throw new NpcEngineError(ERROR_CODES.INVALID_AXIS, 'Unknown human axis: ' + group + '.' + k);
      }
      if (['bodyWeights', 'cognitiveWeights', 'aptitudeWeights'].includes(group) && w < 0) {
        throw new NpcEngineError(ERROR_CODES.INVALID_ACTION_DEF, 'Capability weights must be nonnegative');
      }
    }
  }

  if (def.needRelief !== undefined) {
    if (!isObject(def.needRelief)) {
      throw new NpcEngineError(ERROR_CODES.INVALID_ACTION_DEF, 'needRelief must be an object');
    }
    for (const [k, v] of Object.entries(def.needRelief)) {
      if (!['autonomy', 'competence', 'stimulation', 'social'].includes(k) || !Number.isFinite(v)) {
        throw new NpcEngineError(ERROR_CODES.INVALID_ACTION_DEF, 'Unknown need ' + k);
      }
    }
  }

  if (def.capabilityDomain !== undefined) {
    const resolved = resolveCapabilityDomainId(def.capabilityDomain);
    if (!resolved) {
      throw new NpcEngineError(ERROR_CODES.INVALID_CAPABILITY, `Unknown capabilityDomain in action ${def.id}: ${def.capabilityDomain}`);
    }
  }

  if (def.requiredCapabilities !== undefined) {
    if (!isObject(def.requiredCapabilities)) {
      throw new NpcEngineError(ERROR_CODES.INVALID_ACTION_DEF, 'requiredCapabilities must be an object');
    }
    for (const [capId, minVal] of Object.entries(def.requiredCapabilities)) {
      if (!resolveCapabilityDomainId(capId) || !Number.isFinite(minVal) || minVal < 0 || minVal > 100) {
        throw new NpcEngineError(ERROR_CODES.INVALID_CAPABILITY, `Invalid requiredCapabilities entry: ${capId}=${minVal}`);
      }
    }
  }

  if (def.requiredResources !== undefined) {
    if (!isObject(def.requiredResources)) {
      throw new NpcEngineError(ERROR_CODES.INVALID_ACTION_DEF, 'requiredResources must be an object');
    }
    for (const [resKey, amount] of Object.entries(def.requiredResources)) {
      if (!Number.isFinite(amount) || amount < 0) {
        throw new NpcEngineError(ERROR_CODES.INVALID_ACTION_DEF, `Invalid resource requirement ${resKey}=${amount}`);
      }
    }
  }

  if (def.adapter !== undefined && def.adapter !== null) {
    if (!isObject(def.adapter)) {
      throw new NpcEngineError(ERROR_CODES.INVALID_ACTION_DEF, 'Action adapter must be an object');
    }
    for (const fnKey of ['checkFeasibility', 'estimateOutcome', 'executeInWorld']) {
      if (def.adapter[fnKey] !== undefined && typeof def.adapter[fnKey] !== 'function') {
        throw new NpcEngineError(ERROR_CODES.INVALID_ACTION_DEF, `Adapter hook ${fnKey} must be a function`);
      }
    }
  }

  return true;
}

/**
 * Registers an activity or full action definition into the canonical action registry.
 */
function registerAction(def) {
  validateActionDefinition(def);

  const rawSkillDomain = def.skillDomain || def.capabilityDomain || def.id;
  const resolvedCapId = resolveCapabilityDomainId(def.capabilityDomain || rawSkillDomain) || 'command_leadership';
  const capDomain = CAPABILITY_DOMAINS[resolvedCapId];

  const mergedGroup = (group) => {
    const explicit = def[group];
    if (explicit && Object.keys(explicit).length > 0) {
      return Object.freeze({ ...explicit });
    }
    if (def.inheritDomainWeights !== false && capDomain?.axisWeights?.[group]) {
      return Object.freeze({ ...capDomain.axisWeights[group] });
    }
    return Object.freeze({});
  };

  const normalized = {
    skillDomain: rawSkillDomain,
    effort: 30,
    ...def,
    id: def.id,
    version: def.version || '1.0.0',
    label: def.label,
    description: def.description || def.label,
    category: def.category || resolvedCapId,
    capabilityDomain: resolvedCapId,
    timeCost: Number.isFinite(def.timeCost) && def.timeCost > 0 ? def.timeCost : 1,
    risk: Number.isFinite(def.risk) ? def.risk : (Number.isFinite(def.riskLevel) ? def.riskLevel : 15),
    valueWeights: mergedGroup('valueWeights'),
    personalityWeights: mergedGroup('personalityWeights'),
    aptitudeWeights: mergedGroup('aptitudeWeights'),
    bodyWeights: mergedGroup('bodyWeights'),
    cognitiveWeights: mergedGroup('cognitiveWeights'),
    interestWeights: mergedGroup('interestWeights'),
    needRelief: Object.freeze({ ...(def.needRelief || {}) }),
    preconditions: Object.freeze({ ...(def.preconditions || {}) }),
    requiredCapabilities: Object.freeze({ ...(def.requiredCapabilities || {}) }),
    optionalCapabilities: Object.freeze({ ...(def.optionalCapabilities || {}) }),
    requiredKnowledge: Object.freeze(Array.isArray(def.requiredKnowledge) ? [...def.requiredKnowledge] : []),
    requiredTechniques: Object.freeze(Array.isArray(def.requiredTechniques) ? [...def.requiredTechniques] : []),
    requiredEquipment: Object.freeze(Array.isArray(def.requiredEquipment) ? [...def.requiredEquipment] : []),
    requiredResources: Object.freeze({ ...(def.requiredResources || {}) }),
    minAuthority: Number.isFinite(def.minAuthority) ? def.minAuthority : 0,
    minHealthRatio: Number.isFinite(def.minHealthRatio) ? def.minHealthRatio : 0.12,
    maxFatigue: Number.isFinite(def.maxFatigue) ? def.maxFatigue : 96,
    effects: Object.freeze({ ...(def.effects || {}) }),
    failureModes: Object.freeze(Array.isArray(def.failureModes) ? [...def.failureModes] : ['execution_error', 'external_disruption']),
    replanTriggers: Object.freeze(Array.isArray(def.replanTriggers) ? [...def.replanTriggers] : ['action_failed', 'precondition_invalidated', 'resource_shortage']),
    learningEvidence: Object.freeze({
      primaryDomain: resolvedCapId,
      skillDomain: rawSkillDomain,
      basePractice: 1,
      ...(def.learningEvidence || {})
    }),
    adapter: def.adapter ? Object.freeze({ ...def.adapter }) : null
  };

  activities[normalized.id] = Object.freeze(normalized);
  return activities[normalized.id];
}

function descriptor(id) {
  return activities[id] || activities[id?.startsWith('bounty:') ? 'bounty' : id] || neutralDescriptor;
}

/**
 * Checks hard feasibility constraints for an action before scoring.
 */
function checkActionFeasibility(npc, actionOrId, context = {}) {
  const act = isObject(actionOrId) && actionOrId.id && activities[actionOrId.id]
    ? { ...activities[actionOrId.id], ...actionOrId }
    : isObject(actionOrId) && actionOrId.id
      ? { ...descriptor(actionOrId.activityId || actionOrId.id), ...actionOrId }
      : descriptor(actionOrId);

  const reasons = [];
  const cond = condition(npc);

  const isRecoveryAction = ['rest', 'treat_battle_wounds', 'fighting_retreat'].includes(act.id);
  const minHealth = Number.isFinite(act.minHealthRatio) ? act.minHealthRatio : 0.12;
  const maxFatigue = Number.isFinite(act.maxFatigue) ? act.maxFatigue : 96;

  if (!isRecoveryAction && cond.healthRatio < minHealth) {
    reasons.push({ code: 'INSUFFICIENT_HEALTH', detail: `Health ratio ${cond.healthRatio} < ${minHealth}` });
  }
  if (!isRecoveryAction && cond.fatigue > maxFatigue) {
    reasons.push({ code: 'EXCESSIVE_FATIGUE', detail: `Fatigue ${cond.fatigue} > ${maxFatigue}` });
  }

  const authority = Number.isFinite(context.authority)
    ? context.authority
    : (npc.stageLocal?.authority ?? 100);
  if (act.minAuthority > 0 && authority < act.minAuthority) {
    reasons.push({ code: 'INSUFFICIENT_AUTHORITY', detail: `Authority ${authority} < ${act.minAuthority}` });
  }

  for (const [capKey, minMastery] of Object.entries(act.requiredCapabilities || {})) {
    const skillLvl = getSkillLevel(npc, capKey);
    const domainEval = evaluateCapabilityDomain(npc, capKey);
    const passes = skillLvl >= minMastery || (minMastery <= 25 && domainEval.effectiveCompetence >= minMastery + 18);
    if (!passes) {
      reasons.push({
        code: 'INSUFFICIENT_CAPABILITY_MASTERY',
        domain: resolveCapabilityDomainId(capKey) || capKey,
        required: minMastery,
        actualMastery: skillLvl
      });
    }
  }

  for (const kId of act.requiredKnowledge || []) {
    const knows = hasKnowledge(npc, kId, 0.45) || Boolean(getBelief(npc, kId, context.time)?.effectiveConfidence >= 0.45);
    if (!knows) {
      reasons.push({ code: 'MISSING_REQUIRED_KNOWLEDGE', knowledgeId: kId });
    }
  }

  for (const tId of act.requiredTechniques || []) {
    if (!hasTechnique(npc, tId, 1)) {
      reasons.push({ code: 'MISSING_REQUIRED_TECHNIQUE', techniqueId: tId });
    }
  }

  if (Array.isArray(act.requiredEquipment) && act.requiredEquipment.length > 0 && context.equipment !== undefined) {
    const availableEq = new Set(Array.isArray(context.equipment) ? context.equipment : Object.keys(context.equipment || {}).filter(k => context.equipment[k]));
    for (const eq of act.requiredEquipment) {
      if (!availableEq.has(eq)) {
        reasons.push({ code: 'MISSING_REQUIRED_EQUIPMENT', equipment: eq });
      }
    }
  }

  if (act.requiredResources && Object.keys(act.requiredResources).length > 0) {
    const resources = context.resources || npc.stageLocal?.resources || {};
    for (const [resKey, reqAmt] of Object.entries(act.requiredResources)) {
      const availableAmt = Number.isFinite(resources[resKey])
        ? resources[resKey]
        : (resKey === 'supplyDays' ? cond.supplyDays : undefined);
      if (availableAmt !== undefined && availableAmt < reqAmt) {
        reasons.push({
          code: 'INSUFFICIENT_RESOURCES',
          resource: resKey,
          required: reqAmt,
          available: availableAmt
        });
      }
    }
  }

  if (act.preconditions && Object.keys(act.preconditions).length > 0) {
    const stateView = context.perceivedState || {};
    for (const [key, expectedVal] of Object.entries(act.preconditions)) {
      const belief = getBelief(npc, key, context.time);
      const actualVal = belief ? belief.value : stateView[key];
      if (actualVal !== expectedVal) {
        reasons.push({
          code: 'PRECONDITION_UNMET',
          key,
          expected: expectedVal,
          perceived: actualVal
        });
      }
    }
  }

  if (act.adapter && typeof act.adapter.checkFeasibility === 'function') {
    const extResult = act.adapter.checkFeasibility(npc, act, context);
    if (extResult && extResult.feasible === false) {
      reasons.push({
        code: extResult.reasonCode || 'ADAPTER_REJECTED',
        detail: extResult.reason || 'Rejected by external action adapter'
      });
    }
  }

  return {
    actionId: act.id,
    feasible: reasons.length === 0,
    reasons
  };
}

function generateCandidates(npc, context = {}) {
  const rawList = Array.isArray(context.candidateActions) && context.candidateActions.length > 0
    ? context.candidateActions
    : Object.values(activities);

  const feasibleCandidates = [];
  const rejectedCandidates = [];

  for (const item of rawList) {
    const actObj = typeof item === 'string' ? descriptor(item) : item;
    const check = checkActionFeasibility(npc, actObj, context);
    if (check.feasible) {
      feasibleCandidates.push(actObj);
    } else {
      rejectedCandidates.push({
        id: actObj.id || String(item),
        reasons: check.reasons
      });
    }
  }

  return {
    feasibleCandidates,
    rejectedCandidates
  };
}

module.exports = {
  activities,
  neutralDescriptor,
  validateActionDefinition,
  registerAction,
  registerActivity: registerAction,
  descriptor,
  checkActionFeasibility,
  generateCandidates
};

  };
  __MODULES['memory_learning'] = function(module, exports, require, globalThis) {
'use strict';

/**
 * Memory, Causal Outcome Attribution, and Experience-Based Learning System
 *
 * Implements Section 13 of MASTER_PROMPT_EN.md while preserving 100% compatibility
 * with v1.0 `learn`, `remember`, `memoryBias`, `learningRate`, `workRate`, `harvestLimit`, and `skill`:
 * - Episodic event memories with time, participants, context, source, outcome, and deduplication
 * - Social/relationship memories (help, betrayal, insult, promise, cooperation)
 * - Causal outcome attribution (Weiner 1985 inspired): separates NPC's own contribution
 *   from luck, allies, equipment, weather, and bad intelligence before updating skill & confidence
 * - Relevance-weighted memory retrieval (action, domain, participants, recency, salience, reliability)
 * - Bounded memory growth with deterministic consolidation (preserves major formative events)
 */

const { NpcEngineError, ERROR_CODES, clamp, round, isObject } = __require('utils');
const { raw, getAxis } = __require('identity_core');
const { weighted, carryLimit, load, injure } = __require('condition_system');
const { descriptor } = __require('action_registry');
const { resolveCapabilityDomainId } = __require('capability_ontology');
const {
  ensureKnowledgeAndTechniqueState,
  getSkillLevel,
  grantKnowledge
} = __require('knowledge_system');
const { observe, calibrateSourceTrust } = __require('belief_system');
const { ensureGoalAndSocialState, setRelationship, getRelationship } = __require('goal_system');

const MAX_EPISODIC_MEMORIES = 32;
const MAX_REFLECTIONS = 12;
const MAX_SOCIAL_MEMORIES = 24;

function skill(n, id) {
  return getSkillLevel(n, id);
}

function liking(n, id) {
  return round(clamp(
    50 + Object.entries(descriptor(id).interestWeights).reduce(
      (s, [k, w]) => s + (raw(n, 'interest', k) - 50) * w,
      0
    )
  ));
}

function capacity(n, id) {
  const d = descriptor(id);
  const body = weighted(n, 'body', d.bodyWeights);
  const cognition = weighted(n, 'cognition', d.cognitiveWeights);
  const aptitude = weighted(n, 'aptitude', d.aptitudeWeights, false);
  const learned = skill(n, d.skillDomain);
  const hasBody = Object.keys(d.bodyWeights).length > 0;
  const hasMind = Object.keys(d.cognitiveWeights).length > 0;
  const foundation = hasBody && hasMind ? body * 0.45 + cognition * 0.55 : hasBody ? body : cognition;
  return {
    body: round(body),
    cognition: round(cognition),
    aptitude: round(aptitude),
    skill: round(learned),
    total: round(clamp(foundation * 0.6 + aptitude * 0.25 + (30 + learned * 0.7) * 0.15))
  };
}

function workRate(n, id) {
  return clamp(0.62 + capacity(n, id).total * 0.0076, 0.55, 1.38);
}

function learningRate(n, id) {
  const d = descriptor(id);
  const mind = weighted(n, 'cognition', Object.keys(d.cognitiveWeights).length ? d.cognitiveWeights : { reasoning: 1, attention: 1 });
  const apt = weighted(n, 'aptitude', d.aptitudeWeights, false);
  return round(clamp(0.45 + mind * 0.007 + apt * 0.003, 0.45, 1.45));
}

function harvestLimit(n, id) {
  return Math.max(
    0,
    Math.min(
      Math.floor(1.5 + capacity(n, id).body * 0.025 + skill(n, descriptor(id).skillDomain) * 0.008),
      carryLimit(n) - load(n)
    )
  );
}

/**
 * Legacy-compatible `learn(npc, activityId, amount)` function.
 * Also synchronizes canonical capability domain skill record when `skillDomain` is a legacy alias.
 */
function learn(n, id, amount = 1) {
  if (!Number.isFinite(amount) || amount < 0) {
    throw new NpcEngineError(ERROR_CODES.INVALID_OUTCOME, 'Practice amount must be finite and nonnegative');
  }
  const d = descriptor(id);
  const h = n.core.human;
  const e = h.experience;
  const s = e.skills[d.skillDomain] || (e.skills[d.skillDomain] = { level: 0, practice: 0 });
  const gain = amount * learningRate(n, id) * (1 - s.level / 115);
  const relief = Math.min(1, amount);
  s.practice = round(s.practice + amount);
  s.level = round(clamp(s.level + gain));

  // Also synchronize canonical capability domain entry if distinct from d.skillDomain
  const canonicalDomainId = resolveCapabilityDomainId(d.capabilityDomain || d.skillDomain);
  if (canonicalDomainId && canonicalDomainId !== d.skillDomain) {
    const cs = e.skills[canonicalDomainId] || (e.skills[canonicalDomainId] = { level: 0, practice: 0 });
    cs.practice = round(cs.practice + amount);
    cs.level = round(clamp(Math.max(cs.level, s.level)));
  }

  e.completed = round(e.completed + amount);
  h.state.competence = clamp(h.state.competence - 10 * relief);
  h.state.autonomy = clamp(h.state.autonomy - (liking(n, id) > 50 ? 8 : 2) * relief);
  h.state.stimulation = clamp(h.state.stimulation - (d.needRelief.stimulation ? 12 : 4) * relief);
  return round(gain);
}

/**
 * Legacy-compatible `remember(npc, action, valence, text, time, meta)` function.
 * Preserves exact deduplication and consolidation while supporting optional participant/domain metadata
 * and formative-memory protection (high-importance formative events are retained during pruning).
 */
function remember(n, action, valence, text, time, meta = {}) {
  const h = n.core.human;
  const m = n.stageLocal?.memories;
  if (!m) return false;
  valence = clamp(valence, -20, 20);

  // Deduplicate repeated event delivery within 30 ticks of same polarity
  if (m.some(e => e.action === action && Math.abs(time - e.t) < 30 && Math.sign(e.valence) === Math.sign(valence) && (meta.eventId ? e.eventId === meta.eventId : true))) {
    return false;
  }

  const d = descriptor(action);
  const importance = round(Math.min(100, Math.abs(valence) * 5 + (meta.formative ? 25 : 0)));
  const entry = {
    t: time,
    action,
    valence,
    text,
    importance,
    source: meta.source || 'experienced',
    confidence: Number.isFinite(meta.confidence) ? round(clamp(meta.confidence * 100, 5, 100) / 100) : 1,
    domainId: meta.domainId || d.capabilityDomain || resolveCapabilityDomainId(d.skillDomain) || 'general',
    participants: Array.isArray(meta.participants) ? [...meta.participants] : [],
    formative: Boolean(meta.formative || importance >= 85),
    eventId: meta.eventId || null
  };

  m.unshift(entry);

  // Bounded cap at 32: if pruning beyond 32, protect major formative events by removing the oldest non-formative memory first
  while (m.length > MAX_EPISODIC_MEMORIES) {
    let removeIdx = m.length - 1;
    for (let i = m.length - 1; i >= Math.floor(MAX_EPISODIC_MEMORIES / 2); i--) {
      if (!m[i].formative) {
        removeIdx = i;
        break;
      }
    }
    m.splice(removeIdx, 1);
  }

  const b = h.experience.beliefs;
  const e = b[action] || (b[action] = { count: 0, total: 0, expected: 0, lastAt: 0 });
  e.count++;
  e.total = round(e.total + valence);
  e.expected = round(clamp(e.total / e.count, -20, 20));
  e.lastAt = time;

  if (e.count % 4 === 0) {
    h.experience.reflections.unshift({
      t: time,
      action,
      count: e.count,
      expected: e.expected,
      text: (e.expected >= 0 ? 'มีประสบการณ์ที่ดีซ้ำกับ ' : 'ควรระวังมากขึ้นเมื่อ ') + d.label,
      source: 'own_observations'
    });
    h.experience.reflections.splice(MAX_REFLECTIONS);
  }

  // Record social/relationship memory if participants and socialType are provided
  if (meta.socialType && Array.isArray(meta.participants) && meta.participants.length > 0) {
    if (!Array.isArray(n.stageLocal.socialMemories)) n.stageLocal.socialMemories = [];
    n.stageLocal.socialMemories.unshift({
      t: time,
      type: meta.socialType, // 'help' | 'betrayal' | 'insult' | 'promise' | 'cooperation'
      participants: [...meta.participants],
      action,
      valence,
      text
    });
    if (n.stageLocal.socialMemories.length > MAX_SOCIAL_MEMORIES) {
      n.stageLocal.socialMemories.length = MAX_SOCIAL_MEMORIES;
    }
  }

  return true;
}

/**
 * Legacy-compatible `memoryBias(npc, actionId, time, context)`
 * Preserves exact v1.0 formula when called as `memoryBias(n, id, time)` while adding
 * domain-level lesson transfer and participant relevance when context is supplied.
 */
function memoryBias(n, id, time, context = null) {
  const m = raw(n, 'cognition', 'episodicMemory');
  const retention = 400 + m * 7;
  const b = n.core.human.experience.beliefs[id];
  const memories = n.stageLocal?.memories || [];

  const episodes = memories
    .filter(e => e.action === id)
    .reduce((s, e) => s + e.valence * (e.confidence ?? 1) * Math.max(0, 1 - Math.max(0, time - e.t) / retention), 0);

  const lesson = b
    ? b.expected * Math.min(0.35, b.count * 0.04) * Math.max(0, 1 - Math.max(0, time - b.lastAt) / (2500 + m * 20))
    : 0;

  let contextualBias = 0;
  if (context && isObject(context)) {
    const targetDomain = descriptor(id).capabilityDomain;
    const targetParticipant = context.targetId || null;
    for (const e of memories) {
      if (e.action === id) continue;
      const ageFactor = Math.max(0, 1 - Math.max(0, time - e.t) / retention);
      if (ageFactor <= 0) continue;
      if (targetDomain && e.domainId === targetDomain) {
        contextualBias += e.valence * 0.15 * ageFactor;
      }
      if (targetParticipant && Array.isArray(e.participants) && e.participants.includes(targetParticipant)) {
        contextualBias += e.valence * 0.25 * ageFactor;
      }
    }
  }

  return round(episodes + lesson + contextualBias);
}

/**
 * Retrieves memories ranked by composite relevance to current goals, action/domain,
 * participants, recency, salience (importance), and source reliability.
 */
function retrieveMemories(npc, query = {}) {
  const memories = npc?.stageLocal?.memories || [];
  const now = Number.isFinite(query.time) ? query.time : 0;
  const retention = 400 + raw(npc, 'cognition', 'episodicMemory') * 7;
  const targetAction = query.actionId || null;
  const targetDomain = resolveCapabilityDomainId(query.domainId || (targetAction ? descriptor(targetAction).capabilityDomain : null));
  const targetParticipants = new Set(Array.isArray(query.participants) ? query.participants : []);
  const limit = Number.isInteger(query.limit) && query.limit > 0 ? query.limit : 10;

  const scored = memories.map(entry => {
    const age = Math.max(0, now - entry.t);
    const recencyScore = entry.formative
      ? Math.max(0.45, 1 - age / (retention * 3))
      : Math.max(0.05, 1 - age / retention);
    const salienceScore = clamp(entry.importance ?? Math.abs(entry.valence) * 5, 5, 100) / 100;
    const reliabilityScore = entry.confidence ?? (entry.source === 'experienced' ? 1.0 : 0.65);

    let relevanceMatch = 0.1;
    if (targetAction && entry.action === targetAction) relevanceMatch += 0.55;
    if (targetDomain && entry.domainId === targetDomain) relevanceMatch += 0.3;
    if (targetParticipants.size > 0 && Array.isArray(entry.participants)) {
      const overlap = entry.participants.filter(p => targetParticipants.has(p)).length;
      if (overlap > 0) relevanceMatch += 0.35;
    }

    const totalRelevance = round(relevanceMatch * (recencyScore * 0.45 + salienceScore * 0.35 + reliabilityScore * 0.2));
    return {
      ...entry,
      recencyScore: round(recencyScore),
      salienceScore: round(salienceScore),
      reliabilityScore: round(reliabilityScore),
      relevance: totalRelevance
    };
  });

  return scored
    .filter(x => (query.minRelevance ? x.relevance >= query.minRelevance : true))
    .sort((a, b) => b.relevance - a.relevance)
    .slice(0, limit);
}

/**
 * Causal Attribution & Outcome Learning (`reportOutcome` / `learnFromOutcome`)
 *
 * Implements Weiner-style causal attribution:
 * Distinguishes the NPC's own contribution from:
 * - Ally assistance or ally failure (`allyContribution`: -1..1)
 * - External environment / weather / terrain (`externalFactor`: -1..1)
 * - Equipment / supply quality (`equipmentFactor`: -1..1)
 * - Random luck (`luckFactor`: -1..1)
 * - Bad intelligence / false report (`intelligenceSourceId`, `intelligenceAccurate`)
 *
 * Rules:
 * 1. Only real outcomes (`participated !== false` and `meaningfulExposure !== false`) grant skill growth or event memories.
 *    Merely being assigned to a mission without executing/participating grants 0 skill.
 * 2. Both success and failure can teach procedural skill when the NPC actively engaged and can attribute causal lessons,
 *    scaled by self-attribution share.
 * 3. External/ally-caused failures do not unfairly crush the NPC's self-competence belief in the action, whereas
 *    self-caused failures record strong cautionary lessons and trigger replanning.
 */
function reportOutcome(npc, outcome = {}) {
  if (!npc || !isObject(npc)) throw new NpcEngineError(ERROR_CODES.INVALID_NPC, 'reportOutcome requires a valid NPC');
  if (!isObject(outcome) || !outcome.actionId) {
    throw new NpcEngineError(ERROR_CODES.INVALID_OUTCOME, 'Outcome requires an actionId');
  }

  ensureKnowledgeAndTechniqueState(npc);
  const agency = ensureGoalAndSocialState(npc);
  const actionId = String(outcome.actionId);
  const act = descriptor(actionId);
  const now = Number.isFinite(outcome.time) ? outcome.time : 0;
  const status = outcome.status || (outcome.success === false ? 'failure' : 'success'); // 'success' | 'partial' | 'failure' | 'interrupted'

  // Check if the NPC actually participated and had meaningful exposure
  const participated = outcome.participated !== false && outcome.meaningfulExposure !== false;
  const exposureIntensity = Number.isFinite(outcome.exposureIntensity)
    ? clamp(outcome.exposureIntensity * 100, 0, 200) / 100
    : (participated ? 1.0 : 0);

  // Causal Attribution calculation
  const metaCognition = raw(npc, 'cognition', 'metacognition') / 100;
  const rationality = getAxis(npc, 'personality', 'rationality') / 100;
  const pride = getAxis(npc, 'personality', 'pride') / 100;

  const causes = outcome.causes || {};
  const selfContribution = clamp((causes.self ?? 0.65) * 100, 0, 100) / 100;
  const allyContribution = clamp((causes.allies ?? 0) * 100, -100, 100) / 100;
  const externalFactor = clamp((causes.weatherOrTerrain ?? causes.external ?? 0) * 100, -100, 100) / 100;
  const equipmentFactor = clamp((causes.equipment ?? 0) * 100, -100, 100) / 100;
  const luckFactor = clamp((causes.luck ?? 0) * 100, -100, 100) / 100;

  // How accurately the NPC attributes the cause (high metacognition + rationality reduces self-serving bias)
  const biasResistance = clamp((metaCognition * 0.6 + rationality * 0.4 - pride * 0.25) * 100, 15, 95) / 100;
  const externalMagnitude = Math.min(0.85, Math.abs(allyContribution) * 0.35 + Math.abs(externalFactor) * 0.35 + Math.abs(equipmentFactor) * 0.2 + Math.abs(luckFactor) * 0.3);
  const perceivedSelfShare = round(clamp(
    (selfContribution * (1 - externalMagnitude * biasResistance) + (status === 'success' ? pride * 0.15 * (1 - biasResistance) : 0)) * 100,
    10,
    100
  ) / 100);

  // Determine raw outcome valence (-20..20)
  const baseValence = Number.isFinite(outcome.valence)
    ? clamp(outcome.valence, -20, 20)
    : status === 'success'
      ? 10
      : status === 'partial'
        ? 3
        : status === 'interrupted'
          ? -3
          : -10;

  // Attributed valence for action belief update: if failure was mostly caused by weather/allies/bad intel
  // and NPC has high metacognition, the NPC doesn't over-penalize the action type itself as much
  const attributedActionValence = status === 'failure' && externalMagnitude >= 0.45
    ? round(baseValence * perceivedSelfShare)
    : round(baseValence);

  // 1. Skill Progression (ONLY if participated with meaningful exposure > 0)
  let skillGain = 0;
  if (participated && exposureIntensity > 0.05) {
    // Failure also teaches lessons (at 65% of success practice rate) when the NPC analyzes what went wrong
    const outcomeLearningFactor = status === 'success'
      ? 1.0
      : status === 'partial'
        ? 0.8
        : status === 'failure'
          ? (0.45 + metaCognition * 0.35)
          : 0.25;
    const practiceAmount = round(
      (act.learningEvidence?.basePractice ?? 1) *
      exposureIntensity *
      outcomeLearningFactor *
      (0.35 + perceivedSelfShare * 0.65)
    );
    if (practiceAmount > 0) {
      skillGain = learn(npc, actionId, practiceAmount);
    }
  }

  // 2. Record Episodic Memory (ONLY if real outcome occurred)
  let memoryRecorded = false;
  if (participated) {
    memoryRecorded = remember(
      npc,
      actionId,
      attributedActionValence,
      outcome.summary || `${act.label}: ${status}`,
      now,
      {
        source: 'experienced',
        confidence: 1.0,
        domainId: act.capabilityDomain,
        participants: outcome.participants || [],
        socialType: outcome.socialType || null,
        formative: Boolean(outcome.formative || Math.abs(baseValence) >= 16),
        eventId: outcome.eventId || null
      }
    );
  }

  // 3. Update Domain Attribution & Confidence record
  const domAttr = npc.core.human.experience.domainAttribution[act.capabilityDomain] || {
    attempts: 0,
    successes: 0,
    failures: 0,
    confidenceAdjustment: 0,
    lastAttribution: null
  };
  if (participated) {
    domAttr.attempts++;
    if (status === 'success') domAttr.successes++;
    if (status === 'failure') domAttr.failures++;
    const confDelta = status === 'success'
      ? 3.5 * perceivedSelfShare
      : status === 'failure'
        ? -4.0 * perceivedSelfShare
        : 0;
    domAttr.confidenceAdjustment = round(clamp(domAttr.confidenceAdjustment + confDelta, -25, 25));
    domAttr.lastAttribution = {
      time: now,
      actionId,
      status,
      perceivedSelfShare,
      externalMagnitude: round(externalMagnitude)
    };
    npc.core.human.experience.domainAttribution[act.capabilityDomain] = domAttr;
  }

  // 4. Update Ally Relationships based on allyContribution
  if (Array.isArray(outcome.participants)) {
    for (const allyId of outcome.participants) {
      if (allyId === npc.id) continue;
      const rel = getRelationship(npc, allyId) || { trust: 50, respect: 50, resentment: 0 };
      if (allyContribution >= 0.25 && status === 'success') {
        setRelationship(npc, allyId, {
          trust: clamp(rel.trust + 6, 0, 100),
          respect: clamp(rel.respect + 5, 0, 100)
        });
      } else if (allyContribution <= -0.25 && status === 'failure') {
        setRelationship(npc, allyId, {
          trust: clamp(rel.trust - 8, 0, 100),
          resentment: clamp(rel.resentment + 10, 0, 100)
        });
      }
    }
  }

  // 5. Calibrate Intelligence Source Trust if outcome revealed report accuracy
  if (outcome.intelligenceSourceId && typeof outcome.intelligenceAccurate === 'boolean') {
    calibrateSourceTrust(npc, outcome.intelligenceSourceId, outcome.intelligenceAccurate, 0.35);
  }

  // 6. Apply world-reported condition changes (fatigue, damage/injury, supply changes, discovered facts)
  if (Number.isFinite(outcome.fatigueDelta)) {
    npc.core.condition.fatigue = round(clamp((npc.core.condition.fatigue || 0) + outcome.fatigueDelta, 0, 100));
  }
  if (Number.isFinite(outcome.healthDelta)) {
    npc.health = round(clamp(npc.health + outcome.healthDelta, 0, 240));
  }
  if (Number.isFinite(outcome.injuryAmount) && outcome.injuryAmount > 0) {
    injure(npc, outcome.injuryAmount, now, outcome.injuredPart || null);
  }
  if (Number.isFinite(outcome.supplyDaysDelta) && npc.stageLocal?.readiness) {
    npc.stageLocal.readiness.supplyDays = Math.max(0, round((npc.stageLocal.readiness.supplyDays ?? 30) + outcome.supplyDaysDelta));
  }
  if (isObject(outcome.discoveredFacts) && Object.keys(outcome.discoveredFacts).length > 0) {
    observe(npc, {
      time: now,
      source: 'direct_observation',
      sourceId: `outcome:${actionId}`,
      clarity: 0.95,
      facts: outcome.discoveredFacts
    });
  }
  if (Array.isArray(outcome.learnedKnowledge)) {
    for (const kRec of outcome.learnedKnowledge) {
      grantKnowledge(npc, { ...kRec, acquiredAt: now, practiced: true });
    }
  }

  // 7. Track failed action history to prevent repeating failed actions blindly, and advance/invalidate active plan
  let shouldReplan = false;
  let replanReason = null;

  if (status === 'failure' || status === 'interrupted') {
    const prevFail = agency.failedActionHistory[actionId] || { count: 0, lastFailedAt: 0, lastReason: null };
    agency.failedActionHistory[actionId] = {
      count: prevFail.count + 1,
      lastFailedAt: now,
      lastReason: outcome.failureReason || status,
      perceivedSelfShare
    };
    shouldReplan = true;
    replanReason = outcome.failureReason || `ACTION_${status.toUpperCase()}`;
  } else if (status === 'success') {
    // Clear consecutive failure penalty on success
    delete agency.failedActionHistory[actionId];
    // Mark practiced on relevant domain knowledge
    for (const kRec of Object.values(npc.core.human.experience.knowledge || {})) {
      if (resolveCapabilityDomainId(kRec.domainId) === act.capabilityDomain) {
        kRec.practiced = true;
      }
    }
  }

  if (agency.activePlan) {
    if (shouldReplan) {
      agency.activePlan.status = 'requires_replan';
      agency.activePlan.replanReason = replanReason;
    } else if (agency.activePlan.steps && agency.activePlan.steps[agency.activePlan.currentStepIndex]?.actionId === actionId) {
      agency.activePlan.currentStepIndex++;
      if (agency.activePlan.currentStepIndex >= agency.activePlan.steps.length) {
        agency.activePlan.status = 'completed';
      }
    }
  }

  return {
    actionId,
    status,
    participated,
    skillGain,
    memoryRecorded,
    attributedActionValence,
    perceivedSelfShare,
    externalMagnitude: round(externalMagnitude),
    shouldReplan,
    replanReason
  };
}

module.exports = {
  MAX_EPISODIC_MEMORIES,
  MAX_REFLECTIONS,
  MAX_SOCIAL_MEMORIES,
  skill,
  liking,
  capacity,
  workRate,
  learningRate,
  harvestLimit,
  learn,
  remember,
  memoryBias,
  retrieveMemories,
  reportOutcome,
  learnFromOutcome: reportOutcome
};

  };
  __MODULES['decision_engine'] = function(module, exports, require, globalThis) {
'use strict';

/**
 * Unified Hybrid Decision & Bounded Planning Engine (BDI + Utility AI + Bounded GOAP/HTN)
 *
 * Implements Sections 6, 8, 9, 10 of MASTER_PROMPT_EN.md while preserving 100%
 * compatibility with v1.0 `evaluate`, `option`, `scoreDecisionOptions`, and `chooseDecisionOption`:
 *
 * 1. One shared decision brain across all 15 Three Kingdoms capability domains
 * 2. Hard feasibility filtering BEFORE scoring (no impossible actions selected)
 * 3. Rich Utility Evaluation combining:
 *    - Identity bias (interest, capability, metacognition, unmet needs, risk readiness)
 *    - Life values & personality weights
 *    - Innate aptitudes & demonstrated capability mastery
 *    - Explicit knowledge & learned techniques bonus
 *    - Active goals, mission orders, commitments, and deadlines
 *    - Episodic & consolidated lesson memory bias
 *    - Repeated-failure penalty (prevents blind repetition of failed actions)
 *    - Situational utility & external adapter outcome estimates
 * 4. Bounded Multi-Step Planner (GOAP / HTN hybrid forward A*-style search with configurable
 *    maxDepth, maxExpansions, and fallback behavior)
 * 5. Explicit Intention Commitment & Replanning Triggers (surprises, broken assumptions,
 *    action failure, resource loss, injury, ally defeat, deadline shift, new orders)
 * 6. 100% Deterministic seeded RNG (never calls raw Math.random() in core autonomous decisions)
 */

const {
  NpcEngineError,
  ERROR_CODES,
  clamp,
  round,
  isObject,
  hash,
  createRng
} = __require('utils');
const { validAxisGroups, getAxis } = __require('identity_core');
const { condition, effective, temperature } = __require('condition_system');
const {
  activities,
  descriptor,
  checkActionFeasibility,
  generateCandidates
} = __require('action_registry');
const {
  evaluateCapabilityDomain
} = __require('knowledge_system');
const {
  getBelief,
  getBeliefSnapshot
} = __require('belief_system');
const {
  ensureGoalAndSocialState,
  evaluateActiveDrivesAndGoals
} = __require('goal_system');
const {
  liking,
  capacity,
  memoryBias
} = __require('memory_learning');

function evaluate(n, id, { risk = 0 } = {}) {
  const d = descriptor(id);
  const h = n.core.human;
  const cap = capacity(n, id);
  const interest = liking(n, id);
  const meta = effective(n, 'cognition', 'metacognition');
  const interestAdj = round((interest - 50) * 0.34);
  const capabilityAdj = round((cap.total - 50) * 0.16 * (0.35 + meta * 0.0065));
  let needAdj = 0;
  for (const [k, w] of Object.entries(d.needRelief)) {
    const unmet = k === 'social' ? (n.stageLocal?.needs?.social ?? 0) : h.state[k];
    needAdj += (unmet - 25) * w * 0.22;
  }
  needAdj = round(clamp(needAdj, -8, 18));
  const readiness = cap.total * 0.65 + condition(n).healthRatio * 35;
  const riskEstimateAdj = round(-Math.max(0, risk - readiness) * (0.06 + meta * 0.0018));
  return {
    interest,
    ...cap,
    interestAdj,
    capabilityAdj,
    needAdj,
    riskEstimateAdj,
    bias: round(interestAdj + capabilityAdj + needAdj + riskEstimateAdj)
  };
}

function option(n, opt, id = opt.id) {
  for (const [group, valid] of Object.entries(validAxisGroups)) {
    for (const [key, weight] of Object.entries(opt[group] || {})) {
      if (!valid.has(key) || !Number.isFinite(weight)) {
        throw new NpcEngineError(ERROR_CODES.INVALID_AXIS, 'Unknown human axis: ' + group + '.' + key);
      }
    }
  }
  const d = descriptor(id);
  const human = evaluate(n, id, { risk: opt.riskLevel ?? opt.risk ?? d.risk ?? 0 });
  return {
    ...opt,
    baseScore: round((opt.baseScore ?? 50) + human.bias),
    valueWeights: { ...d.valueWeights, ...opt.valueWeights },
    personalityWeights: { ...d.personalityWeights, ...opt.personalityWeights },
    aptitudeWeights: { ...d.aptitudeWeights, ...opt.aptitudeWeights },
    human,
    activityId: d.id
  };
}

function preferenceBias(n, group, weights, scale) {
  let total = 0;
  for (const [id, w] of Object.entries(weights || {})) {
    total += (getAxis(n, group, id) - 50) * w * scale;
  }
  return round(total);
}

function scoreDecisionOptions(n, options, context = {}) {
  if (!Array.isArray(options)) throw new NpcEngineError(ERROR_CODES.INVALID_ACTION_DEF, 'Options must be an array');
  const memories = n.stageLocal?.memories || [];
  const now = Number.isFinite(context.time) ? context.time : memories.reduce((m, e) => Math.max(m, Number(e.t) || 0), 0);

  const hasActiveAgency = Boolean(
    context.enableExtendedScoring ||
    (n.stageLocal?.agency && (
      n.stageLocal.agency.goals?.length > 0 ||
      n.stageLocal.agency.activeOrders?.length > 0 ||
      Object.keys(n.stageLocal.agency.failedActionHistory || {}).length > 0
    ))
  );

  const activeDrives = hasActiveAgency ? evaluateActiveDrivesAndGoals(n, { ...context, time: now }) : [];
  const failedHistory = n.stageLocal?.agency?.failedActionHistory || {};

  return options.map(opt => {
    const actionId = opt.activityId || opt.id;
    const d = descriptor(actionId);
    const enriched = option(n, opt, actionId);

    let goalAlignment = 0;
    if (activeDrives.length > 0) {
      for (const g of activeDrives) {
        if (Array.isArray(g.avoidActions) && g.avoidActions.includes(actionId)) {
          goalAlignment -= g.effectivePriority * 0.35;
        }
        if (Array.isArray(g.preferredActions) && g.preferredActions.includes(actionId)) {
          goalAlignment += g.effectivePriority * 0.28;
        } else if (Array.isArray(g.preferredDomains) && g.preferredDomains.includes(d.capabilityDomain)) {
          goalAlignment += g.effectivePriority * 0.14;
        }
        if (g.desiredState && d.effects) {
          for (const [k, v] of Object.entries(g.desiredState)) {
            if (d.effects[k] === v) {
              goalAlignment += g.effectivePriority * 0.25;
            }
          }
        }
      }
    }

    let failurePenalty = 0;
    const failRec = failedHistory[actionId];
    if (failRec && failRec.count > 0) {
      const recency = Math.max(0.25, 1 - Math.max(0, now - failRec.lastFailedAt) / 200);
      failurePenalty = -round(failRec.count * 14 * recency * (0.5 + (failRec.perceivedSelfShare ?? 0.7) * 0.5));
    }

    let masteryAndAdapterAdj = 0;
    if (hasActiveAgency) {
      const domEval = evaluateCapabilityDomain(n, d.capabilityDomain || d.skillDomain, context);
      masteryAndAdapterAdj += round((domEval.mastery - 25) * 0.18 - domEval.conditionPenalty * 0.15);
      if (d.adapter && typeof d.adapter.estimateOutcome === 'function') {
        const est = d.adapter.estimateOutcome(n, d, context);
        if (est && Number.isFinite(est.utilityAdjustment)) {
          masteryAndAdapterAdj += round(est.utilityAdjustment);
        }
      }
    }

    const riskLevel = opt.riskLevel ?? opt.risk ?? d.risk ?? 0;
    let riskPersonalityAdj = 0;
    if (hasActiveAgency && riskLevel > 25) {
      const caution = getAxis(n, 'personality', 'caution');
      const courage = getAxis(n, 'personality', 'courage');
      riskPersonalityAdj = round(((courage - caution) / 100) * (riskLevel - 25) * 0.22);
    }

    const contributions = {
      identity: enriched.human.bias,
      values: preferenceBias(n, 'values', enriched.valueWeights, 0.34),
      personality: preferenceBias(n, 'personality', enriched.personalityWeights, 0.24),
      aptitudes: preferenceBias(n, 'aptitudes', enriched.aptitudeWeights, 0.22),
      memory: context.includeMemory === false
        ? 0
        : round(memoryBias(n, actionId, now, hasActiveAgency ? context : null) * (Number.isFinite(context.memoryScale) ? context.memoryScale : 0.65)),
      situation: Number.isFinite(opt.situationalBias) ? opt.situationalBias : 0
    };

    if (hasActiveAgency) {
      contributions.goals = round(goalAlignment);
      contributions.masteryAndAdapter = round(masteryAndAdapterAdj);
      contributions.riskTolerance = round(riskPersonalityAdj);
      contributions.failureAvoidance = round(failurePenalty);
    }

    const totalExtra = hasActiveAgency
      ? contributions.goals + contributions.masteryAndAdapter + contributions.riskTolerance + contributions.failureAvoidance
      : 0;

    const score = round(
      enriched.baseScore +
      contributions.values +
      contributions.personality +
      contributions.aptitudes +
      contributions.memory +
      contributions.situation +
      totalExtra
    );

    return {
      ...enriched,
      score,
      decisionContributions: contributions
    };
  }).sort((a, b) => b.score - a.score || String(a.id).localeCompare(String(b.id)));
}

function chooseDecisionOption(n, options, context = {}) {
  const alreadyScored = Array.isArray(options) && options.length > 0 && options.every(x => Number.isFinite(x.score) && x.decisionContributions);
  const scored = alreadyScored ? options.slice().sort((a, b) => b.score - a.score) : scoreDecisionOptions(n, options, context);
  if (!scored.length) return null;

  if (context.deterministicTopChoice === true) {
    return scored[0];
  }

  const temp = Number.isFinite(context.temperature) ? clamp(context.temperature, 1, 30) : temperature(n);
  const rngFn = typeof context.rng === 'function'
    ? context.rng
    : createRng(
      context.seed ?? n.core?.human?.identityId ?? n.id,
      `choose:${n.id}:${context.time ?? 0}:${scored.map(s => s.id).join(',')}`
    ).next;

  const max = scored[0].score;
  const weights = scored.map(x => Math.exp((x.score - max) / temp));
  const sum = weights.reduce((a, b) => a + b, 0);
  let pick = clamp(rngFn(), 0, 0.999999999999) * sum;
  for (let i = 0; i < scored.length; i++) {
    pick -= weights[i];
    if (pick <= 0) return scored[i];
  }
  return scored[scored.length - 1];
}

/**
 * Bounded Multi-Step Planner (GOAP / HTN hybrid forward search over belief state)
 */
function buildMultiStepPlan(npc, goalState, candidateActions, context = {}) {
  const maxDepth = clamp(context.maxDepth ?? 4, 1, 8);
  const maxExpansions = clamp(context.maxExpansions ?? 64, 4, 256);

  const beliefSnapshot = getBeliefSnapshot(npc, { currentTime: context.time, minConfidence: 0.4 });
  const initialSymbols = { ...(context.perceivedState || {}) };
  for (const [k, rec] of Object.entries(beliefSnapshot)) {
    initialSymbols[k] = rec.value;
  }

  const satisfiesGoal = (state) => {
    if (!isObject(goalState) || Object.keys(goalState).length === 0) return false;
    return Object.entries(goalState).every(([k, v]) => state[k] === v);
  };

  if (satisfiesGoal(initialSymbols)) {
    return {
      found: true,
      alreadySatisfied: true,
      steps: [],
      expansions: 0,
      assumptions: { ...initialSymbols }
    };
  }

  const rawPool = Array.isArray(candidateActions) && candidateActions.length > 0
    ? candidateActions
    : Object.values(activities);

  const scoredActions = scoreDecisionOptions(
    npc,
    rawPool.map(a => (typeof a === 'string' ? { id: a } : a)),
    { ...context, enableExtendedScoring: true }
  );

  const actionOperators = scoredActions.map(sa => {
    const def = descriptor(sa.activityId || sa.id);
    const stepCost = Math.max(1, round(120 - clamp(sa.score, 10, 110) + (def.timeCost || 1) * 5));
    return {
      id: sa.id,
      label: def.label,
      domainId: def.capabilityDomain,
      preconditions: { ...(def.preconditions || {}), ...(sa.preconditions || {}) },
      effects: { ...(def.effects || {}), ...(sa.effects || {}) },
      timeCost: def.timeCost || 1,
      resourceCosts: { ...(def.requiredResources || {}), ...(sa.requiredResources || {}) },
      score: sa.score,
      stepCost,
      decisionContributions: sa.decisionContributions,
      def
    };
  });

  const deadline = Number.isFinite(context.deadline) ? context.deadline : null;
  const startTime = Number.isFinite(context.time) ? context.time : 0;
  const startResources = { ...(context.resources || npc.stageLocal?.resources || {}) };
  if (startResources.supplyDays === undefined && npc.stageLocal?.readiness?.supplyDays !== undefined) {
    startResources.supplyDays = npc.stageLocal.readiness.supplyDays;
  }

  const heuristic = (state) => {
    let unmet = 0;
    for (const [k, v] of Object.entries(goalState)) {
      if (state[k] !== v) unmet++;
    }
    return unmet * 15;
  };

  const frontier = [{
    gCost: 0,
    fCost: heuristic(initialSymbols),
    state: initialSymbols,
    resources: startResources,
    elapsedTime: 0,
    steps: []
  }];

  const visited = new Map();
  let expansions = 0;

  while (frontier.length > 0 && expansions < maxExpansions) {
    frontier.sort((a, b) => a.fCost - b.fCost || a.steps.length - b.steps.length);
    const current = frontier.shift();
    expansions++;

    if (satisfiesGoal(current.state)) {
      return {
        found: true,
        alreadySatisfied: false,
        steps: current.steps,
        totalTimeCost: current.elapsedTime,
        totalCost: round(current.gCost),
        expansions,
        assumptions: { ...initialSymbols },
        goalState: { ...goalState }
      };
    }

    if (current.steps.length >= maxDepth) continue;

    const stateKey = JSON.stringify(Object.entries(current.state).sort(([a], [b]) => a.localeCompare(b)));
    if (visited.has(stateKey) && visited.get(stateKey) <= current.gCost) continue;
    visited.set(stateKey, current.gCost);

    for (const op of actionOperators) {
      if (current.steps.length > 0 && current.steps[current.steps.length - 1].actionId === op.id) continue;

      const precondsMet = Object.entries(op.preconditions).every(([k, v]) => current.state[k] === v);
      if (!precondsMet) continue;

      // Check capability/knowledge/equipment/resource feasibility at the simulated intermediate state!
      const stepDefWithoutPreconditions = { ...op.def, preconditions: {} };
      const feas = checkActionFeasibility(npc, stepDefWithoutPreconditions, {
        ...context,
        perceivedState: current.state,
        resources: current.resources
      });
      if (!feas.feasible) continue;

      const nextElapsed = current.elapsedTime + op.timeCost;
      if (deadline !== null && startTime + nextElapsed > deadline) continue;

      const nextResources = { ...current.resources };
      let resourceExhausted = false;
      for (const [rKey, rCost] of Object.entries(op.resourceCosts)) {
        if (nextResources[rKey] !== undefined) {
          if (nextResources[rKey] < rCost) {
            resourceExhausted = true;
            break;
          }
          nextResources[rKey] = round(nextResources[rKey] - rCost);
        }
      }
      if (resourceExhausted) continue;

      const effectEntries = Object.entries(op.effects);
      if (effectEntries.length === 0) continue;
      const changesSomething = effectEntries.some(([k, v]) => current.state[k] !== v);
      if (!changesSomething) continue;

      const nextState = { ...current.state, ...op.effects };
      const nextSteps = [
        ...current.steps,
        {
          actionId: op.id,
          label: op.label,
          domainId: op.domainId,
          score: op.score,
          timeCost: op.timeCost,
          expectedEffects: { ...op.effects },
          preconditions: { ...op.preconditions }
        }
      ];
      const nextG = current.gCost + op.stepCost;
      frontier.push({
        gCost: nextG,
        fCost: nextG + heuristic(nextState),
        state: nextState,
        resources: nextResources,
        elapsedTime: nextElapsed,
        steps: nextSteps
      });
    }
  }

  return {
    found: false,
    alreadySatisfied: false,
    steps: [],
    expansions,
    reason: expansions >= maxExpansions ? 'PLANNING_BUDGET_EXHAUSTED' : 'NO_FEASIBLE_PLAN_FOR_GOAL'
  };
}

function checkPlanValidity(npc, activePlan, context = {}) {
  if (!activePlan || !Array.isArray(activePlan.steps) || activePlan.steps.length === 0) {
    return { valid: false, reason: 'NO_ACTIVE_PLAN' };
  }
  if (activePlan.status === 'completed') {
    return { valid: false, reason: 'PLAN_ALREADY_COMPLETED' };
  }
  if (activePlan.status === 'requires_replan') {
    return { valid: false, reason: activePlan.replanReason || 'FLAGGED_FOR_REPLAN' };
  }
  if (context.forceReplan) {
    return { valid: false, reason: 'FORCED_REPLAN_TRIGGER' };
  }

  const currentStep = activePlan.steps[activePlan.currentStepIndex || 0];
  if (!currentStep) {
    return { valid: false, reason: 'NO_REMAINING_STEPS' };
  }

  if (Number.isFinite(context.deadline) && Number.isFinite(context.time)) {
    const remainingTime = activePlan.steps
      .slice(activePlan.currentStepIndex || 0)
      .reduce((s, st) => s + (st.timeCost || 1), 0);
    if (context.time + remainingTime > context.deadline) {
      return { valid: false, reason: 'DEADLINE_EXCEEDED' };
    }
  }

  const feas = checkActionFeasibility(npc, currentStep.actionId, context);
  if (!feas.feasible) {
    return {
      valid: false,
      reason: 'STEP_INFEASIBLE',
      infeasibleReasons: feas.reasons
    };
  }

  if (isObject(activePlan.assumptions)) {
    for (const [k, expectedVal] of Object.entries(currentStep.preconditions || {})) {
      const belief = getBelief(npc, k, context.time);
      const currentVal = belief ? belief.value : context.perceivedState?.[k];
      if (currentVal !== undefined && currentVal !== expectedVal) {
        return {
          valid: false,
          reason: `ASSUMPTION_INVALIDATED:${k}`
        };
      }
    }
  }

  return { valid: true, currentStep };
}

function decide(npc, context = {}) {
  if (!npc || !isObject(npc)) throw new NpcEngineError(ERROR_CODES.INVALID_NPC, 'decide requires a valid NPC');
  const agency = ensureGoalAndSocialState(npc);
  const now = Number.isFinite(context.time) ? context.time : 0;

  const { observe } = __require('belief_system');
  const observationResults = [];
  if (Array.isArray(context.observations)) {
    for (const obs of context.observations) {
      observationResults.push(observe(npc, { time: now, ...obs }));
    }
  } else if (isObject(context.observation)) {
    observationResults.push(observe(npc, { time: now, ...context.observation }));
  }

  let orderEvaluation = null;
  if (isObject(context.order)) {
    const { issueOrder } = __require('goal_system');
    orderEvaluation = issueOrder(npc, context.order, { ...context, time: now });
  }

  const activeDrives = evaluateActiveDrivesAndGoals(npc, { ...context, time: now });
  const topGoal = activeDrives[0] || null;

  const { feasibleCandidates, rejectedCandidates } = generateCandidates(npc, {
    ...context,
    time: now
  });

  if (feasibleCandidates.length === 0) {
    const fallbackTraceId = 'TRC-' + hash(`${npc.id}:${now}:fallback`).toString(16).padStart(8, '0');
    const fallbackIntent = {
      traceId: fallbackTraceId,
      npcId: npc.id,
      time: now,
      status: 'fallback_idle',
      actionId: 'rest',
      label: descriptor('rest').label,
      domainId: 'medicine_care',
      reasonCodes: ['NO_FEASIBLE_CANDIDATES', 'FALLBACK_RECOVERY'],
      rejectedCandidates,
      expectedOutcome: { status: 'recovery' },
      confidence: 0.5,
      riskLevel: 0,
      replanTriggers: ['resources_restored', 'condition_recovered']
    };
    agency.lastIntention = fallbackIntent;
    return fallbackIntent;
  }

  let planResult = null;
  let replanned = false;
  let replanReason = null;

  const validity = checkPlanValidity(npc, agency.activePlan, { ...context, time: now });
  if (validity.valid) {
    planResult = agency.activePlan;
  } else {
    if (agency.activePlan) {
      replanned = true;
      replanReason = validity.reason;
    }
    const desiredState = context.goalState || topGoal?.desiredState;
    if (isObject(desiredState) && Object.keys(desiredState).length > 0) {
      const rawPool = Array.isArray(context.candidateActions) && context.candidateActions.length > 0
        ? context.candidateActions
        : Object.values(activities);
      const built = buildMultiStepPlan(npc, desiredState, rawPool, {
        ...context,
        time: now,
        deadline: context.deadline ?? topGoal?.deadline ?? null
      });
      if (built.found && built.steps.length > 0) {
        planResult = {
          planId: 'PLN-' + hash(`${npc.id}:${now}:${JSON.stringify(desiredState)}`).toString(16).padStart(8, '0'),
          createdAt: now,
          goalId: topGoal ? topGoal.id : 'custom_goal',
          goalState: desiredState,
          steps: built.steps,
          currentStepIndex: 0,
          assumptions: built.assumptions,
          expansions: built.expansions,
          status: 'active'
        };
        agency.activePlan = planResult;
      }
    }
  }

  const scoredOptions = scoreDecisionOptions(npc, feasibleCandidates, {
    ...context,
    time: now,
    enableExtendedScoring: true
  });

  let chosenOption = null;
  if (planResult && planResult.steps && planResult.steps[planResult.currentStepIndex || 0]) {
    const stepActionId = planResult.steps[planResult.currentStepIndex || 0].actionId;
    chosenOption = scoredOptions.find(o => (o.activityId || o.id) === stepActionId) || scoredOptions[0];
  } else {
    chosenOption = chooseDecisionOption(npc, scoredOptions, {
      ...context,
      time: now,
      deterministicTopChoice: context.deterministicTopChoice ?? true
    });
  }

  const chosenId = chosenOption.activityId || chosenOption.id;
  const chosenDef = descriptor(chosenId);
  const capEval = evaluateCapabilityDomain(npc, chosenDef.capabilityDomain || chosenDef.skillDomain, context);

  const reasonCodes = [];
  if (orderEvaluation) {
    reasonCodes.push(`ORDER_${orderEvaluation.responseMode.toUpperCase()}:${orderEvaluation.reasonCode}`);
  }
  if (replanned && replanReason) {
    reasonCodes.push(`REPLANNED:${replanReason}`);
  }
  if (planResult && planResult.steps?.length > 1) {
    reasonCodes.push(`MULTI_STEP_PLAN:step_${(planResult.currentStepIndex || 0) + 1}_of_${planResult.steps.length}`);
  }
  if (topGoal) {
    reasonCodes.push(`PRIMARY_DRIVE:${topGoal.id}`);
  }
  const c = chosenOption.decisionContributions || {};
  if (Math.abs(c.values || 0) >= 4) reasonCodes.push(c.values > 0 ? 'VALUE_ALIGNMENT' : 'VALUE_AVERSION');
  if (Math.abs(c.personality || 0) >= 4) reasonCodes.push(c.personality > 0 ? 'PERSONALITY_FIT' : 'PERSONALITY_CAUTION');
  if (Math.abs(c.memory || 0) >= 2) reasonCodes.push(c.memory > 0 ? 'POSITIVE_PAST_EXPERIENCE' : 'PAST_FAILURE_CAUTION');
  if ((c.failureAvoidance || 0) < 0) reasonCodes.push('AVOIDED_REPEATED_FAILURE');
  reasonCodes.push(`CAPABILITY_TIER:${capEval.masteryTier.toUpperCase()}`);

  const traceId = 'TRC-' + hash(
    `${npc.id}:${now}:${chosenId}:${chosenOption.score}:${context.seed ?? 0}`
  ).toString(16).padStart(8, '0');

  const intention = {
    traceId,
    npcId: npc.id,
    time: now,
    status: 'committed',
    actionId: chosenId,
    label: chosenDef.label,
    domainId: chosenDef.capabilityDomain,
    score: chosenOption.score,
    decisionContributions: chosenOption.decisionContributions,
    capabilityAssessment: {
      domainId: capEval.domainId,
      mastery: capEval.mastery,
      effectiveCompetence: capEval.effectiveCompetence,
      executionQuality: capEval.executionQuality,
      errorRisk: capEval.errorRisk,
      speedMultiplier: capEval.speedMultiplier
    },
    activeGoalId: topGoal ? topGoal.id : null,
    orderResponse: orderEvaluation ? {
      orderId: orderEvaluation.id,
      responseMode: orderEvaluation.responseMode,
      reasonCode: orderEvaluation.reasonCode
    } : null,
    plan: planResult ? {
      planId: planResult.planId,
      stepIndex: planResult.currentStepIndex || 0,
      totalSteps: planResult.steps.length,
      steps: planResult.steps.map(s => s.actionId)
    } : null,
    replanned,
    replanReason,
    reasonCodes,
    expectedEffects: { ...(chosenDef.effects || {}), ...(chosenOption.effects || {}) },
    confidence: round(clamp((100 - capEval.errorRisk) * 0.85 + 10, 10, 98) / 100),
    riskLevel: chosenOption.riskLevel ?? chosenOption.risk ?? chosenDef.risk ?? 15,
    replanTriggers: chosenDef.replanTriggers,
    alternativesConsidered: scoredOptions.slice(0, 5).map(o => ({
      actionId: o.activityId || o.id,
      score: o.score
    })),
    rejectedCandidates,
    observationSummary: observationResults
  };

  agency.lastIntention = intention;
  npc.stageLocal.action = chosenId;

  if (!Array.isArray(npc.stageLocal.decisionTraces)) {
    npc.stageLocal.decisionTraces = [];
  }
  npc.stageLocal.decisionTraces.unshift(intention);
  if (npc.stageLocal.decisionTraces.length > 25) {
    npc.stageLocal.decisionTraces.length = 25;
  }

  return intention;
}

module.exports = {
  evaluate,
  option,
  preferenceBias,
  scoreDecisionOptions,
  chooseDecisionOption,
  buildMultiStepPlan,
  checkPlanValidity,
  decide,
  plan: buildMultiStepPlan,
  submitIntent: decide
};

  };
  __MODULES['multi_agent'] = function(module, exports, require, globalThis) {
'use strict';

/**
 * Multi-Agent Coordination, Command Hierarchy, Delegation & Plan Conflict Resolution
 *
 * Implements Section 14 of MASTER_PROMPT_EN.md:
 * - Separate but coordinated NPC plans (no omniscient shared plan)
 * - Explicit communication gating (information is shared only when visibility/channel allows)
 * - Command hierarchy and task delegation based on subordinate capability & loyalty
 * - Role specialization and deconfliction (avoiding redundant actions when coordinated)
 * - Reaction to ally injury, defeat, absence, or changed orders
 */

const { clamp, round, isObject } = __require('utils');
const { getAxis } = __require('identity_core');
const { evaluateCapabilityDomain } = __require('knowledge_system');
const { observe, getBeliefSnapshot } = __require('belief_system');
const { getRelationship, setRelationship, issueOrder } = __require('goal_system');

/**
 * Shares observations/beliefs from `senderNpc` to `receiverNpc` ONLY if a valid communication
 * channel exists (`direct_meeting`, `runner_courier`, `signal_banner`, `shared_camp`).
 */
function communicateBeliefs(senderNpc, receiverNpc, {
  channel = 'runner_courier',
  factKeys = null,
  time = 0,
  channelReliability = 0.88
} = {}) {
  if (!senderNpc || !receiverNpc || senderNpc.id === receiverNpc.id) {
    return { communicated: false, reason: 'INVALID_PARTICIPANTS' };
  }
  const allowedChannels = new Set(['direct_meeting', 'runner_courier', 'signal_banner', 'shared_camp']);
  if (!allowedChannels.has(channel)) {
    return { communicated: false, reason: 'NO_COMMUNICATION_CHANNEL' };
  }

  const senderBeliefs = getBeliefSnapshot(senderNpc, { currentTime: time, minConfidence: 0.35 });
  const keysToShare = Array.isArray(factKeys) ? factKeys : Object.keys(senderBeliefs);
  const payloadFacts = {};
  let avgSenderConf = 0;
  let count = 0;

  for (const k of keysToShare) {
    if (senderBeliefs[k]) {
      payloadFacts[k] = senderBeliefs[k].value;
      avgSenderConf += senderBeliefs[k].effectiveConfidence;
      count++;
    }
  }
  if (count === 0) {
    return { communicated: false, reason: 'NO_BELIEFS_TO_SHARE', sharedKeys: [] };
  }
  avgSenderConf /= count;

  const rel = getRelationship(receiverNpc, senderNpc.id);
  const trustFactor = rel ? (rel.trust / 100) : (getAxis(receiverNpc, 'personality', 'trustfulness') / 100);
  const effectiveReliability = clamp((avgSenderConf * channelReliability * (0.55 + trustFactor * 0.45)) * 100, 15, 95) / 100;

  const obsResult = observe(receiverNpc, {
    time,
    source: 'ally_report',
    sourceId: senderNpc.id,
    sourceReliability: effectiveReliability,
    clarity: channel === 'direct_meeting' ? 0.95 : channel === 'signal_banner' ? 0.75 : 0.85,
    facts: payloadFacts
  });

  return {
    communicated: true,
    channel,
    fromId: senderNpc.id,
    toId: receiverNpc.id,
    sharedKeys: obsResult.updatedKeys,
    calibratedConfidence: obsResult.calibratedConfidence
  };
}

/**
 * Assigns specialized roles/tasks across a group of allied NPCs deployed in a mission,
 * led by `commanderNpc` (or peer-coordinated if no commander is designated).
 * Prevents redundant duplicate assignments on exclusive tasks and matches roles to capabilities.
 */
function coordinateGroupRoles(npcs, missionTasks = [], {
  commanderId = null,
  communicationAvailable = true,
  time = 0
} = {}) {
  if (!Array.isArray(npcs) || npcs.length === 0 || !Array.isArray(missionTasks) || missionTasks.length === 0) {
    return { assignments: {}, unassignedTasks: [] };
  }

  // If communication is blocked (e.g. separated detachments in fog without couriers),
  // each agent cannot coordinate deconfliction and evaluates independently.
  if (!communicationAvailable) {
    return {
      coordinated: false,
      reason: 'COMMUNICATION_BLOCKED',
      assignments: {}
    };
  }

  const commander = commanderId ? npcs.find(n => n.id === commanderId) : npcs[0];
  const cmdCompetence = commander
    ? evaluateCapabilityDomain(commander, 'command_leadership').effectiveCompetence
    : 50;

  const assignments = {};
  const assignedNpcIds = new Set();
  const unassignedTasks = [];

  // Sort tasks by priority descending
  const sortedTasks = [...missionTasks].sort((a, b) => (b.priority ?? 50) - (a.priority ?? 50));

  for (const task of sortedTasks) {
    const domainId = task.requiredDomain || 'land_warfare';
    let bestNpc = null;
    let bestScore = -Infinity;

    for (const candidate of npcs) {
      if (assignedNpcIds.has(candidate.id) && !task.allowMultiple) continue;

      const cap = evaluateCapabilityDomain(candidate, domainId);
      const relToCmd = commander && candidate.id !== commander.id
        ? getRelationship(commander, candidate.id)
        : null;
      const trustBonus = relToCmd ? (relToCmd.trust - 50) * 0.25 - relToCmd.rivalry * 0.2 : 0;

      // Commander's personnel assessment quality determines how accurately they match capability to task
      const assessmentAccuracy = clamp(cmdCompetence / 100, 0.35, 1.0);
      const perceivedCompetence = cap.effectiveCompetence * assessmentAccuracy + 50 * (1 - assessmentAccuracy);
      const score = perceivedCompetence + trustBonus - cap.conditionPenalty * 0.3;

      if (score > bestScore) {
        bestScore = score;
        bestNpc = candidate;
      }
    }

    if (bestNpc) {
      assignedNpcIds.add(bestNpc.id);
      const orderOutcome = issueOrder(bestNpc, {
        id: `coord:${task.id}`,
        issuerId: commander ? commander.id : 'council',
        label: task.label || task.id,
        desiredState: task.desiredState || { [`task_${task.id}_done`]: true },
        mandatedActionId: task.actionId || null,
        preferredActions: task.preferredActions || (task.actionId ? [task.actionId] : []),
        alternativeActions: task.alternativeActions || [],
        preferredDomains: [domainId],
        priority: task.priority ?? 80,
        authority: commander && commander.id !== bestNpc.id ? clamp(55 + cmdCompetence * 0.4, 40, 98) : 75,
        estimatedRisk: task.riskLevel ?? 30,
        estimatedFeasibility: task.feasibility ?? 75
      }, { time });

      assignments[bestNpc.id] = {
        npcId: bestNpc.id,
        taskId: task.id,
        actionId: task.actionId || null,
        domainId,
        fitScore: round(bestScore),
        orderResponse: orderOutcome.responseMode,
        reasonCode: orderOutcome.reasonCode
      };
    } else {
      unassignedTasks.push(task.id);
    }
  }

  return {
    coordinated: true,
    commanderId: commander ? commander.id : null,
    commanderLeadershipCompetence: cmdCompetence,
    assignments,
    unassignedTasks
  };
}

/**
 * Resolves a plan proposal conflict between two allied officers (e.g., aggressive vanguard vs cautious strategist).
 */
function negotiateConflictingPlans(npcA, npcB, proposalA, proposalB, { arbiterNpc = null } = {}) {
  const dipA = evaluateCapabilityDomain(npcA, 'diplomacy_politics').effectiveCompetence;
  const stratA = evaluateCapabilityDomain(npcA, 'strategy_doctrine').effectiveCompetence;
  const dipB = evaluateCapabilityDomain(npcB, 'diplomacy_politics').effectiveCompetence;
  const stratB = evaluateCapabilityDomain(npcB, 'strategy_doctrine').effectiveCompetence;

  const relAB = getRelationship(npcA, npcB.id) || { trust: 50, respect: 50, rivalry: 0 };
  const relBA = getRelationship(npcB, npcA.id) || { trust: 50, respect: 50, rivalry: 0 };

  const weightA = stratA * 0.5 + dipA * 0.3 + (proposalA.expectedUtility ?? 50) * 0.4 - (proposalA.riskLevel ?? 30) * 0.25;
  const weightB = stratB * 0.5 + dipB * 0.3 + (proposalB.expectedUtility ?? 50) * 0.4 - (proposalB.riskLevel ?? 30) * 0.25;

  let arbiterBiasA = 0;
  if (arbiterNpc) {
    const arbRationality = getAxis(arbiterNpc, 'personality', 'rationality') / 100;
    const arbCaution = getAxis(arbiterNpc, 'personality', 'caution');
    const riskDiff = (proposalB.riskLevel ?? 30) - (proposalA.riskLevel ?? 30);
    arbiterBiasA = (weightA - weightB) * arbRationality + riskDiff * ((arbCaution - 50) / 100) * 0.4;
  }

  const totalScoreA = round(weightA + arbiterBiasA);
  const totalScoreB = round(weightB);
  const winner = totalScoreA >= totalScoreB ? 'A' : 'B';

  // High pride + high rivalry causes resentment when overruled; high composure + mutual respect accepts consensus
  const loserNpc = winner === 'A' ? npcB : npcA;
  const winnerNpc = winner === 'A' ? npcA : npcB;
  const loserPride = getAxis(loserNpc, 'personality', 'pride');
  const loserComposure = getAxis(loserNpc, 'personality', 'composure');
  const loserRel = winner === 'A' ? relBA : relAB;

  const acceptedGracefully = loserComposure >= 60 || loserRel.respect >= 65 || loserPride < 70;
  if (!acceptedGracefully) {
    setRelationship(loserNpc, winnerNpc.id, {
      resentment: clamp((loserRel.resentment || 0) + 8, 0, 100)
    });
  }

  return {
    selectedProposal: winner === 'A' ? proposalA : proposalB,
    winningNpcId: winnerNpc.id,
    losingNpcId: loserNpc.id,
    scoreA: totalScoreA,
    scoreB: totalScoreB,
    acceptedGracefully
  };
}

/**
 * Updates an NPC's state, grief, morale, and replanning triggers when an ally is injured, defeated, or absent.
 */
function reactToAllyOutcome(npc, allyId, eventType, { severity = 50, time = 0 } = {}) {
  const rel = getRelationship(npc, allyId) || {
    trust: 50,
    loyalty: 50,
    respect: 50,
    role: 'peer'
  };
  const empathy = getAxis(npc, 'personality', 'empathy');
  const loyalty = getAxis(npc, 'personality', 'loyalty');
  const composure = getAxis(npc, 'personality', 'composure');
  const familyClan = getAxis(npc, 'values', 'familyClan');

  const bondStrength = (
    (rel.role === 'sworn_sibling' ? 35 : rel.role === 'liege' ? 25 : 10) +
    rel.trust * 0.35 +
    rel.loyalty * 0.3 +
    empathy * 0.15 +
    familyClan * 0.1
  ) / 100;

  let griefDelta = 0;
  let moraleDelta = 0;
  let triggerReplan = false;

  if (eventType === 'ally_defeated' || eventType === 'ally_killed' || eventType === 'ally_captured') {
    griefDelta = round(clamp(severity * bondStrength * (eventType === 'ally_killed' ? 0.85 : 0.45), 2, 60));
    moraleDelta = -round(clamp(severity * (0.45 - composure * 0.002), 5, 40));
    triggerReplan = true;
  } else if (eventType === 'ally_injured') {
    griefDelta = round(clamp(severity * bondStrength * 0.25, 1, 25));
    moraleDelta = -round(clamp(severity * 0.2, 2, 20));
    triggerReplan = severity >= 45;
  } else if (eventType === 'ally_betrayed') {
    setRelationship(npc, allyId, { trust: 5, loyalty: 0, resentment: 90 });
    moraleDelta = -15;
    triggerReplan = true;
  }

  npc.core.human.state.grief = round(clamp((npc.core.human.state.grief || 0) + griefDelta, 0, 100));
  if (npc.stageLocal?.readiness) {
    npc.stageLocal.readiness.morale = round(clamp((npc.stageLocal.readiness.morale ?? 80) + moraleDelta, 0, 100));
  }

  // Record observation in belief state so planner knows ally status changed
  observe(npc, {
    time,
    source: 'direct_observation',
    sourceId: allyId,
    clarity: 0.95,
    facts: {
      [`ally_${allyId}_status`]: eventType,
      ally_compromised: triggerReplan
    }
  });

  // If sworn sibling or close bond is endangered/defeated and loyalty/empathy are high, add urgent rescue/avenge goal
  if (triggerReplan && bondStrength >= 0.7 && (loyalty >= 70 || empathy >= 70 || rel.loyalty >= 80 || rel.role === "sworn_sibling")) {
    const { addGoal } = __require('goal_system');
    addGoal(npc, {
      id: `ally_crisis:${allyId}`,
      type: 'protect_dependents_allies',
      label: `Respond to crisis involving ally ${allyId} (${eventType})`,
      priority: round(clamp(75 + bondStrength * 20, 70, 98)),
      desiredState: eventType === 'ally_injured' ? { ally_treated: true } : { flank_stabilized: true },
      preferredActions: eventType === 'ally_injured'
        ? ['treat_battle_wounds', 'fighting_retreat', 'defend_city']
        : ['fighting_retreat', 'rally_wavering_troops', 'defend_city'],
      preferredDomains: ['medicine_care', 'command_leadership', 'land_warfare'],
      targetId: allyId,
      createdAt: time
    });
  }

  return {
    allyId,
    eventType,
    griefDelta,
    moraleDelta,
    triggerReplan,
    bondStrength: round(bondStrength)
  };
}

module.exports = {
  communicateBeliefs,
  coordinateGroupRoles,
  negotiateConflictingPlans,
  reactToAllyOutcome
};

  };
  __MODULES['persistence'] = function(module, exports, require, globalThis) {
'use strict';

/**
 * Persistence, Serialization, Save Validation & Legacy Migration Module
 *
 * Implements Section 4.1, 4.2, 13, 17 of MASTER_PROMPT_EN.md:
 * - Preserves `core.human.schemaVersion = 1`
 * - Never rerolls or resets identity axes or zero values on load
 * - Preserves learned skills, explicit knowledge, learned techniques, beliefs, goals,
 *   relationships, episodic/social memories, and consolidated reflections across save/load
 * - Tolerates unknown optional metadata safely without corrupting state
 */

const {
  ENGINE_VERSION,
  HUMAN_SCHEMA_VERSION,
  NpcEngineError,
  ERROR_CODES,
  isObject,
  deepClone
} = __require('utils');
const { validate, attach, fingerprint } = __require('identity_core');
const { ensureExtendedConditionState } = __require('condition_system');
const { ensureKnowledgeAndTechniqueState } = __require('knowledge_system');
const { ensureBeliefState } = __require('belief_system');
const { ensureGoalAndSocialState } = __require('goal_system');

/**
 * Validates a saved NPC record or world save payload.
 */
function validateSave(payload) {
  if (!isObject(payload)) {
    throw new NpcEngineError(ERROR_CODES.INVALID_SAVE, 'Save payload must be an object');
  }

  // Can validate either a single NPC object or a world save wrapper `{ npcs: { ... } }`
  if (isObject(payload.npcs)) {
    for (const [id, npc] of Object.entries(payload.npcs)) {
      if (!isObject(npc) || String(npc.id) !== String(id)) {
        throw new NpcEngineError(ERROR_CODES.INVALID_SAVE, `Canonical NPC ID mismatch for key ${id}`);
      }
      validate(npc);
    }
    return true;
  }

  const npc = payload.npc && isObject(payload.npc) ? payload.npc : payload;
  validate(npc);
  return true;
}

/**
 * Serializes an NPC (or world NPC map) into a clean, versioned, JSON-safe snapshot.
 */
function serialize(npcOrWorld, options = {}) {
  if (!isObject(npcOrWorld)) {
    throw new NpcEngineError(ERROR_CODES.INVALID_SAVE, 'serialize requires an NPC or world object');
  }
  const cloned = deepClone(npcOrWorld);
  validateSave(cloned);

  if (options.wrapEnvelope) {
    return JSON.stringify({
      engineVersion: ENGINE_VERSION,
      humanSchemaVersion: HUMAN_SCHEMA_VERSION,
      savedAt: options.savedAt ?? 0,
      data: cloned
    });
  }
  return JSON.stringify(cloned);
}

/**
 * Deserializes a JSON string or raw save object, migrates legacy v1.0 saves non-destructively
 * without rerolling any existing axis or zero value, and validates integrity.
 */
function deserialize(rawSave, { seed = 0 } = {}) {
  let parsed = rawSave;
  if (typeof rawSave === 'string') {
    try {
      parsed = JSON.parse(rawSave);
    } catch (err) {
      throw new NpcEngineError(ERROR_CODES.INVALID_SAVE, 'Malformed JSON save data: ' + err.message);
    }
  }
  if (!isObject(parsed)) {
    throw new NpcEngineError(ERROR_CODES.INVALID_SAVE, 'Deserialized save must be an object');
  }

  const data = parsed.data && isObject(parsed.data) && parsed.humanSchemaVersion !== undefined
    ? deepClone(parsed.data)
    : deepClone(parsed);

  const hydrateSingleNpc = (npc) => {
    // Attach fills ONLY missing fields while preserving all existing numbers (including 0)
    attach(npc, seed);
    ensureExtendedConditionState(npc);
    ensureKnowledgeAndTechniqueState(npc);
    ensureBeliefState(npc);
    ensureGoalAndSocialState(npc);
    validate(npc);
    return npc;
  };

  if (isObject(data.npcs)) {
    for (const [id, npc] of Object.entries(data.npcs)) {
      if (!npc.id) npc.id = id;
      hydrateSingleNpc(npc);
    }
    return data;
  }

  return hydrateSingleNpc(data);
}

/**
 * Verifies that two references point to the exact same canonical NPC record in `world.npcs[npc.id]`.
 */
function assertCanonicalNpcRecord(world, npc) {
  if (!isObject(world) || !isObject(world.npcs)) {
    throw new NpcEngineError(ERROR_CODES.INVALID_NPC, 'World requires an npcs registry object');
  }
  if (!npc || !npc.id) {
    throw new NpcEngineError(ERROR_CODES.INVALID_ID, 'NPC requires a stable id');
  }
  const existing = world.npcs[npc.id];
  if (!existing) {
    world.npcs[npc.id] = npc;
    return true;
  }
  if (existing !== npc) {
    throw new NpcEngineError(
      ERROR_CODES.INVALID_NPC,
      `Duplicate NPC instance detected for id ${npc.id}; UI/AI/Simulation must share one canonical object reference`
    );
  }
  return true;
}

module.exports = {
  validateSave,
  serialize,
  deserialize,
  assertCanonicalNpcRecord,
  fingerprint
};

  };
  __MODULES['diagnostics'] = function(module, exports, require, globalThis) {
'use strict';

/**
 * Diagnostics, Trace Inspection, and Capability/Decision Audit APIs
 *
 * Provides structured, concise diagnostic reports for testing, debugging,
 * and UI inspection without mutating NPC state.
 */

const { getIdentity, fingerprint } = __require('identity_core');
const { condition, emotions, clarity, temperature } = __require('condition_system');
const { inspectAllCapabilities } = __require('knowledge_system');
const { getBeliefSnapshot } = __require('belief_system');
const { evaluateActiveDrivesAndGoals } = __require('goal_system');
const { retrieveMemories } = __require('memory_learning');

function inspectNpcDiagnostics(npc, context = {}) {
  const identity = getIdentity(npc);
  const cond = condition(npc);
  const emo = emotions(npc);
  const capabilities = inspectAllCapabilities(npc, context);
  const beliefs = getBeliefSnapshot(npc, { currentTime: context.time, minConfidence: 0.2 });
  const drives = evaluateActiveDrivesAndGoals(npc, context);
  const recentMemories = retrieveMemories(npc, { time: context.time ?? 0, limit: 8 });
  const lastIntention = npc?.stageLocal?.agency?.lastIntention || null;
  const activePlan = npc?.stageLocal?.agency?.activePlan || null;

  return {
    npcId: npc.id,
    name: npc.name,
    fingerprint: fingerprint(npc),
    schemaVersion: identity.schemaVersion,
    axisCount: identity.axisCount,
    clarity: clarity(npc),
    decisionTemperature: temperature(npc),
    condition: cond,
    emotions: emo,
    capabilities,
    knowledgeCount: Object.keys(npc?.core?.human?.experience?.knowledge || {}).length,
    techniques: Object.keys(npc?.core?.human?.experience?.techniques || {}),
    beliefs,
    activeDrives: drives,
    activeOrders: npc?.stageLocal?.agency?.activeOrders || [],
    relationships: npc?.stageLocal?.agency?.relationships || {},
    activePlan,
    lastIntention,
    recentMemories,
    traceHistoryCount: (npc?.stageLocal?.decisionTraces || []).length
  };
}

function getDecisionTraces(npc, limit = 10) {
  const traces = npc?.stageLocal?.decisionTraces || [];
  return traces.slice(0, limit);
}

module.exports = {
  inspectNpcDiagnostics,
  getDecisionTraces
};

  };
  __MODULES['npc_identity_engine'] = function(module, exports, require, globalThis) {
/* Human Foundation v1 + Complete Three Kingdoms Autonomous NPC Decision Engine (v2.0 Frozen Core).
   Preserves 100% compatibility with v1.0 68-axis identity foundation, seeding, and APIs,
   while exposing the complete 15-domain capability ontology, partial-observation belief system,
   hybrid BDI + Utility + GOAP/HTN decision brain, causal learning/memory, and extension contract. */
(function (root) {
  'use strict';

  const {
    ENGINE_VERSION,
    HUMAN_SCHEMA_VERSION,
    EXTENSION_SCHEMA_VERSION,
    NpcEngineError,
    ERROR_CODES,
    clamp,
    round,
    isObject,
    hash,
    random,
    createRng,
    rollValue
  } = __require('utils');

  const {
    VERSION,
    axisCount,
    VALUE_DIMENSIONS_8,
    PERSONALITY_AXES_14,
    APTITUDE_DOMAINS_6,
    bodyDefs,
    cognitiveDefs,
    interestDefs,
    parts,
    partLabels,
    axisDefinitions,
    raw,
    validate,
    ensure,
    attach: baseAttach,
    getAxis,
    setAxis,
    fingerprint,
    differences,
    getIdentity
  } = __require('identity_core');

  const {
    CAPABILITY_FAMILIES,
    CAPABILITY_DOMAINS,
    resolveCapabilityDomainId,
    getCapabilityDomain,
    listCapabilityDomains
  } = __require('capability_ontology');

  const {
    ensureExtendedConditionState,
    condition,
    effective,
    weighted,
    clarity,
    temperature,
    movement,
    carryLimit,
    load,
    travelSpeed,
    combat,
    damageMultiplier,
    recovery,
    injure,
    recover,
    tick,
    emotions
  } = __require('condition_system');

  const {
    ensureKnowledgeAndTechniqueState,
    getSkillLevel,
    setCapabilityMastery,
    grantKnowledge,
    hasKnowledge,
    getKnowledge,
    learnTechnique,
    hasTechnique,
    evaluateCapabilityDomain,
    inspectAllCapabilities
  } = __require('knowledge_system');

  const {
    ensureBeliefState,
    getEpistemicAcuity,
    observe,
    updateBeliefs,
    getBelief,
    getBeliefSnapshot,
    calibrateSourceTrust
  } = __require('belief_system');

  const {
    DEFAULT_PRIORITY_POLICY,
    ensureGoalAndSocialState,
    setRelationship,
    getRelationship,
    addGoal,
    issueOrder,
    evaluateActiveDrivesAndGoals
  } = __require('goal_system');

  const {
    activities,
    validateActionDefinition,
    registerAction,
    registerActivity,
    descriptor,
    checkActionFeasibility,
    generateCandidates
  } = __require('action_registry');

  const {
    MAX_EPISODIC_MEMORIES,
    MAX_REFLECTIONS,
    MAX_SOCIAL_MEMORIES,
    skill,
    liking,
    capacity,
    workRate,
    learningRate,
    harvestLimit,
    learn,
    remember,
    memoryBias,
    retrieveMemories,
    reportOutcome,
    learnFromOutcome
  } = __require('memory_learning');

  const {
    evaluate,
    option,
    preferenceBias,
    scoreDecisionOptions,
    chooseDecisionOption,
    buildMultiStepPlan,
    checkPlanValidity,
    decide,
    plan,
    submitIntent
  } = __require('decision_engine');

  const {
    communicateBeliefs,
    coordinateGroupRoles,
    negotiateConflictingPlans,
    reactToAllyOutcome
  } = __require('multi_agent');

  const {
    validateSave,
    serialize,
    deserialize,
    assertCanonicalNpcRecord
  } = __require('persistence');

  const {
    inspectNpcDiagnostics,
    getDecisionTraces
  } = __require('diagnostics');

  /**
   * Attaches and initializes an NPC non-destructively (idempotent).
   * Preserves all existing 68-axis values (including 0) and initializes extended state containers.
   */
  function attach(n, seed = 0, options = {}) {
    baseAttach(n, seed, options);
    ensureExtendedConditionState(n);
    ensureKnowledgeAndTechniqueState(n);
    ensureBeliefState(n);
    ensureGoalAndSocialState(n);
    return n;
  }

  /**
   * Applies an archetype or scenario preset to an NPC.
   * Supports the 68 identity axes PLUS optional starting `capabilities`, `knowledge`,
   * `techniques`, `relationships`, `goals`, `readiness`, and `role`.
   */
  function applyPreset(n, preset = {}) {
    if (!isObject(preset)) throw new NpcEngineError(ERROR_CODES.INVALID_NPC, 'Preset must be an object');
    for (const group of ['values', 'personality', 'body', 'cognition', 'aptitudes', 'interests']) {
      const vals = preset[group];
      if (vals === undefined || vals === null) continue;
      if (!isObject(vals)) throw new NpcEngineError(ERROR_CODES.INVALID_AXIS, 'Preset group must be an object: ' + group);
      for (const [id, value] of Object.entries(vals)) {
        setAxis(n, group, id, value);
      }
    }
    if (preset.name !== undefined) n.name = String(preset.name);
    if (preset.role !== undefined) n.role = String(preset.role);
    if (preset.form && isObject(preset.form)) Object.assign(n.core.human.form, preset.form);
    if (preset.state && isObject(preset.state)) {
      const p = preset.state.parts && isObject(preset.state.parts) ? preset.state.parts : {};
      Object.assign(n.core.human.state, preset.state, { parts: { ...n.core.human.state.parts, ...p } });
    }
    if (preset.capabilities && isObject(preset.capabilities)) {
      for (const [domId, lvl] of Object.entries(preset.capabilities)) {
        setCapabilityMastery(n, domId, lvl);
      }
    }
    if (Array.isArray(preset.knowledge)) {
      for (const kRec of preset.knowledge) {
        grantKnowledge(n, typeof kRec === 'string' ? { id: kRec, confidence: 0.9, practiced: true } : kRec);
      }
    }
    if (Array.isArray(preset.techniques)) {
      for (const tDef of preset.techniques) {
        learnTechnique(n, typeof tDef === 'string' ? { id: tDef, proficiency: 75 } : tDef, { force: true });
      }
    }
    if (preset.relationships && isObject(preset.relationships)) {
      for (const [targetId, relPatch] of Object.entries(preset.relationships)) {
        setRelationship(n, targetId, relPatch);
      }
    }
    if (Array.isArray(preset.goals)) {
      for (const gDef of preset.goals) {
        addGoal(n, gDef);
      }
    }
    if (preset.readiness && isObject(preset.readiness)) {
      ensureExtendedConditionState(n);
      Object.assign(n.stageLocal.readiness, preset.readiness);
    }
    return n;
  }

  /**
   * Creates a canonical NPC with deterministic 68-axis foundation and Three Kingdoms state containers.
   */
  function createNpc(options = {}) {
    if (!isObject(options)) throw new NpcEngineError(ERROR_CODES.INVALID_NPC, 'createNpc expects an options object');
    if (options.id === undefined || options.id === null || String(options.id).trim() === '') {
      throw new NpcEngineError(ERROR_CODES.INVALID_ID, 'createNpc requires a stable id');
    }
    const id = String(options.id);
    const seed = options.seed ?? 0;
    const npc = {
      id,
      name: options.name === undefined ? id : String(options.name),
      core: {
        values: { ...(options.values || {}) },
        aptitudes: { ...(options.aptitudes || {}) },
        physiology: { ...(options.physiology || {}) },
        condition: { ...(options.condition || {}) }
      },
      personality: { ...(options.personality || {}) },
      health: options.health ?? 100,
      stageLocal: {
        mode: 'idle',
        action: null,
        lastWork: null,
        danger: 0,
        needs: { hunger: 0, social: 0, safety: 0 },
        memories: []
      }
    };
    if (options.core && isObject(options.core)) {
      for (const k of ['values', 'aptitudes', 'physiology', 'condition']) {
        if (isObject(options.core[k])) Object.assign(npc.core[k], options.core[k]);
      }
      if (options.core.human) npc.core.human = options.core.human;
    }
    if (options.stageLocal && isObject(options.stageLocal)) {
      Object.assign(npc.stageLocal, options.stageLocal);
      npc.stageLocal.needs = {
        hunger: 0,
        social: 0,
        safety: 0,
        ...(isObject(options.stageLocal.needs) ? options.stageLocal.needs : {})
      };
      npc.stageLocal.memories = Array.isArray(options.stageLocal.memories) ? options.stageLocal.memories : [];
    }
    if (Number.isFinite(options.intelligence)) npc.intelligence = options.intelligence;
    if (Number.isFinite(options.planning)) npc.planning = options.planning;

    attach(npc, seed);
    applyPreset(npc, options);
    if (options.form && isObject(options.form)) Object.assign(npc.core.human.form, options.form);
    if (options.state && isObject(options.state)) {
      const p = options.state.parts && isObject(options.state.parts) ? options.state.parts : {};
      Object.assign(npc.core.human.state, options.state, { parts: { ...npc.core.human.state.parts, ...p } });
    }
    validate(npc);
    return npc;
  }

  const api = {
    // Metadata & Versioning
    VERSION,
    ENGINE_VERSION,
    HUMAN_SCHEMA_VERSION,
    EXTENSION_SCHEMA_VERSION,
    NpcEngineError,
    ERROR_CODES,

    // 68-Axis Identity Foundation
    axisCount,
    axisDefinitions,
    bodyDefs,
    cognitiveDefs,
    interestDefs,
    parts,
    partLabels,
    ensure,
    attach,
    createNpc,
    applyPreset,
    getAxis,
    setAxis,
    getIdentity,
    validate,
    raw,
    fingerprint,
    differences,
    createRng,
    hash,
    random,
    rollValue,

    // 15-Domain Capability Ontology & Knowledge/Techniques
    CAPABILITY_FAMILIES,
    CAPABILITY_DOMAINS,
    resolveCapabilityDomainId,
    getCapabilityDomain,
    listCapabilityDomains,
    getSkillLevel,
    setCapabilityMastery,
    grantKnowledge,
    hasKnowledge,
    getKnowledge,
    learnTechnique,
    hasTechnique,
    evaluateCapabilityDomain,
    inspectAllCapabilities,

    // Condition, Readiness & Physical Performance
    effective,
    condition,
    weighted,
    clarity,
    temperature,
    movement,
    travelSpeed,
    combat,
    damageMultiplier,
    recovery,
    workRate,
    learningRate,
    carryLimit,
    load,
    harvestLimit,
    injure,
    recover,
    tick,
    emotions,

    // Partial Observation & Belief State
    observe,
    updateBeliefs,
    getBelief,
    getBeliefSnapshot,
    getEpistemicAcuity,
    calibrateSourceTrust,

    // Goals, Motivations, Relationships & Orders
    DEFAULT_PRIORITY_POLICY,
    setRelationship,
    getRelationship,
    addGoal,
    issueOrder,
    evaluateActiveDrivesAndGoals,

    // Action Registry & Extension Contract
    activities,
    validateActionDefinition,
    registerAction,
    registerActivity,
    descriptor,
    checkActionFeasibility,
    generateCandidates,

    // Unified Hybrid Decision & Bounded Planning Brain
    liking,
    capacity,
    evaluate,
    evaluateOptions: scoreDecisionOptions,
    option,
    scoreDecisionOptions,
    chooseDecisionOption,
    buildMultiStepPlan,
    checkPlanValidity,
    plan,
    decide,
    submitIntent,

    // Memory, Causal Attribution & Learning
    MAX_EPISODIC_MEMORIES,
    MAX_REFLECTIONS,
    MAX_SOCIAL_MEMORIES,
    skill,
    learn,
    train: learn,
    remember,
    memoryBias,
    retrieveMemories,
    reportOutcome,
    learnFromOutcome,

    // Multi-Agent Coordination
    communicateBeliefs,
    coordinateGroupRoles,
    negotiateConflictingPlans,
    reactToAllyOutcome,

    // Persistence, Save Validation & Diagnostics
    validateSave,
    serialize,
    deserialize,
    assertCanonicalNpcRecord,
    inspectNpcDiagnostics,
    getDecisionTraces
  };

  root.HumanCore = api;
  root.NpcIdentityEngine = api;
  root.ThreeKingdomsNpcEngine = api;
  if (typeof module === 'object') module.exports = api;
})(typeof globalThis !== 'undefined' ? globalThis : this);

  };
  __MODULES['three_kingdoms_activities'] = function(module, exports, require, globalThis) {
/* Three Kingdoms activity and extended action definitions. Load after npc-identity-engine.js.
   Preserves all 16 original activities with exact weights while adding comprehensive
   Three Kingdoms domain actions across all 15 capability families. */
(function (root) {
  'use strict';
  const Engine = root.NpcIdentityEngine || (typeof require === 'function' ? __require('npc_identity_engine') : null);
  if (!Engine) throw Error('Load npc-identity-engine.js before the Three Kingdoms activity pack');

  const definitions = [
    // =========================================================================
    // Original 16 Activities (100% Exact Legacy Weights + Extended Preconditions/Effects)
    // =========================================================================
    {
      id: 'rest',
      label: 'พักฟื้น',
      skillDomain: 'recovery',
      capabilityDomain: 'medicine_care',
      effort: 0,
      timeCost: 1,
      risk: 0,
      valueWeights: { familyClan: 0.12, freedom: 0.1 },
      personalityWeights: { discipline: 0.1 },
      bodyWeights: { recoveryRate: 0.7, immuneResilience: 0.3 },
      interestWeights: { tranquility: 0.6 },
      needRelief: { autonomy: 0.25 },
      effects: { recovered: true }
    },
    {
      id: 'train_troops',
      label: 'ฝึกทหาร',
      skillDomain: 'training',
      capabilityDomain: 'command_leadership',
      effort: 45,
      timeCost: 2,
      risk: 8,
      valueWeights: { sectDuty: 0.3, honorLegacy: 0.18, martialPeak: 0.18 },
      personalityWeights: { discipline: 0.35, courage: 0.15, composure: 0.1 },
      bodyWeights: { endurance: 0.35, strength: 0.25, coordination: 0.2, agility: 0.2 },
      cognitiveWeights: { planning: 0.25, attention: 0.25, spatialReasoning: 0.25, workingMemory: 0.25 },
      interestWeights: { practice: 0.4, leadership: 0.35, exertion: 0.25 },
      aptitudeWeights: { command: 0.15, combat: 0.1 },
      needRelief: { competence: 0.7, stimulation: 0.2 },
      effects: { troops_drilled: true }
    },
    {
      id: 'command_army',
      label: 'บัญชาการกองทัพ',
      skillDomain: 'command',
      capabilityDomain: 'command_leadership',
      effort: 75,
      timeCost: 2,
      risk: 0,
      valueWeights: { powerStatus: 0.28, honorLegacy: 0.22, sectDuty: 0.22, wealthResource: -0.1 },
      personalityWeights: { ambition: 0.18, discipline: 0.16, caution: 0.2, rationality: 0.2, courage: 0.12, composure: 0.14 },
      bodyWeights: { endurance: 0.25, senseAcuity: 0.1 },
      cognitiveWeights: { planning: 0.32, spatialReasoning: 0.2, systemsThinking: 0.18, workingMemory: 0.16, metacognition: 0.14 },
      interestWeights: { leadership: 0.32, analysis: 0.24, competition: 0.18, risk: 0.12, expression: 0.14 },
      aptitudeWeights: { command: 0.38, combat: 0.12 },
      needRelief: { competence: 0.6, stimulation: 0.25 },
      effects: { army_deployed: true }
    },
    {
      id: 'duel',
      label: 'ประลองแม่ทัพ',
      skillDomain: 'combat',
      capabilityDomain: 'individual_combat',
      effort: 80,
      timeCost: 1,
      risk: 45,
      valueWeights: { martialPeak: 0.32, honorLegacy: 0.24, powerStatus: 0.16 },
      personalityWeights: { courage: 0.26, aggression: 0.2, pride: 0.18, discipline: 0.14, caution: -0.12 },
      bodyWeights: { strength: 0.2, power: 0.22, agility: 0.2, coordination: 0.16, balance: 0.12, endurance: 0.1 },
      cognitiveWeights: { spatialReasoning: 0.3, processingSpeed: 0.25, attention: 0.2, metacognition: 0.15, workingMemory: 0.1 },
      interestWeights: { competition: 0.4, exertion: 0.22, risk: 0.23, leadership: 0.15 },
      aptitudeWeights: { combat: 0.35, command: 0.08 },
      needRelief: { competence: 0.7, stimulation: 0.45 },
      effects: { enemy_champion_challenged: true }
    },
    {
      id: 'ambush',
      label: '伏擊／設伏',
      skillDomain: 'tactics',
      capabilityDomain: 'land_warfare',
      effort: 65,
      timeCost: 2,
      risk: 28,
      valueWeights: { powerStatus: 0.16, martialPeak: 0.18, wealthResource: 0.12, honorLegacy: 0.08 },
      personalityWeights: { caution: 0.28, rationality: 0.2, creativity: 0.16, aggression: 0.12, discipline: 0.16, integrity: -0.08 },
      bodyWeights: { agility: 0.25, senseAcuity: 0.25, balance: 0.15, mobility: 0.2, endurance: 0.15 },
      cognitiveWeights: { planning: 0.25, spatialReasoning: 0.25, metacognition: 0.2, workingMemory: 0.15, attention: 0.15 },
      interestWeights: { analysis: 0.3, exploration: 0.22, risk: 0.25, nature: 0.13, competition: 0.1 },
      aptitudeWeights: { command: 0.2, combat: 0.18 },
      needRelief: { competence: 0.5, stimulation: 0.3 },
      effects: { ambush_sprung: true }
    },
    {
      id: 'siege',
      label: '攻城與ล้อมเมือง',
      skillDomain: 'siegecraft',
      capabilityDomain: 'siege_engineering',
      effort: 85,
      timeCost: 3,
      risk: 35,
      valueWeights: { powerStatus: 0.22, sectDuty: 0.16, wealthResource: 0.2, honorLegacy: 0.12 },
      personalityWeights: { discipline: 0.2, rationality: 0.22, caution: 0.18, ambition: 0.14, composure: 0.16 },
      bodyWeights: { strength: 0.18, endurance: 0.32, coordination: 0.15 },
      cognitiveWeights: { planning: 0.28, systemsThinking: 0.24, numeracy: 0.16, spatialReasoning: 0.18, workingMemory: 0.14 },
      interestWeights: { leadership: 0.25, analysis: 0.3, creation: 0.12, exertion: 0.12, practice: 0.21 },
      aptitudeWeights: { command: 0.3, crafting: 0.12 },
      needRelief: { competence: 0.55 },
      effects: { city_besieged: true }
    },
    {
      id: 'defend_city',
      label: 'ป้องกันเมือง',
      skillDomain: 'defense',
      capabilityDomain: 'land_warfare',
      effort: 70,
      timeCost: 2,
      risk: 25,
      valueWeights: { familyClan: 0.24, sectDuty: 0.28, honorLegacy: 0.2, powerStatus: 0.08 },
      personalityWeights: { loyalty: 0.2, integrity: 0.16, empathy: 0.14, courage: 0.2, discipline: 0.16, composure: 0.14 },
      bodyWeights: { durability: 0.22, endurance: 0.3, balance: 0.16, strength: 0.16, agility: 0.16 },
      cognitiveWeights: { planning: 0.24, spatialReasoning: 0.22, socialInsight: 0.18, workingMemory: 0.18, attention: 0.18 },
      interestWeights: { care: 0.25, leadership: 0.28, competition: 0.16, companionship: 0.14, practice: 0.17 },
      aptitudeWeights: { command: 0.24, combat: 0.2 },
      needRelief: { competence: 0.5, social: 0.25 },
      effects: { city_defended: true, dependents_safe: true }
    },
    {
      id: 'diplomacy',
      label: 'เจรจาทางการทูต',
      skillDomain: 'diplomacy',
      capabilityDomain: 'diplomacy_politics',
      effort: 35,
      timeCost: 2,
      risk: 10,
      valueWeights: { sectDuty: 0.18, familyClan: 0.12, wealthResource: 0.16, powerStatus: 0.14, honorLegacy: 0.14, freedom: 0.1 },
      personalityWeights: { empathy: 0.18, trustfulness: 0.12, integrity: 0.16, rationality: 0.2, composure: 0.16, creativity: 0.1, caution: 0.08 },
      cognitiveWeights: { socialInsight: 0.28, verbalComprehension: 0.26, planning: 0.18, metacognition: 0.14, workingMemory: 0.14 },
      interestWeights: { companionship: 0.2, expression: 0.22, exchange: 0.22, analysis: 0.2, leadership: 0.16 },
      aptitudeWeights: { socialCommerce: 0.32, command: 0.08 },
      needRelief: { autonomy: 0.35, social: 0.35, competence: 0.2 },
      effects: { diplomatic_channel_opened: true }
    },
    {
      id: 'govern_city',
      label: 'บริหารเมือง',
      skillDomain: 'governance',
      capabilityDomain: 'civil_administration',
      effort: 55,
      timeCost: 2,
      risk: 10,
      valueWeights: { sectDuty: 0.24, familyClan: 0.16, wealthResource: 0.22, honorLegacy: 0.18, powerStatus: 0.08 },
      personalityWeights: { integrity: 0.2, discipline: 0.16, empathy: 0.14, rationality: 0.18, caution: 0.12, composure: 0.1, ambition: 0.1 },
      cognitiveWeights: { planning: 0.22, numeracy: 0.18, systemsThinking: 0.2, socialInsight: 0.18, verbalComprehension: 0.12, metacognition: 0.1 },
      interestWeights: { leadership: 0.25, care: 0.2, analysis: 0.2, exchange: 0.16, companionship: 0.1, creation: 0.09 },
      aptitudeWeights: { command: 0.18, socialCommerce: 0.2 },
      needRelief: { competence: 0.45, social: 0.2 },
      effects: { city_governed: true }
    },
    {
      id: 'intrigue',
      label: 'วางแผนข่าวกรองและกลอุบาย',
      skillDomain: 'intrigue',
      capabilityDomain: 'intelligence_deception',
      effort: 60,
      timeCost: 2,
      risk: 28,
      valueWeights: { powerStatus: 0.24, freedom: 0.12, wealthResource: 0.12, honorLegacy: 0.06, sectDuty: 0.08 },
      personalityWeights: { caution: 0.24, rationality: 0.22, creativity: 0.16, trustfulness: -0.16, integrity: -0.12, composure: 0.12, ambition: 0.12 },
      cognitiveWeights: { socialInsight: 0.22, workingMemory: 0.18, metacognition: 0.18, planning: 0.2, attention: 0.12, systemsThinking: 0.1 },
      interestWeights: { analysis: 0.32, risk: 0.2, exploration: 0.18, expression: 0.1, exchange: 0.1, tranquility: 0.1 },
      aptitudeWeights: { command: 0.14, socialCommerce: 0.2 },
      needRelief: { stimulation: 0.25, competence: 0.45 },
      effects: { enemy_disrupted: true }
    },
    {
      id: 'recruit',
      label: 'เกลี้ยกล่อมรับสมัครขุนพล',
      skillDomain: 'recruitment',
      capabilityDomain: 'command_leadership',
      effort: 30,
      timeCost: 1,
      risk: 8,
      valueWeights: { honorLegacy: 0.22, sectDuty: 0.16, familyClan: 0.1, powerStatus: 0.16, wealthResource: 0.08 },
      personalityWeights: { empathy: 0.18, trustfulness: 0.16, integrity: 0.12, ambition: 0.12, composure: 0.12, creativity: 0.1, loyalty: 0.1 },
      cognitiveWeights: { socialInsight: 0.28, verbalComprehension: 0.24, planning: 0.16, metacognition: 0.16, workingMemory: 0.16 },
      interestWeights: { companionship: 0.2, leadership: 0.25, expression: 0.2, exchange: 0.1, care: 0.1, competition: 0.15 },
      aptitudeWeights: { socialCommerce: 0.28, command: 0.12 },
      needRelief: { social: 0.35, competence: 0.3 },
      effects: { officers_recruited: true }
    },
    {
      id: 'logistics',
      label: 'จัดเสบียงและเส้นทางลำเลียง',
      skillDomain: 'logistics',
      capabilityDomain: 'logistics_sustainment',
      effort: 50,
      timeCost: 2,
      risk: 12,
      valueWeights: { wealthResource: 0.26, sectDuty: 0.28, familyClan: 0.1, honorLegacy: 0.12 },
      personalityWeights: { discipline: 0.24, caution: 0.18, rationality: 0.2, integrity: 0.14, composure: 0.12, ambition: 0.06 },
      bodyWeights: { endurance: 0.28, strength: 0.16, senseAcuity: 0.12 },
      cognitiveWeights: { numeracy: 0.26, planning: 0.26, systemsThinking: 0.2, workingMemory: 0.14, spatialReasoning: 0.14 },
      interestWeights: { analysis: 0.22, leadership: 0.14, exchange: 0.22, practice: 0.16, exploration: 0.12, care: 0.14 },
      aptitudeWeights: { command: 0.16, socialCommerce: 0.1, crafting: 0.08 },
      needRelief: { competence: 0.4 },
      effects: { supplies_secured: true }
    },
    {
      id: 'scout',
      label: 'ลาดตระเวน',
      skillDomain: 'scouting',
      capabilityDomain: 'intelligence_deception',
      effort: 40,
      timeCost: 1,
      risk: 20,
      valueWeights: { freedom: 0.2, sectDuty: 0.16, knowledgeCraft: 0.12, familyClan: -0.08 },
      personalityWeights: { caution: 0.22, curiosity: 0.2, courage: 0.12, composure: 0.14, rationality: 0.12 },
      bodyWeights: { senseAcuity: 0.28, agility: 0.2, balance: 0.16, mobility: 0.2, endurance: 0.16 },
      cognitiveWeights: { spatialReasoning: 0.28, attention: 0.2, planning: 0.18, metacognition: 0.18, workingMemory: 0.16 },
      interestWeights: { exploration: 0.35, nature: 0.2, risk: 0.18, analysis: 0.17, tranquility: 0.1 },
      aptitudeWeights: { combat: 0.1, command: 0.08 },
      needRelief: { stimulation: 0.3, autonomy: 0.2 },
      effects: { terrain_scouted: true, enemy_located: true }
    },
    {
      id: 'patrol',
      label: 'ลาดตระเวนรักษาความสงบ',
      skillDomain: 'patrol',
      capabilityDomain: 'command_leadership',
      effort: 35,
      timeCost: 1,
      risk: 15,
      valueWeights: { sectDuty: 0.28, familyClan: 0.16, honorLegacy: 0.16 },
      personalityWeights: { discipline: 0.2, caution: 0.2, empathy: 0.12, integrity: 0.16, courage: 0.12, composure: 0.12 },
      bodyWeights: { endurance: 0.28, senseAcuity: 0.18, agility: 0.18, durability: 0.18, balance: 0.18 },
      cognitiveWeights: { attention: 0.22, socialInsight: 0.2, planning: 0.2, spatialReasoning: 0.2, metacognition: 0.16 },
      interestWeights: { care: 0.2, leadership: 0.2, companionship: 0.18, practice: 0.16, exploration: 0.12, exertion: 0.14 },
      aptitudeWeights: { command: 0.12, combat: 0.12 },
      needRelief: { competence: 0.25, social: 0.15 },
      effects: { perimeter_secured: true }
    },
    {
      id: 'research_strategy',
      label: 'ศึกษาตำราพิชัยสงคราม',
      skillDomain: 'strategy',
      capabilityDomain: 'strategy_doctrine',
      effort: 40,
      timeCost: 2,
      risk: 5,
      valueWeights: { knowledgeCraft: 0.3, honorLegacy: 0.16, powerStatus: 0.12, sectDuty: 0.14 },
      personalityWeights: { curiosity: 0.22, rationality: 0.22, discipline: 0.18, creativity: 0.14, caution: 0.12, composure: 0.12 },
      cognitiveWeights: { systemsThinking: 0.24, planning: 0.2, reasoning: 0.18, workingMemory: 0.14, spatialReasoning: 0.14, verbalComprehension: 0.1 },
      interestWeights: { analysis: 0.36, practice: 0.2, creation: 0.16, tranquility: 0.12, leadership: 0.16 },
      aptitudeWeights: { command: 0.28, comprehension: 0.12 },
      needRelief: { competence: 0.5 },
      effects: { doctrine_prepared: true }
    },
    {
      id: 'trade',
      label: 'ค้าขายและจัดซื้อ',
      skillDomain: 'trade',
      capabilityDomain: 'civil_administration',
      effort: 30,
      timeCost: 1,
      risk: 8,
      valueWeights: { wealthResource: 0.32, familyClan: 0.1, sectDuty: 0.08, freedom: 0.16 },
      personalityWeights: { rationality: 0.18, integrity: 0.14, creativity: 0.1, caution: 0.14, trustfulness: 0.08 },
      cognitiveWeights: { numeracy: 0.26, planning: 0.18, socialInsight: 0.2, verbalComprehension: 0.18, systemsThinking: 0.18 },
      interestWeights: { exchange: 0.38, exploration: 0.16, analysis: 0.16, companionship: 0.12, creation: 0.1, risk: 0.08 },
      aptitudeWeights: { socialCommerce: 0.3 },
      needRelief: { autonomy: 0.2, competence: 0.2 },
      effects: { treasury_replenished: true }
    },

    // =========================================================================
    // Extended Three Kingdoms Domain Actions Across All 15 Capability Families
    // =========================================================================
    {
      id: 'fighting_retreat',
      label: 'ถอยทัพเชิงยุทธวิธี (Fighting Withdrawal)',
      skillDomain: 'land_warfare',
      capabilityDomain: 'land_warfare',
      effort: 55,
      timeCost: 1,
      risk: 20,
      requiredCapabilities: { land_warfare: 10 },
      effects: { safe_withdrawal: true, flank_stabilized: true },
      needRelief: { autonomy: 0.15, competence: 0.3 }
    },
    {
      id: 'rally_wavering_troops',
      label: 'ปลุกขวัญและจัดระเบียบกองทัพ (Rally Wavering Troops)',
      skillDomain: 'command_leadership',
      capabilityDomain: 'command_leadership',
      effort: 50,
      timeCost: 1,
      risk: 22,
      requiredCapabilities: { command_leadership: 15 },
      effects: { morale_restored: true, flank_stabilized: true },
      needRelief: { competence: 0.5 }
    },
    {
      id: 'construct_siege_engines',
      label: 'สร้างเครื่องจักรตีเมือง (Construct Siege Engines)',
      skillDomain: 'siege_engineering',
      capabilityDomain: 'siege_engineering',
      effort: 70,
      timeCost: 2,
      risk: 15,
      requiredCapabilities: { siege_engineering: 20 },
      requiredResources: { timber: 10 },
      effects: { siege_engines_ready: true },
      needRelief: { competence: 0.5 }
    },
    {
      id: 'treat_battle_wounds',
      label: 'รักษาผู้บาดเจ็บและควบคุมโรคระบาด (Treat Battle Wounds & Triage)',
      skillDomain: 'medicine_care',
      capabilityDomain: 'medicine_care',
      effort: 45,
      timeCost: 1,
      risk: 8,
      requiredCapabilities: { medicine_care: 15 },
      effects: { ally_treated: true, recovered: true },
      needRelief: { competence: 0.45, social: 0.25 }
    },
    {
      id: 'forge_weapons_and_armor',
      label: 'หลอมตีอาวุธและซ่อมชุดเกราะ (Forge Weapons & Armor)',
      skillDomain: 'craft_production',
      capabilityDomain: 'craft_production',
      effort: 60,
      timeCost: 2,
      risk: 10,
      requiredCapabilities: { craft_production: 20 },
      effects: { equipment_upgraded: true },
      needRelief: { competence: 0.55 }
    },
    {
      id: 'compile_regional_map',
      label: 'จัดทำแผนที่ยุทธศาสตร์และพยากรณ์อากาศ (Compile Cartography & Forecast)',
      skillDomain: 'scholarship_planning',
      capabilityDomain: 'scholarship_planning',
      effort: 35,
      timeCost: 1,
      risk: 5,
      requiredCapabilities: { scholarship_planning: 20 },
      effects: { regional_map_compiled: true },
      needRelief: { competence: 0.4 }
    },
    {
      id: 'guide_mountain_march',
      label: 'นำทัพเดินผ่านทางแคบและหาแหล่งน้ำ (Guide Terrain March & Survival)',
      skillDomain: 'travel_survival',
      capabilityDomain: 'travel_survival',
      effort: 55,
      timeCost: 2,
      risk: 22,
      requiredCapabilities: { travel_survival: 20 },
      effects: { mountain_pass_crossed: true },
      needRelief: { autonomy: 0.25, stimulation: 0.25 }
    },
    {
      id: 'forage_and_secure_water',
      label: 'หาเสบียงเสริมและแหล่งน้ำสะอาด (Forage & Secure Water)',
      skillDomain: 'travel_survival',
      capabilityDomain: 'travel_survival',
      effort: 45,
      timeCost: 1,
      risk: 15,
      effects: { supplies_secured: true },
      needRelief: { autonomy: 0.2, competence: 0.25 }
    },
    {
      id: 'mentor_junior_officer',
      label: 'ชี้แนะและถ่ายทอดวิชาแก่ขุนพลรุ่นเยาว์ (Mentor Junior Officer)',
      skillDomain: 'social_household',
      capabilityDomain: 'social_household',
      effort: 30,
      timeCost: 1,
      risk: 5,
      requiredCapabilities: { social_household: 15 },
      effects: { junior_mentored: true },
      needRelief: { social: 0.4, competence: 0.35 }
    }
  ];

  for (const def of definitions) Engine.registerActivity(def);

  const api = {
    definitions,
    ids: definitions.map(d => d.id),
    get(id) {
      return definitions.find(d => d.id === id) || null;
    }
  };
  root.ThreeKingdomsNpcActivities = api;
  if (typeof module === 'object') module.exports = api;
})(typeof globalThis !== 'undefined' ? globalThis : this);

  };
  globalScope.NpcIdentityEngine = __require('npc_identity_engine');
  globalScope.ThreeKingdomsNpcEngine = globalScope.NpcIdentityEngine;
  __require('three_kingdoms_activities');
  if(typeof module !== 'undefined' && module.exports) module.exports = globalScope.NpcIdentityEngine;
})(typeof window !== 'undefined' ? window : globalThis);
