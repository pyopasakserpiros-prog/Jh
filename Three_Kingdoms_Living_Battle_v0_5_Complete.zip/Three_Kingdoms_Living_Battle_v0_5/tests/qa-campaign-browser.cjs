'use strict';
const {chromium}=require('playwright'),A=require('node:assert/strict'),path=require('node:path'),fs=require('node:fs');
(async()=>{
 const width=Number(process.env.QA_WIDTH||393),side=process.env.QA_SIDE||'shu',errors=[],remote=[];
 const browser=await chromium.launch({headless:true,executablePath:process.env.BROWSER_EXECUTABLE,args:['--no-sandbox','--disable-dev-shm-usage','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
 const page=await browser.newPage({viewport:{width,height:width<600?851:1050},isMobile:width<600,hasTouch:width<600,acceptDownloads:true});
 page.on('pageerror',e=>errors.push(e.message));page.on('request',r=>{if(/^https?:/.test(r.url()))remote.push(r.url());});
 await page.goto('file://'+path.resolve(__dirname,'../Three_Kingdoms_Living_Battle_v0_5.html'));await page.evaluate(()=>document.fonts.ready);
 await page.click('[data-action="scenario"][data-value="hanzhong"]');if(process.env.QA_SHOTS&&width===1440)await page.screenshot({path:path.join(process.env.QA_SHOTS,'stage-final-1440.png'),fullPage:true});await page.click('[data-action="nextstep"]');await page.click('[data-action="side"][data-value="'+side+'"]');await page.click('[data-action="nextstep"]');
 await page.fill('#cardSearch',side==='shu'?'เล่าปี่':'โจโฉ');A.equal(await page.locator('.officer-card').count(),1);await page.fill('#cardSearch','');await page.click('[data-action="nextstep"]');
 A.ok((await page.locator('body').innerText()).includes('ทัพฝ่ายตรงข้าม'));A.ok(await page.locator('#pressureInput').isDisabled());await page.selectOption('#yearsInput','5');
 await page.click('[data-action="launch"]');await page.evaluate(()=>BattleApp.pause());A.equal(await page.evaluate(()=>BattleApp.state.sim.durationDays),1825);A.equal(await page.evaluate(()=>BattleApp.state.sim.units.length),80);
 // Verify the actual detachment dialog before armies begin moving.
 await page.locator('[data-action="battletab"][data-value="army"]').first().click();
 const parentId=await page.evaluate(()=>BattleApp.state.sim.units.find(u=>u.side===BattleApp.state.side&&u.troops>=2000).id);
 await page.locator('[data-action="unitdetail"][data-id="'+parentId+'"]').click();A.ok((await page.locator('.modal').innerText()).includes('เครื่องมือ 80 หน่วย'));await page.fill('#splitCount','750');await page.click('[data-action="split"]');A.equal(await page.evaluate(()=>BattleApp.state.sim.units.filter(u=>u.troops>0).length),81);await page.click('[data-action="merge"]');A.equal(await page.evaluate(()=>BattleApp.state.sim.units.filter(u=>u.troops>0).length),80);
 await page.locator('[data-action="battletab"][data-value="map"]').first().click();
 const t=await page.evaluate(()=>BattleApp.state.sim.time);await page.click('[data-action="step30"]');A.equal(await page.evaluate(()=>BattleApp.state.sim.time),t+30);A.ok((await page.locator('.clock-time').innerText()).includes('วัน'));
 await page.evaluate(()=>{LivingBattle.step(BattleApp.state.sim,60);BattleApp.refresh();});
 const navigate=async name=>{await page.locator('[data-action="battletab"][data-value="'+name+'"]').first().click();A.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false,'overflow '+name);};
 if(process.env.QA_SHOTS){fs.mkdirSync(process.env.QA_SHOTS,{recursive:true});await page.screenshot({path:path.join(process.env.QA_SHOTS,'hanzhong-'+side+'-'+width+'.png'),fullPage:true});}
 await navigate('overview');A.ok(await page.locator('tbody tr').count()>=3);await navigate('npcs');await page.selectOption('#npcSide','enemy');A.equal(await page.evaluate(()=>BattleApp.state.npcSide),'enemy');
 const id=await page.evaluate(()=>Object.values(BattleApp.state.sim.npcs).find(n=>n.side===BattleApp.state.sim.opponent&&LivingBattle.card(n.id).fictional).id);
 await page.evaluate(id=>BattleApp.inspect(id),id);await page.click('[data-action="npctab"][data-value="history"]');A.ok((await page.locator('.modal').innerText()).includes('สมมุติ'));await page.keyboard.press('Escape');
 await navigate('reports');await page.selectOption('#reportSide','enemy');await page.selectOption('#reportFilter','decision');A.ok(await page.locator('.event-row').count()>0);await page.selectOption('#reportFilter','monthly');A.ok(await page.locator('.event-row').count()>=3);
 const downloadPromise=page.waitForEvent('download');await page.click('[data-action="export"]');const download=await downloadPromise;const output=await download.path();const data=JSON.parse(fs.readFileSync(output,'utf8'));A.equal(data.elapsed.unit,'days');A.equal(data.elapsed.value,data.timeDays);A.equal(data.timeMinutes,data.timeDays*1440);A.equal(data.campaignLedger.durationDays,1825);A.ok(data.monthlyReports.length>=3);A.ok(data.events.length>600);
 await navigate('sources');A.ok((await page.locator('body').innerText()).includes('นายกองสมมุติ'));await navigate('army');await navigate('map');
 A.deepEqual(errors,[]);A.deepEqual(remote,[]);console.log(JSON.stringify({viewport:width,side,units:80,years:5,errors,remoteRequests:remote.length,result:'PASS: wizard, daily steps, monthly reports, detachment controls, enemy observer, fictional biography, export and all tabs'},null,2));process.exit(0);
})().catch(e=>{console.error(e);process.exit(1)});
