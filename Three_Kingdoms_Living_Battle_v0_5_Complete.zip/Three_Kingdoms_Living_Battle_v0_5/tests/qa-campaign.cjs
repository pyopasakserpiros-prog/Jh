'use strict';
const A=require('node:assert/strict'),C=require('../src/battle-core'),D=C.D,fs=require('node:fs');let groups=0;
const rationTotal=s=>s.units.reduce((v,u)=>v+u.rations,0)+s.nodes.reduce((v,n)=>v+n.stock,0)+s.camps.reduce((v,c)=>v+c.stock,0)+s.convoys.reduce((v,c)=>v+c.cargo,0);
function test(name,fn){fn();groups++;console.log('PASS '+name);}
function check(s,initialFood){for(const side of['shu','wei']){const force=s.units.filter(u=>u.side===side).reduce((v,u)=>v+u.troops,0);A.equal(force+s.metrics.losses[side],s.initialTotals[side]+s.metrics.recruited[side]);A.equal(s.manpower[side]+s.metrics.recruited[side],s.initialManpower[side]);}for(const u of s.units){for(const k of['x','y','rations','troops','wounded','fatigue','morale'])A.ok(Number.isFinite(u[k])&&u[k]>=-1e-7,u.id+' '+k);A.ok(u.wounded<=u.troops);}const food=rationTotal(s)+s.metrics.rationsConsumed+s.metrics.rationsLost-initialFood-s.metrics.rationsProduced;A.ok(Math.abs(food)<.03,'ration ledger difference '+food);}
const assignment=side=>Object.fromEntries(D.SCENARIOS.hanzhong.roles.map((r,i)=>[r.id,D.HISTORICAL.hanzhong[side][i]]));
let shu,wei,food,mirrorFood;
test('historical initial commanders, 80 active units, and unmodified enemy strength',()=>{
 shu=C.createSimulation({scenario:'hanzhong',side:'shu',assign:assignment('shu'),reserves:[],seed:217,pressure:.45});wei=C.createSimulation({scenario:'hanzhong',side:'wei',assign:assignment('wei'),reserves:[],seed:217,pressure:1.3});
 A.equal(shu.units.length,80);A.equal(wei.units.length,80);A.deepEqual(shu.initialTotals,wei.initialTotals);A.equal(shu.pressure,1);A.equal(wei.pressure,1);A.equal(shu.units.find(u=>u.commanderId==='xiahou_yuan').nodeId,'yangping');A.equal(shu.units.find(u=>u.commanderId==='zhang_he').nodeId,'guangshi');A.equal(shu.units.find(u=>u.commanderId==='xu_huang').nodeId,'maming');A.equal(shu.units.find(u=>u.commanderId==='cao_cao').nodeId,'ye');A.equal(shu.units.find(u=>u.commanderId==='zhuge_liang').nodeId,'chengdu');food=rationTotal(shu);mirrorFood=rationTotal(wei);
});
test('drafting an enemy officer is rejected before simulation creation',()=>{const a=assignment('shu');a.supreme='cao_cao';A.throws(()=>C.createSimulation({scenario:'hanzhong',side:'shu',assign:a,reserves:[],mode:'free'}),/ฝ่ายตรงข้าม/);});
test('two years of real decisions preserve food, troops, and finite replacement pools',()=>{
 while(shu.status!=='completed'){C.step(shu,30);check(shu,food);}A.equal(shu.time,730);A.equal(shu.monthlyReports.length,24);A.ok(shu.metrics.decisions.shu>1000&&shu.metrics.decisions.wei>1000);A.ok(shu.metrics.convoysDelivered>0);A.ok(shu.metrics.convoysLost>0);A.ok(shu.metrics.campBuilt>0);for(const s of['shu','wei']){A.ok(shu.metrics.trainingDays[s]>0);A.ok(shu.metrics.patrolDays[s]>0);A.ok(shu.metrics.restDays[s]>0);}A.ok(shu.eventArchive.length>600);A.ok(shu.events.length<=600);
});
test('switching which historical side is called the player leaves the complete simulation unchanged',()=>{
 while(wei.status!=='completed'){C.step(wei,30);check(wei,mirrorFood);}const world=s=>JSON.stringify({units:s.units,nodes:s.nodes,camps:s.camps,convoys:s.convoys,weather:s.weather,metrics:s.metrics,manpower:s.manpower,events:s.eventArchive});A.equal(world(shu),world(wei));A.equal(shu.outcome.winner,wei.outcome.winner);
});
test('a five-year observation reaches day 1825 without a hard-coded historical ending',()=>{
 const s=C.createSimulation({scenario:'hanzhong',side:'wei',years:5,seed:49});const initial=rationTotal(s);while(s.status!=='completed'){C.step(s,60);check(s,initial);}A.equal(s.time,1825);A.equal(s.monthlyReports.length,60);A.ok(C.clock(s).text.includes('222'));A.ok(s.metrics.decisions.shu>0&&s.metrics.decisions.wei>0);
});
test('detachments transfer wounded, tools and authorized strength, merge them back, and remain finite in a long campaign',()=>{
 const s=C.createSimulation({scenario:'hanzhong',side:'shu',seed:217}),p=s.units.find(u=>u.side==='shu'&&u.troops>=2000),officer=C.freeOfficers(s,'shu')[0];p.wounded=120;
 const old={troops:p.troops,rations:p.rations,wounded:p.wounded,materials:p.materials,initial:p.initialTroops},initialFood=rationTotal(s),d=C.splitUnit(s,p,750,officer);A.ok(d);
 for(const key of['troops','rations','wounded','materials'])A.ok(Math.abs(p[key]+d[key]-old[key])<.0001,key+' conservation');A.ok(Math.abs(p.initialTroops+d.initialTroops-old.initial)<.0001);A.ok(d.wounded<=d.troops);A.equal(d.duty,'infantry');
 A.ok(C.mergeUnit(s,d));for(const key of['troops','rations','wounded','materials'])A.ok(Math.abs(p[key]-old[key])<.0001,key+' merge');A.ok(Math.abs(p.initialTroops-old.initial)<.0001);
 const split=C.splitUnit(s,p,750,officer);A.ok(split);C.step(s,120);check(s,initialFood);
 const builder=s.units.find(u=>u.troops>0);builder.status='engaged';A.equal(C.constructCamp(s,builder),false);
});
test('the supplied NPC runtime is byte-identical to v0.2',()=>{
 const path=require('node:path'),crypto=require('node:crypto'),hash=p=>crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');A.equal(hash(path.resolve(__dirname,'../src/npc-runtime.js')),fs.readFileSync(path.resolve(__dirname,'../docs/NPC_RUNTIME_SHA256.txt'),'utf8').trim());
});
console.log(groups+' long-campaign groups passed.');
