(function(root){'use strict';
const C=root.LivingBattle||(typeof require==='function'?require('./battle-core'):null),D=C.D,E=C.E;
const clamp=(x,a=0,b=100)=>Math.max(a,Math.min(b,x)),clone=x=>JSON.parse(JSON.stringify(x)),round=x=>Math.round(x*100)/100;
const SIDE_IDS=['shu','wei'],sideIds=sim=>sim.sideIds||SIDE_IDS,KIND=['patrol','supply','engineer','training','medical','administration','infantry','reserve'];
const DUTY={patrol:'ลาดตระเวน',supply:'ลำเลียง',engineer:'ช่างค่าย',training:'ฝึกกำลัง',medical:'พักฟื้น',administration:'กิจการคลัง',infantry:'รักษาทาง',reserve:'กำลังหนุน'};
const ACT=[
 ['fire_raid','โจมตีแนวค่ายด้วยไฟ','siege_engineering',{creativity:.8,courage:.5,caution:.3}],
 ['advance','เคลื่อนรุกและรวมกำลัง','land_warfare',{ambition:.5,courage:.6,aggression:.8,caution:-.4}],
 ['fortify','ตั้งค่ายและเสริมแนว','siege_engineering',{discipline:.8,caution:.7}],
 ['supply','จัดเสบียงและคลังหน้า','logistics_sustainment',{discipline:.9,rationality:.8}],
 ['patrol','ลาดตระเวนเส้นทาง','intelligence_deception',{caution:.8,curiosity:.8}],
 ['train','ฝึกและรับกำลังทดแทน','command_leadership',{discipline:.9,ambition:.3}],
 ['rest','พักฟื้นและรักษากำลัง','medicine_care',{empathy:.7,caution:.7,aggression:-.5}],
 ['raid','เข้าตีโอบและตัดทางลำเลียง','strategy_doctrine',{creativity:.8,courage:.7,aggression:.5}],
 ['guard','รักษาจุดยุทธศาสตร์','command_leadership',{loyalty:.8,discipline:.7,caution:.5}]
];
for(const[id,label,domain,p]of ACT)if(!E.activities['hz_'+id])E.registerAction({id:'hz_'+id,label,version:'1.0.0',category:domain,skillDomain:domain,capabilityDomain:domain,effort:30,risk:['advance','raid'].includes(id)?45:15,timeCost:5,personalityWeights:p,valueWeights:{sectDuty:.6},effects:{['hz_'+id]:true}});
function auxiliaryCard(side,i,scenario='hanzhong'){
 const id=(scenario==='hanzhong'?'hz':scenario==='yiling'?'yl':'jz')+'_'+side+'_staff_'+i;let old=C.card(id);if(old)return old;
 const names=['เฉิน','จาง','หลี่','หวัง','หวง','หลิว','โจว','ซุน'],given=['จิ้ง','หมิง','จง','เหวิน','อัน','จวิน','ผิง','อี้'];
 const duty=KIND[i%KIND.length],base=C.card(side==='shu'?'liao_hua':side==='wu'?'lu_xun':'li_dian'),c=clone(base),rng=E.createRng(217, id);
 c.id=id;c.name=c.nameTh='นายกอง'+names[i%8]+given[Math.floor(i/8)]+' '+(side==='shu'?'ฝ่ายเล่า':side==='wu'?'ฝ่ายง่อ':'ฝ่ายโจ');c.en='Staff officer '+side+' '+(i+1);c.seal=side==='shu'?'劉':side==='wu'?'吳':'曹';c.faction=c.factionCode=side;c.draftable=false;c.fictional=true;c.confidence='สมมุติ';c.active=D.SCENARIOS[scenario].year;c.death=9999;c.bio='นายทหารสมมุติสำหรับจำลองงาน'+DUTY[duty]+' มีตัวตนและใช้กติกาเดียวกับขุนพลหลัก';c.evidence='ไม่มีข้ออ้างว่าเป็นบุคคลในจดหมายเหตุ สร้างเพื่อให้เห็นงานเบื้องหลังของกองทัพและภาระการตัดสินใจ';c.source=null;c.sourceId=null;c.vol=null;
 for(const [key]of Object.entries(c.stats))c.stats[key]=40+Math.floor(rng.next()*27);
 for(const key of Object.keys(c.preset.personality))c.preset.personality[key]=30+Math.floor(rng.next()*52);
 c.preset.aptitudes.command=c.stats.command;c.preset.aptitudes.combat=c.stats.martial;
 for(const key of Object.keys(c.preset.capabilities))c.preset.capabilities[key]=35+Math.floor(rng.next()*30);
 D.CARDS.push(c);return c;
}
function addNpc(sim,id,side,role){const card=C.card(id),n=E.createNpc({id,seed:sim.seed,name:card.name});E.applyPreset(n,card.preset);n.side=side;n.role=role;sim.npcs[id]=n;return n;}
function unit(sim,id,side,commanderId,role,duty,nodeId,troops){
 const n=sim.nodes.find(n=>n.id===nodeId),cavalry=['ma_chao','xu_huang','pang_de','zhang_liao','cao_xiu'].includes(commanderId),u={id,side,commanderId,role,duty,name:D.SCENARIOS[sim.scenario].roles.find(r=>r.id===role)?.name||DUTY[duty]||'หน่วยแยก',type:duty==='patrol'?'scout':duty==='engineer'?'engineer':duty==='supply'||duty==='medical'?'support':role==='naval'&&sim.scenario!=='hanzhong'&&sim.edges.some(e=>e.terrain==='water'&&(e.from===nodeId||e.to===nodeId))?'naval':cavalry?'cavalry':role==='left'||role==='right'?'archers':'infantry',troops,initialTroops:troops,nodeId,x:n.x,y:n.y,route:[],edgeProgress:0,target:null,status:'holding',order:'จัดกำลังและสำรวจเส้นทาง',morale:78,cohesion:76,fatigue:8,rations:troops*38,ammo:100,sick:0,materials:200,training:55,wounded:0,burning:0,parentId:null,isDetachment:false,decision:null,lastDecision:-999,taskUntil:0,task:null,retreating:false,recoverUntil:0,buildCamp:null};sim.units.push(u);return u;
}
function createSimulation({scenario='hanzhong',side='shu',assign=null,reserves=[],seed=217,mode='free',doctrine='balanced',years=null}={}){
 const spec=D.SCENARIOS[scenario],cfg=D.CAMPAIGNS[scenario],SIDES=spec.sides.map(s=>s.id),bySide=value=>Object.fromEntries(SIDES.map(s=>[s,typeof value==='function'?value():value]));
 if(!SIDES.includes(side))throw new Error('ฝ่ายในแคมเปญฮันต๋งไม่ถูกต้อง');
 if(!assign){const a=C.autoRoster(scenario,side,mode==='free'?'era':mode,{},4);assign=a.assign;reserves=a.reserves;}
 C.validateRoster(scenario,side,assign,reserves,mode);
 const opponent=SIDES.find(s=>s!==side),map=C.M.getMap(scenario),numericSeed=Number.isFinite(Number(seed))?Number(seed):217;
 const sim={version:C.VERSION,scenario,sideIds:SIDES,campaign:true,side,opponent,seed:numericSeed,mode,pressure:1,time:0,startDate:spec.startDate,durationDays:clamp(Math.round(Number(years)||spec.yearOptions[0]),spec.yearOptions[0],spec.yearOptions.at(-1))*365,status:'running',outcome:null,rng:E.createRng(numericSeed,scenario+'-shared'),nodes:map.nodes,edges:map.edges,npcs:{},units:[],camps:[],convoys:[],events:[],eventSerial:0,nextId:0,assignments:{},reserves:{},doctrines:bySide('balanced'),initialTotals:{},initialNavalTotals:bySide(0),knowledge:bySide(()=>({})),weather:{wind:'NW',strength:2,rain:false,snow:false,season:'winter'},serial:{},hqControl:{},objectives:{},objectiveProgress:{},plans:{},manpower:{...cfg.manpower},initialManpower:{...cfg.manpower},metrics:{losses:bySide(0),recruited:bySide(0),woundedReturned:bySide(0),rationsConsumed:0,rationsProduced:0,rationsLost:0,campBuilt:0,detached:0,convoysDelivered:0,convoysLost:0,fireAttacks:0,decisions:bySide(0),trainingDays:bySide(0),patrolDays:bySide(0),restDays:bySide(0),roadWork:bySide(0)},monthlyReports:[],counterfactualNotes:[],historyNotes:[]};
 sim.doctrines[side]=doctrine;
 sim.assignments[side]={...assign};sim.reserves[side]=[...reserves];
 for(const other of SIDES.filter(s=>s!==side)){sim.assignments[other]=D.fixedRoster(scenario,other).assign;sim.reserves[other]=[];}
 // Both sides are initialized first, in historical-side order; player-side choice never changes rules.
 for(const s of SIDES){
  const totalWeight=cfg.weights.reduce((a,b)=>a+b,0),mainTotal=cfg.totals[s]-24*250;
  spec.roles.forEach((r,i)=>{const id=sim.assignments[s][r.id];addNpc(sim,id,s,r.id);const duty=['logistics','transport'].includes(r.id)?'supply':['strategist','rear'].includes(r.id)?'administration':r.id==='recon'?'patrol':r.id==='engineer'?'engineer':r.id==='guard'?'reserve':'infantry';unit(sim,s+'_'+r.id,s,id,r.id,duty,cfg.starts[s][i],Math.floor(mainTotal*cfg.weights[i]/totalWeight));});
  for(let i=0;i<24;i++){const c=auxiliaryCard(s,i,scenario);addNpc(sim,c.id,s,'staff_'+KIND[i%8]);unit(sim,s+'_staff_'+i,s,c.id,'staff',KIND[i%8],cfg.auxBases[s][Math.floor(i/3)%8],250);}
  for(const id of sim.reserves[s])if(!sim.npcs[id])addNpc(sim,id,s,'reserve_officer');
  sim.initialTotals[s]=sim.units.filter(u=>u.side===s).reduce((sum,u)=>sum+u.troops,0);
  for(const a of Object.values(sim.npcs).filter(n=>n.side===s))E.setRelationship(a,sim.assignments[s].supreme,{trust:75,respect:78,loyalty:80,rivalry:0,role:'liege'});
 }
 for(const n of sim.nodes){n.originalOwner=n.owner;n.control=0;n.claimSide=null;n.roadQuality=1;n.wood=500;n.recruits=0;n.stock=['hq','depot'].includes(n.type)?550000:n.type==='pass'?130000:45000;n.baseProduction=0;}
 for(const s of SIDES){
  const farms=sim.nodes.filter(n=>n.owner===s&&['hq','depot'].includes(n.type));for(const n of farms)n.baseProduction=sim.initialTotals[s]*1.35/farms.length;
  for(const n of sim.nodes.filter(n=>n.owner===s&&['hq','depot','pass'].includes(n.type))){sim.camps.push({id:'camp_'+n.id,nodeId:n.id,x:n.x+30,y:n.y+25,side:s,name:'ค่าย'+n.name,progress:100,defense:n.defense,stock:0,burning:0,initial:true,createdAt:0,commanderId:sim.assignments[s].supreme});}
 }
 for(const e of sim.edges){e.quality=1;e.km=e.distance*(scenario==='yiling'||scenario==='jingzhou'?.35:.65);e.damage=0;}
 C.event(sim,'history','เริ่ม'+spec.name+' ค.ศ. '+spec.year,'อิงแนวรบและบุคคลจากจดหมายเหตุ ทุกฝ่ายใช้โปรแกรมคิด กติกาการผลิต การส่งกำลัง และการสูญเสียเหมือนกัน ไม่มีการบังคับผู้ชนะหรือวันตายตามประวัติศาสตร์',{side:'all'});
 C.event(sim,'briefing','เวลาในแคมเปญนับเป็นวัน','หนึ่งรอบคือหนึ่งวัน 1× เท่ากับหนึ่งวันต่อวินาที รายงานสรุปรายเดือนช่วยติดตามแผนตลอด '+sim.durationDays+' วัน',{side:'all'});
 sim.historyNotes=cfg.notes;
 C.getOps().init(sim);updateWeather(sim);sight(sim);objectives(sim);return sim;
}
function date(sim){const [y,m,d]=sim.startDate.split('-').map(Number);return new Date(Date.UTC(y,m-1,d+sim.time));}
function clock(sim){const d=date(sim);return{day:sim.time+1,hour:0,minute:0,text:d.getUTCDate()+' '+['ม.ค.','ก.พ.','มี.ค.','เม.ย.','พ.ค.','มิ.ย.','ก.ค.','ส.ค.','ก.ย.','ต.ค.','พ.ย.','ธ.ค.'][d.getUTCMonth()]+' ค.ศ. '+d.getUTCFullYear(),elapsed:'วันที่ '+(sim.time+1)+' / '+sim.durationDays};}
function updateWeather(sim){const m=date(sim).getUTCMonth(),season=m===11||m<2?'winter':m<5?'spring':m<8?'summer':'autumn';const wet=season==='summer'?.4:season==='spring'?.23:.1;sim.weather={season,wind:['NW','SE','NE','SW'][Math.floor(sim.rng.next()*4)],strength:1+Math.floor(sim.rng.next()*4),rain:sim.rng.next()<wet,snow:season==='winter'&&sim.rng.next()<.28,temperature:season==='winter'?1:season==='summer'?26:15};}
function routeCost(sim,route){return route.slice(1).reduce((v,id,i)=>{const e=sim.edges.find(e=>e.from===route[i]&&e.to===id||e.to===route[i]&&e.from===id);return v+(e?.km||100)/(e?.quality||1);},0);}
function reachable(sim,u,n){return C.findRoute(sim,u.route.length>1?u.route[1]:u.nodeId,n.id).length>0;}
function dailySpeed(sim,u,edge){const stat=C.card(u.commanderId)?.stats.command||50;return (edge.terrain==='water'?(u.type==='convoy'?11:13+(C.card(u.commanderId)?.stats.naval||40)/12):u.type==='convoy'?10: u.type==='scout'?17:u.type==='cavalry'?19:12)*(edge.terrain==='mountain'?(u.type==='cavalry'?.45:.55):1)*(sim.weather.snow&&edge.terrain==='mountain'?.45:sim.weather.rain?.72:1)*clamp(edge.quality||1,.25,1)*(1-u.fatigue/180)*(.8+stat/250);}
function move(sim,u){if(u.troops<=0||u.status==='engaged'||u.status==='building'||u.route.length<2)return;let day=1;for(let i=0;i<8&&u.route.length>1&&day>0;i++){
 const a=sim.nodes.find(n=>n.id===u.route[0]),b=sim.nodes.find(n=>n.id===u.route[1]),e=sim.edges.find(e=>e.from===a.id&&e.to===b.id||e.from===b.id&&e.to===a.id);if(!e){u.route=[];u.status='holding';break;}
 if(u.type==='convoy')u.waterborne=e.terrain==='water';const speed=dailySpeed(sim,u,e),left=e.km*(1-u.edgeProgress),step=speed*day;
 if(step>=left){day-=left/speed;u.x=b.x;u.y=b.y;u.nodeId=b.id;u.route.shift();u.edgeProgress=0;
  if(u.route.length<2){u.route=[];u.target=null;u.status=u.retreating?'recovering':'holding';if(u.retreating)u.recoverUntil=sim.time+12;u.retreating=false;u.taskUntil=sim.time+(b.owner!==u.side?7:2);if(u.type!=='convoy')C.event(sim,'movement',sim.npcs[u.commanderId].name+' ถึง'+b.name,u.name+' ใช้เส้นทางจริงของฉาก เหลือเสบียง '+C.supplyDays(u).toFixed(1)+' วัน ความล้า '+Math.round(u.fatigue),{side:u.side,unitId:u.id,npcId:u.commanderId,nodeId:b.id});}
 }else{u.edgeProgress+=step/e.km;u.x=a.x+(b.x-a.x)*u.edgeProgress;u.y=a.y+(b.y-a.y)*u.edgeProgress;day=0;}
 }}
function sight(sim){for(const side of sideIds(sim)){const own=sim.units.filter(u=>u.side===side&&u.troops>0);for(const enemy of sim.units.filter(u=>u.side!==side&&u.troops>0)){const observer=own.find(u=>C.dist(u,enemy)<(u.type==='scout'?300:180));if(observer)sim.knowledge[side][enemy.id]={id:enemy.id,x:enemy.x,y:enemy.y,time:sim.time,troops:enemy.troops,nodeId:enemy.nodeId,commanderId:enemy.commanderId};}}}
function base(sim,u,safe=false){return C.dist?sim.nodes.filter(n=>n.owner===u.side&&n.stock>u.troops*6&&reachable(sim,u,n)&&(!safe||!Object.values(sim.knowledge[u.side]).some(k=>sim.time-k.time<12&&C.dist(k,n)<160))).sort((a,b)=>C.dist(a,u)-C.dist(b,u))[0]:null;}
function target(sim,u,raid=false){
 const origin=u.route.length>1?u.route[1]:u.nodeId,known=Object.values(sim.knowledge[u.side]).filter(k=>sim.time-k.time<12),key=D.CAMPAIGNS[sim.scenario].keys;
 const candidates=sim.nodes.filter(n=>n.owner!==u.side&&n.type!=='transit'&&C.findRoute(sim,origin,n.id,{waterOnly:u.type==='naval'}).length>0).map(n=>{const route=C.findRoute(sim,origin,n.id,{side:u.side,avoidKnownThreats:raid,waterOnly:u.type==='naval'}),days=routeCost(sim,route)/7,threat=known.filter(k=>C.dist(k,n)<150).reduce((sum,k)=>sum+k.troops,0);return{n,route,days,score:days+threat/500-(key.includes(n.id)?18:0)-(raid&&n.type==='depot'?12:0)};});
 return candidates.sort((a,b)=>a.score-b.score)[0];
}
function remember(sim,u,action,value,text){E.remember(sim.npcs[u.commanderId],'hz_'+action,value,text,sim.time,{importance:65});}
function decision(sim,u){
 if(u.troops<=0||u.status==='merged'||u.retreating||u.route.length>1||u.status==='building'||u.taskUntil>sim.time||u.recoverUntil>sim.time)return;
 const card=C.card(u.commanderId),npc=sim.npcs[u.commanderId],n=sim.nodes.find(n=>n.id===u.nodeId),days=C.supplyDays(u),t=target(sim,u),known=Object.values(sim.knowledge[u.side]).filter(k=>sim.time-k.time<12&&C.dist(k,u)<250),enemy=known.reduce((v,k)=>v+k.troops,0),friends=sim.units.filter(a=>a.side===u.side&&a.troops>0&&C.dist(a,u)<180).reduce((v,a)=>v+a.troops,0),ratio=enemy/Math.max(1,friends),rear=['supply','administration','medical','training'].includes(u.duty),options=[];
 const add=(id,score,reason)=>{const a=ACT.find(a=>a[0]===id);options.push({id:'hz_'+id,label:a[1],baseScore:35,situationalBias:score-35,riskLevel:['advance','raid'].includes(id)?45:15,reason});};
 add('guard',rear?45:18,'รักษา'+n.name+' และรอประสานแผนกับเพื่อนร่วมทัพ');
 if(days<24||u.duty==='supply'||u.duty==='administration')add('supply',days<8?165:days<18?105:rear?82:28,'เสบียง '+days.toFixed(1)+' วัน เทียบกับระยะเดินทัพ การจัดส่งต้องหักจากคลังและเดินทางจริง');
 if(u.fatigue>35||u.morale<52||u.sick>15||u.wounded>0||u.duty==='medical')add('rest',u.morale<30||days<3?150:50+u.fatigue*.7,'พักฟื้นความล้า '+Math.round(u.fatigue)+' ขวัญ '+Math.round(u.morale)+' และผู้บาดเจ็บ '+Math.round(u.wounded));
 if(C.canBuild(sim,u))add('fortify',u.duty==='engineer'?98:40+C.getOps().campNeed(sim,u)+(sim.weather.season==='winter'?20:0),'ตั้งค่ายใช้เครื่องมือและเสบียงของหน่วย ต้องก่อสร้างหลายวัน');
 if(u.duty==='patrol'||known.length<2)add('patrol',u.duty==='patrol'?90:35,'ตรวจแนวทางและอัปเดตข่าวที่ล้าสมัย ไม่ใช้ตำแหน่งลับของศัตรู');
 if(n.owner===u.side&&days>=15&&(u.training<85||u.troops<u.initialTroops*.8||u.duty==='training'))add('train',u.duty==='training'?88:35+(sim.weather.snow?20:0),'ฝึกขบวนและรับคนจากกำลังทดแทนที่มีจำกัด ไม่มีการเพิ่มทหารฟรี');
 const posture=sim.doctrines[u.side]==='aggressive'?15:sim.doctrines[u.side]==='cautious'?-10:0;
 const next=t?.route[1],nextNode=sim.nodes.find(n=>n.id===next),travel=t?routeCost(sim,t.route.slice(0,2))/Math.max(3,7):999;
 if(t&&!rear&&days>=travel+10&&ratio<2.4){add('advance',52+posture-(sim.weather.snow?23:0),'แผนหลายช่วง: มุ่ง '+t.n.name+' โดยเคลื่อนถึง '+(nextNode?.name||t.n.name)+' ก่อน ใช้เสบียงเดินทางประมาณ '+Math.ceil(travel)+' วัน');if(card.stats.strategy>60)add('raid',42+posture+(u.duty==='patrol'?5:0),'พิจารณาเส้นทางอ้อมหรือจุดลำเลียงแทนการชนที่มั่นตรง ๆ');}
 const fireTargets=sim.scenario==='yiling'&&!sim.weather.rain?known.filter(k=>C.dist(k,u)<150&&sim.nodes.find(n=>n.id===k.nodeId)?.terrain==='forest'):[];if(fireTargets.length&&u.materials>=40&&u.fatigue<70)add('fire_raid',card.stats.strategy>70?108:68,'พบค่ายหรือกองทัพในป่าแห้งที่เข้าถึงได้ ใช้เครื่องมือ 40 หน่วยและเสี่ยงไฟลามกลับ');
 const mobilisation=C.getOps().context(sim,u);if(mobilisation.dispatch)options.push({id:'op_dispatch',label:'ส่งทัพย่อยจากฐานระดมพล',baseScore:145,situationalBias:0,riskLevel:25,reason:'ระดมจาก'+mobilisation.base.name+' โดยแบ่งทหารและเสบียงจริง'});else if(mobilisation.rally&&mobilisation.target)options.push({id:'op_rally',label:'รวมกำลังที่ฐานระดมพล',baseScore:85,situationalBias:0,riskLevel:20,reason:'เลือก'+mobilisation.target.name+' เป็นฐานตามเส้นทางและคลัง'});
 const scored=E.scoreDecisionOptions(npc,options,{time:sim.time,includeMemory:true,memoryScale:.6}),chosen=scored[0],act=chosen.id.slice(3);u.decision={time:sim.time,action:act,label:chosen.label,score:chosen.score,reason:chosen.reason,contributions:chosen.decisionContributions,options:scored.slice(0,4).map(o=>({id:o.id,label:o.label,score:o.score,contributions:o.decisionContributions}))};u.lastDecision=sim.time;u.task=act;u.taskUntil=sim.time+5;sim.metrics.decisions[u.side]++;
 if(u.lastAction!==act||sim.time-(u.lastReport||-99)>=25){C.event(sim,'decision',npc.name+' • '+chosen.label,chosen.reason+' • กำหนดทบทวนแผนใน 5 วัน',{side:u.side,unitId:u.id,npcId:npc.id,nodeId:u.nodeId,decision:clone(u.decision)});u.lastReport=sim.time;}u.lastAction=act;
 if(act==='dispatch'){C.getOps().dispatch(sim,u);return;}if(act==='rally'){if(mobilisation.target){C.orderMove(sim,u,mobilisation.target.id,'รวมพลที่'+mobilisation.target.name);u.rallyBase={kind:'planned',nodeId:mobilisation.target.id};}return;}
 if(act==='fire_raid'){const k=fireTargets[0],enemy=sim.units.find(e=>e.id===k.id);u.materials-=40;if(enemy&&C.dist(enemy,u)<150){enemy.burning=clamp(enemy.burning+45);for(const c of sim.camps.filter(c=>C.dist(c,enemy)<90))c.burning=clamp(c.burning+55);sim.metrics.fireAttacks++;C.event(sim,'fire',npc.name+' ใช้ไฟโจมตีแนวป่า','ลงมือจากข่าวที่พบและระยะจริง ใช้เครื่องมือ 40 หน่วย ฝนและแนวกันไฟลดผลได้',{side:u.side,unitId:u.id,npcId:npc.id,nodeId:u.nodeId});}u.status='holding';u.order='เฝ้าดูไฟและรักษาระยะ';return;}
 if(act==='advance'||act==='raid'){
  const route=act==='raid'?C.findRoute(sim,u.nodeId,t.n.id,{side:u.side,avoidKnownThreats:true}):t.route;
  if(route.length>1){const next=route[1];C.orderMove(sim,u,next,chosen.label+' → '+sim.nodes.find(n=>n.id===next).name);u.planGoal=t.n.id;u.plan={goal:t.n.id,createdAt:sim.time,route:clone(route),estimatedDays:Math.ceil(routeCost(sim,route)/7)};}return;
 }
 if(act==='supply'){const near=base(sim,u);if(near&&n.stock<u.troops*10){if(C.dist(near,u)<180&&reachable(sim,u,near))C.orderMove(sim,u,near.id,'กลับจุดรวบรวมเสบียง');else sendConvoy(sim,u.side,u);}u.status=u.route.length?'moving':'supplying';u.order='จัดคลัง เสบียง และขบวนลำเลียง';return;}
 if(act==='rest'){u.status='recovering';u.order='พักฟื้น 5 วัน';if(ratio>2){const b=base(sim,u,true);if(b)C.diagnostics.anchorReturn(sim,u,b.id);}return;}
 if(act==='fortify'){buildCamp(sim,u);return;}
 if(act==='patrol'){
  const adjacent=sim.edges.filter(e=>e.from===u.nodeId||e.to===u.nodeId).map(e=>sim.nodes.find(n=>n.id===(e.from===u.nodeId?e.to:e.from))).filter(n=>n.owner===u.side||n.owner==='neutral').sort((a,b)=>(sim.serial['patrol_'+u.side+'_'+a.id]||-50)-(sim.serial['patrol_'+u.side+'_'+b.id]||-50));
  if(adjacent[0]&&days>15){const t=adjacent[0];sim.serial['patrol_'+u.side+'_'+t.id]=sim.time;C.orderMove(sim,u,t.id,'ลาดตระเวนและคุ้มกันทาง '+t.name);}else{u.status='patrolling';u.order='เฝ้าตรวจการณ์แนวรอบค่าย';}return;
 }
 u.status=act==='train'?'training':'holding';u.order=chosen.label+'ที่'+n.name;
}
function buildCamp(sim,u){if(!u||!C.canBuild(sim,u))return false;const n=sim.nodes.find(n=>n.id===u.nodeId);if(u.route.length||n.owner!==u.side||!n.campable||u.materials<80||sim.camps.some(c=>c.nodeId===n.id)||C.supplyDays(u)<12)return false;u.materials-=80;const food=Math.min(u.rations*.12,u.troops*4);u.rations-=food;const c={id:'hz_camp_'+(++sim.nextId),nodeId:n.id,x:n.x+30,y:n.y+25,side:u.side,name:'ค่าย'+n.name,progress:0,defense:10,stock:food,burning:0,initial:false,createdAt:sim.time,commanderId:u.commanderId};C.getOps().ensureCamp(c);sim.camps.push(c);u.buildCamp=c.id;u.status='building';u.task='fortify';C.event(sim,'camp',sim.npcs[u.commanderId].name+' เริ่มตั้งค่าย',c.name+' ใช้เครื่องมือ 80 หน่วย และจัดเสบียง '+Math.round(food).toLocaleString()+' หน่วย ต้องใช้แรงงานหลายวัน',{side:u.side,nodeId:n.id,unitId:u.id,npcId:u.commanderId});return c;}
function sendConvoy(sim,side,target,isDepot=false){
 const id=isDepot?'node_'+target.id:target.id;if(sim.convoys.some(c=>c.side===side&&c.targetKey===id&&!['delivered','lost'].includes(c.status)))return false;
 const dest=isDepot?target:sim.nodes.find(n=>n.id===target.nodeId),need=isDepot?Math.max(0,250000-dest.stock):Math.max(0,target.troops*40-target.rations);
 const sources=sim.nodes.filter(n=>n.owner===side&&n.id!==dest.id&&n.stock>120000).map(n=>({n,path:C.findRoute(sim,n.id,dest.id,{side,avoidEnemy:true})})).filter(x=>x.path.length>1).sort((a,b)=>routeCost(sim,a.path)-routeCost(sim,b.path));
 const source=sources[0];if(!source)return false;const skill=C.card((sim.assignments[side].logistics||sim.assignments[side].transport)).stats.logistics,amount=Math.min(need,source.n.stock-60000,50000+skill*1000);if(amount<5000)return false;
 source.n.stock-=amount;const c={id:'hz_supply_'+(++sim.nextId),side,type:'convoy',commanderId:sim.assignments[side].transport,role:'convoy',troops:1,nodeId:source.n.id,x:source.n.x,y:source.n.y,route:[],edgeProgress:0,target:null,targetUnit:isDepot?null:target.id,targetNode:isDepot?dest.id:null,targetKey:id,cargo:amount,fatigue:0,status:'moving',order:'ลำเลียงเสบียงไป'+dest.name};sim.convoys.push(c);C.orderMove(sim,c,dest.id,c.order);
 C.event(sim,'supply','ส่งขบวนลำเลียงจาก'+source.n.name,'ขน '+Math.round(amount).toLocaleString()+' หน่วย ผ่าน '+source.path.length+' จุด ใช้เวลาโดยประมาณ '+Math.ceil(routeCost(sim,source.path)/8)+' วัน เสี่ยงฝน หิมะและการตัดทาง',{side,nodeId:source.n.id,unitId:isDepot?null:target.id});return c;
}
function logistics(sim){
 const season=sim.weather.season,mult=season==='autumn'?1.8:season==='winter'?.55:season==='spring'?.85:1;
 for(const n of sim.nodes){if(n.owner==='neutral')continue;const production=n.baseProduction*mult*(n.owner===n.originalOwner?1:.55);n.stock+=production;sim.metrics.rationsProduced+=production;
  if(sim.weather.rain&&sim.weather.season==='summer'&&n.type==='depot'){const loss=n.stock*.0008;n.stock-=loss;sim.metrics.rationsLost+=loss;}
 }
 for(const u of sim.units){if(u.troops<=0||u.status==='merged')continue;const need=u.troops*(u.route.length?1.2:1),eat=Math.min(u.rations,need);u.rations-=eat;sim.metrics.rationsConsumed+=eat;if(eat<need){u.morale=clamp(u.morale-1.2);u.cohesion=clamp(u.cohesion-.5);u.sick=clamp(u.sick+.3);}
  const n=sim.nodes.find(n=>n.id===u.nodeId);if(!u.route.length&&n.owner===u.side&&C.dist(u,n)<40){const amount=Math.min(n.stock,Math.max(0,u.troops*45-u.rations),u.troops*6);n.stock-=amount;u.rations+=amount;const tools=Math.min(3,n.wood,Math.max(0,240-u.materials));n.wood-=tools;u.materials+=tools;}
  u.sick=clamp(u.sick+(sim.weather.rain&&u.route.length?.08:sim.weather.snow?.04:-.03));
  u.fatigue=clamp(u.fatigue+(u.route.length?.7:u.status==='engaged'?1.2:-1.4));if(!u.route.length&&u.status!=='engaged'&&eat>=need)u.morale=clamp(u.morale+.35);
  if(u.task==='train'&&!u.route.length){u.training=clamp(u.training+.8);u.cohesion=clamp(u.cohesion+.6);sim.metrics.trainingDays[u.side]++;if(u.troops<u.initialTroops&&sim.manpower[u.side]>0&&C.supplyDays(u)>15){const men=Math.min(sim.manpower[u.side],Math.max(0,u.initialTroops-u.troops),30);u.troops+=men;sim.manpower[u.side]-=men;sim.metrics.recruited[u.side]+=men;}}
  if(u.task==='rest'&&!u.route.length){u.fatigue=clamp(u.fatigue-2);u.morale=clamp(u.morale+.8);u.sick=clamp(u.sick-.5);const recovered=Math.min(u.wounded,Math.max(1,Math.floor(u.troops*.008)));u.wounded-=recovered;sim.metrics.woundedReturned[u.side]+=recovered;sim.metrics.restDays[u.side]++;}
  if(u.task==='patrol')sim.metrics.patrolDays[u.side]++;
  if(u.duty==='engineer'&&!u.route.length){for(const e of sim.edges.filter(e=>e.from===u.nodeId||e.to===u.nodeId)){const fix=Math.min(.012,1-e.quality);if(fix>0){e.quality+=fix;sim.metrics.roadWork[u.side]+=fix;}}}
 }
 if(sim.time%5===0)for(const side of sideIds(sim)){
  for(const target of sim.units.filter(u=>u.side===side&&u.troops>0&&C.supplyDays(u)<22).sort((a,b)=>C.supplyDays(a)-C.supplyDays(b)).slice(0,8))sendConvoy(sim,side,target);
  for(const node of sim.nodes.filter(n=>n.owner===side&&['depot','pass','hq'].includes(n.type)&&n.stock<130000).sort((a,b)=>a.stock-b.stock).slice(0,4))sendConvoy(sim,side,node,true);
 }
 for(const c of sim.convoys){if(['delivered','lost'].includes(c.status))continue;move(sim,c);const hostile=sim.units.find(u=>u.side!==c.side&&u.troops>100&&!u.retreating&&C.dist(u,c)<35),escort=sim.units.filter(u=>u.side===c.side&&u.troops>0&&C.dist(u,c)<80).reduce((s,u)=>s+u.troops,0);
  if(hostile&&hostile.troops>escort*.75){const loot=Math.min(c.cargo,Math.max(0,hostile.troops*50-hostile.rations));hostile.rations+=loot;sim.metrics.rationsLost+=c.cargo-loot;c.cargo=0;c.status='lost';sim.metrics.convoysLost++;C.event(sim,'supply','ขบวนเสบียงถูกตัด',sim.npcs[hostile.commanderId].name+' เข้าถึงทางลำเลียง ยึดเสบียง '+Math.round(loot).toLocaleString()+' หน่วย',{side:c.side,nodeId:c.nodeId});continue;}
  const loss=c.cargo*(sim.weather.snow?.002:sim.weather.rain?.001:.0002);c.cargo-=loss;sim.metrics.rationsLost+=loss;
  const target=c.targetUnit?sim.units.find(u=>u.id===c.targetUnit&&u.troops>0):sim.nodes.find(n=>n.id===c.targetNode);
  if(!target){sim.nodes.find(n=>n.id===c.nodeId).stock+=c.cargo;c.cargo=0;c.status='delivered';continue;}
  if(C.dist(c,target)<40&&!target.route?.length){if(c.targetUnit)target.rations+=c.cargo;else if(target.owner===c.side)target.stock+=c.cargo;else{sim.metrics.rationsLost+=c.cargo;}c.cargo=0;c.status='delivered';sim.metrics.convoysDelivered++;const officer=sim.npcs[c.commanderId];if(officer)E.remember(officer,'hz_supply',2,'ขบวนเสบียงส่งถึงเป้าหมายหลังเดินทางจริง',sim.time,{importance:40});C.event(sim,'supply','เสบียงถึง'+(target.name||'กองทัพ'),c.targetUnit?'ส่งอาหารถึงกองทัพที่หยุดรับเสบียงแล้ว':'คลังหน้ารับอาหารจากขบวนลำเลียงแล้ว',{side:c.side,nodeId:c.nodeId,unitId:c.targetUnit});}
  else if(!c.route.length){const targetNode=c.targetUnit?target.nodeId:target.id;C.orderMove(sim,c,targetNode,'ติดตามเป้าหมายลำเลียง');}
 }
 if(sim.convoys.length>240)sim.convoys=sim.convoys.filter(c=>!['delivered','lost'].includes(c.status)).concat(sim.convoys.filter(c=>['delivered','lost'].includes(c.status)).slice(-40));
}
function damage(sim,u,amount){const impact=Math.min(u.troops,Math.max(0,Math.round(amount))),dead=Math.min(u.troops,Math.ceil(impact*.65));u.troops-=dead;u.wounded=Math.min(u.troops,u.wounded+Math.floor(impact*.35));sim.metrics.losses[u.side]+=dead;if(!u.troops){u.status='destroyed';u.route=[];C.event(sim,'battle',u.name+' หมดสภาพรบ','หน่วยของ'+sim.npcs[u.commanderId].name+' ไม่เหลือกำลังจัดรูปขบวน',{side:u.side,unitId:u.id,nodeId:u.nodeId});}return dead;}
function battle(sim){
 const alive=sim.units.filter(u=>u.troops>0&&u.status!=='merged'),incoming=new Map(),inContact=new Set();const power=u=>{const c=C.card(u.commanderId),n=C.nearestNode?C.nearestNode(sim,u):sim.nodes.find(n=>n.id===u.nodeId),fort=C.dist(n,u)<60&&n.owner===u.side?1+C.defenseAt(sim,n,u.side)/100:1;return Math.max(0,u.troops-u.wounded)*(.5+c.stats.command/180+c.stats.martial/250)*(u.morale/100)*(.5+u.training/160)*(1-u.fatigue/200)*(C.supplyDays(u)>3?1:.5)*fort;};
 const counts=new Map(alive.map(u=>[u.id,alive.filter(e=>e.side!==u.side&&C.dist(e,u)<45).length]));
 for(let i=0;i<alive.length;i++)for(let j=i+1;j<alive.length;j++){const a=alive[i],b=alive[j];if(a.side===b.side||C.dist(a,b)>=45)continue;inContact.add(a.id);inContact.add(b.id);incoming.set(a.id,(incoming.get(a.id)||0)+power(b)*.008/counts.get(b.id)*(b.retreating?.3:1)*(.85+sim.rng.next()*.3));incoming.set(b.id,(incoming.get(b.id)||0)+power(a)*.008/counts.get(a.id)*(a.retreating?.3:1)*(.85+sim.rng.next()*.3));const key=[a.id,b.id].sort().join(':');if(!sim.serial[key]||sim.time-sim.serial[key]>15){sim.serial[key]=sim.time;C.event(sim,'battle',sim.npcs[a.commanderId].name+' ปะทะ '+sim.npcs[b.commanderId].name,'กำลัง '+a.troops.toLocaleString()+' ต่อ '+b.troops.toLocaleString()+' นาย ผลขึ้นกับพื้นที่ การฝึก ขวัญ และอาหาร',{side:a.side,unitId:a.id,nodeId:a.nodeId});}}
 for(const u of alive){if(inContact.has(u.id)){if(!u.retreating)u.status='engaged';const loss=damage(sim,u,incoming.get(u.id)||0);u.morale=clamp(u.morale-loss/Math.max(1,u.troops)*90-.2);u.cohesion=clamp(u.cohesion-.3);if(u.troops>0&&!u.retreating&&(u.morale<30||u.troops<u.initialTroops*.3)){const b=base(sim,u,true);if(b&&C.diagnostics.anchorReturn(sim,u,b.id)){remember(sim,u,'advance',-5,'เสียกำลังและถอนกลับฐาน');C.event(sim,'retreat',sim.npcs[u.commanderId].name+' ถอนทัพ','ขวัญ '+Math.round(u.morale)+' กำลัง '+u.troops.toLocaleString()+' นาย กลับ '+b.name,{side:u.side,unitId:u.id,npcId:u.commanderId,nodeId:u.nodeId});}}}else if(u.status==='engaged')u.status=u.route.length?'moving':'holding';}
}
function campsAndControl(sim){
 for(const c of sim.camps){const workers=sim.units.filter(u=>u.buildCamp===c.id&&u.troops>0&&!u.route.length&&u.status!=='engaged');if(c.progress<100&&workers.length){c.progress=clamp(c.progress+workers.reduce((s,u)=>s+3+C.card(u.commanderId).stats.logistics/30,0));if(c.progress>=100){c.defense=35;for(const u of workers){u.buildCamp=null;u.status='holding';}sim.metrics.campBuilt++;C.event(sim,'camp',c.name+' สร้างเสร็จ','พร้อมพักทหารและป้องกันเส้นทาง',{side:c.side,nodeId:c.nodeId});}}
 }
 C.getOps().update(sim);
 for(const n of sim.nodes){const at=sim.units.filter(u=>u.troops>0&&!u.route.length&&!u.retreating&&u.morale>=35&&C.dist(u,n)<55),present=sim.units.filter(u=>u.troops>0&&!u.retreating&&C.dist(u,n)<55),sides=new Set(present.map(u=>u.side));if(sides.size!==1||!at.length){n.control=0;n.claimSide=null;continue;}const side=at[0].side;if(side===n.owner){n.control=0;n.claimSide=null;continue;}const force=at.reduce((sum,u)=>sum+u.troops,0);if(force<500||C.getOps().hostileCamp(sim,n.id,side)){n.control=0;continue;}if(n.claimSide!==side){n.claimSide=side;n.control=0;}n.control++;if(n.control>=5){n.owner=side;n.control=0;n.claimSide=null;C.event(sim,'capture',C.sideLabel(sim,side)+' ยึด'+n.name,'รักษาพื้นที่ต่อเนื่อง 5 วัน ยึดเมืองและคลัง ค่ายศัตรูต้องถูกทำลายแยกจากเมือง',{side,nodeId:n.id,unitId:at[0].id});}}
}
function objectives(sim){
 const cfg=D.CAMPAIGNS[sim.scenario],keys=cfg.keys;sim.objectives={};for(const side of sideIds(sim)){const held=keys.filter(id=>sim.nodes.find(n=>n.id===id).owner===side).length,units=sim.units.filter(u=>u.side===side&&u.troops>0),days=units.reduce((v,u)=>v+u.rations,0)/Math.max(1,units.reduce((v,u)=>v+u.troops,0));sim.objectives[side]=[{id:'theatre',title:'คุมแกนยุทธการ: '+cfg.keyName,progress:held,required:keys.length,details:'ถือครอง '+held+' / '+keys.length+' จุด • เสบียงติดทัพเฉลี่ย '+days.toFixed(1)+' วัน',ready:held===keys.length},{id:'observation',title:'ติดตามสงครามหลายฤดูกาล',progress:sim.time,required:sim.durationDays,details:'จำลองแล้ว '+sim.time+' วัน จาก '+sim.durationDays+' วัน',ready:false}];}
 if(sim.time>=sim.durationDays){const scores=Object.fromEntries(sideIds(sim).map(side=>[side,round(keys.filter(id=>sim.nodes.find(n=>n.id===id).owner===side).length*20+C.campaignScore(sim,side)*.4)])),ranking=sideIds(sim).slice().sort((a,b)=>scores[b]-scores[a]||a.localeCompare(b)),winner=scores[ranking[0]]-scores[ranking[1]]<5?null:ranking[0];sim.status='completed';sim.outcome={winner,scores,result:winner===sim.side?'victory':winner?'defeat':'draw',time:sim.time,reason:'ครบระยะสังเกต '+sim.durationDays+' วัน: '+sideIds(sim).map(side=>C.sideLabel(sim,side)+' '+scores[side]).join(' / ')};C.event(sim,'outcome','สิ้นสุดแคมเปญหลายฝ่าย',sim.outcome.reason,{side:'all'});}

}

function monthly(sim){const r={day:sim.time,date:clock(sim).text,weather:sim.weather.season,sides:{}};for(const side of sideIds(sim)){const t=C.totals(sim,side);r.sides[side]={...t,decisions:sim.metrics.decisions[side],manpower:sim.manpower[side]};C.event(sim,'monthly','รายงานประจำเดือน '+C.sideLabel(sim,side),'กำลัง '+t.troops.toLocaleString()+' นาย • คลัง '+Math.round(t.stock).toLocaleString()+' หน่วย • ค่าย '+t.camps+' • กำลังทดแทน '+sim.manpower[side].toLocaleString()+' • ตัดสินใจสะสม '+sim.metrics.decisions[side].toLocaleString()+' ครั้ง',{side});}sim.monthlyReports.push(r);}
function forestFire(sim){if(sim.scenario!=='yiling')return;
 const active=sim.units.filter(u=>u.troops>0),burning=active.filter(u=>u.burning>25).map(u=>({...u}));
 for(const u of active){if(u.burning>0){damage(sim,u,Math.max(1,u.troops*u.burning*.00006));u.morale=clamp(u.morale-.6);u.burning=clamp(u.burning-(sim.weather.rain?25:u.task==='rest'?12:6));}}
 for(const c of sim.camps){if(c.burning>0){const loss=c.stock*c.burning*.0003;c.stock-=loss;sim.metrics.rationsLost+=loss;c.defense=Math.max(3,c.defense-1);c.burning=clamp(c.burning-(sim.weather.rain?30:8));}}
 if(!sim.weather.rain&&sim.time%5===0)for(const a of burning)for(const u of active){if(a.id===u.id||u.burning>20||C.dist(a,u)>100)continue;const site=sim.nodes.find(n=>n.id===u.nodeId),camp=sim.camps.find(c=>c.side===u.side&&c.nodeId===u.nodeId&&c.progress===100);if(site?.terrain==='forest'&&sim.rng.next()<(camp?.12:.45))u.burning=35;}
}
function step(sim,days=1){days=clamp(Math.floor(Number(days)||1),1,120);for(let d=0;d<days&&sim.status!=='completed';d++){
 sim.time++;if(sim.time%7===1)updateWeather(sim);if(sim.weather.rain||sim.weather.snow)for(const e of sim.edges)if(e.terrain==='mountain')e.quality=clamp(e.quality-.003,.35,1);
 sight(sim);if(sim.time===1||sim.time%5===0)for(const side of sideIds(sim))for(const u of sim.units.filter(u=>u.side===side))decision(sim,u);
 for(const u of sim.units)move(sim,u);logistics(sim);battle(sim);forestFire(sim);campsAndControl(sim);objectives(sim);if(sim.time%30===0)monthly(sim);
 }return sim;}
const api={createSimulation,step,clock,buildCamp,decision,sendConvoy,SIDE_IDS,diagnostics:{battle,campsAndControl,objectives},sharedRulesVersion:'campaign-shared-3'};root.LongCampaign=api;if(typeof module==='object')module.exports=api;
})(typeof globalThis!=='undefined'?globalThis:this);
