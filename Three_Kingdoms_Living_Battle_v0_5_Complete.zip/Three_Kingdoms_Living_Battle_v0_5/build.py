"""Build a dependency-free offline HTML. No bundler or network is needed."""
from pathlib import Path
import re
ROOT = Path(__file__).resolve().parent
html = (ROOT / 'index.html').read_text()
fonts = (ROOT / 'src/fonts.css').read_text()
html = html.replace('<link rel="stylesheet" href="src/fonts.css">', '<style>\n'+fonts+'\n</style>')
css = (ROOT / 'src/app.css').read_text()
html = html.replace('<link rel="stylesheet" href="src/app.css">', '<style>\n'+css+'\n</style>')
def inline(match):
    code = (ROOT / match.group(1)).read_text().replace('</script', '<\\/script')
    return '<script>\n'+code+'\n</script>'
html = re.sub(r'<script src="([^"]+)"></script>', inline, html)
target=ROOT/'Three_Kingdoms_Living_Battle_v0_5.html'
target.write_text(html)
print(f'Built {target.name} ({target.stat().st_size:,} bytes)')
